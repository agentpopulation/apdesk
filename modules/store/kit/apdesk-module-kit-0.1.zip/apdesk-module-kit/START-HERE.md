# AP Desk module kit 0.1: start here

For AP Desk 0.1.1. Plain text files only; nothing to install. You need Node 22.13 or later, the same Node the desk uses.
Open a terminal in this folder (on Windows: in File Explorer, type `cmd` in the address bar of this folder and press Enter).

## What is in it

- **NOTE-FOR-THE-CODING-AGENT.md**: the note you give a coding agent, with this zip, to get a module built.
- **GUIDE.md**: how modules work: loading, the menu, the Module Store, the look, choosing models, budget, Bench, settings,
  tools, approvals, storage, words on screen, testing, and the Advisor worked through. **CONTRACT.md**: the exact reference.
- **samples/**: `hello-notes` (the smallest complete module), `advisor` (your Advisor, a first working version),
  `guide-extras` (the guide's other examples), `skill-example` and `skill-bad-example` (one honest skill, one that trips the checks).
- **specs/**: `ADVISOR-SPEC.md` (the next steps for the Advisor) and `NEW-MODULE-TEMPLATE.md` (a form for any new module).
- **tools/**: the checks and helpers below. **tests/**: the kit's own tests (`node --test` runs them all).

## 1. Get a module built by a coding agent

1. Fill in `specs/NEW-MODULE-TEMPLATE.md` (or use `specs/ADVISOR-SPEC.md`).
2. Give the agent this zip, the note `NOTE-FOR-THE-CODING-AGENT.md` and your filled form.
3. It hands back a zip of the module, the checker's report, its test output and a list of what it did not check.
4. Check what came back yourself (step 2 below). Do not take its word for it.

## 2. Check a module someone gave you, and add it

```
node tools/check-module.mjs path\to\their-module.zip
node tools/add-module.mjs path\to\their-module.zip --desk C:\apdesk
```
The first reads the files and prints what the module can do (the label). It does not run the module's code. The second
runs the same check, then copies the module into `C:\apdesk\modules\<id>\` (use your own desk folder). A red line stops it.
Yellow lines are shown and you are asked y or N; in a script, or when you pipe the answer in, add `--yes` instead (it
never skips a red line). It never overwrites a module of the same name unless you add `--replace`; then the old one stays
in the modules folder as `<id>.old-<date>`, asleep (its module.json renamed), until you delete it.
Then restart the desk and switch the module on in Settings › Modules.

**Running it once (`--run`).** Add `--run` to either command to also start the module once and run its tests. Read the
label first. The run happens in a separate Node process that may read only a copy of the module and write only in a temp
folder, with no programs, no workers and the network refused. Those locks are Node's own and the kit's, not a wall:
code that finds a way round them could still do harm on this PC. Without `--run`, no code of the module runs.

**Signatures.** If the publisher signed it, check with his public key: `--key path\to\his-key.pub.json`. Get that key
from him by another way (in person, or his own site), and compare the fingerprint the check prints with the one he reads
out to you. A key that came in the same zip or message proves nothing, and the name in "signed" is whatever the signer
typed. To sign your own: `node tools/make-module-keys.mjs D:\keys\modules.key` once, then
`node tools/sign-module.mjs <module folder> --key D:\keys\modules.key --publisher "Your name"`. Use a key of its own for
modules, not the one that signs desk updates: if it leaks, someone can sign modules in your name, but not desk updates.
Give only the file that ends in `.pub.json`; never the `.key` file. Keep the `.key` file off the internet and out of this folder.

## 3. Bring in a skill

A skill is a short set of steps an agent follows (a folder with SKILL.md, or one .md file).
```
node tools/check-skill.mjs path\to\skill-folder
node tools/import-skill.mjs path\to\skill-folder
```
The import writes a small file `<name>.skill.json` with the name and the steps, with every invisible character taken out.
Nothing that came with the skill is run or copied: scripts are listed as "left out", with the steps that mention them.
To add it: in the desk, open **Agents**, open an agent, the tab **Tools and skills**, press **Write a skill**, and paste
the name and then the steps from that file. (There is a second way through the browser console of the desk's own window,
printed by the tool. Use it only if you are used to the console, and never paste anything there that you have not read.)

## What "checked" means, and what it does not

- The module check reads every file and lists what the module reaches for (its doors, tables, outside hosts, tools); it
  compares that with what the module says about itself and with its signature. It is a text check: code that builds names
  at run time, or that behaves well until it is in your real desk, can pass it. With `--run` it also starts the module once
  in a locked-down process; a run shows only what the code chose to do there.
- Once added, a module runs inside the desk with the desk's whole powers: your files, your keys, the network. The desk does
  not stop one module from reading another module's tables, or from adding tools it did not list.
- The skill check is a list of English words, read line by line and paragraph by paragraph. Other languages and other
  wording get past it. Read every skill yourself before you add it.
- So: add a module or a skill only from someone you would run a program from.

## Typing /advisor in chat

AP Desk 0.1.1 has no slash commands in chat. Today the Advisor works from its own page (menu: Advisor) and from Chat when you
ask the Coordinator to hand work to your advisor (its tool `advisor_ask`). Typing `/advisor` needs a small addition to the
desk itself, which the lead will plan; the Advisor already declares the command in its module.json for that day.

## Opening a fresh desk for the first time

A new desk first asks who will use it (you may press "Skip, show everything") and then pairs your browser with a six-digit
code that the desk prints in its own window. Only a paired browser sees the pages.

## Where this was checked

On Linux, 22 Nov 2026, in a copy of AP Desk 0.1.1: the kit's tests, both samples' tests in the kit and in the desk, the
desk's start-up check with the samples in, switching them on and off, their pages in Chromium at 1366 and 390 px wide in
both looks. Not checked: Windows or macOS, a real model (only a stand-in model answered), a paid advisor.
