// The module check: both samples come out with no red line; every hostile module under tests/bad is red for its own reason.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { KIT, tool } from './helpers/run.mjs';
import { makeZip } from './helpers/zip-writer.mjs';
import { checkModule } from '../tools/check-module.mjs';
import { copyFolder } from '../tools/lib/files.mjs';
import { REFUSED, MARKED } from '../tools/lib/hostile.mjs';

const reds = (rep) => rep.sections.flatMap((s) => s.lines).filter((l) => l.level === 'red').map((l) => l.text);

test('both samples: no red line, and the report ends with the honest paragraph', async () => {
  for (const s of ['hello-notes', 'advisor']) {
    const r = tool('check-module.mjs', [path.join(KIT, 'samples', s), '--run']);
    assert.equal(r.code, 0, r.out);
    assert.match(r.out, /Result: no red line/);
    assert.match(r.out, /Its own tests pass in the stand-in desk, in the same locked-down process: \d+ passed/);
    assert.match(r.out, /It switches off, and nothing it started ran in the 1\.5 seconds after\./);
    assert.match(r.out, /It cannot prove that code is harmless/); assert.match(r.out, /run a program from\.\n*$/);
  }
});

// the one hostile list, shared with the desk (tools/lib/hostile.mjs is a copy of app/core/module-check/hostile.mjs)
const BAD = REFUSED;
for (const [name, why] of Object.entries(MARKED)) {
  test(`hostile module ${name} is marked with a yellow line`, async () => {
    const rep = await checkModule(path.join(KIT, 'tests', 'bad', name), { run: false });
    assert.ok(rep.sections.flatMap((s) => s.lines).some((l) => l.level === 'yellow' && why.test(l.text)), name);
  });
}
for (const [name, why] of Object.entries(BAD)) {
  test(`hostile module ${name} is red for the right reason`, async () => {
    const rep = await checkModule(path.join(KIT, 'tests', 'bad', name), { run: false });
    assert.ok(rep.red > 0, `${name} should have a red line`);
    assert.ok(reds(rep).some((t) => why.test(t)), `${name}: ${reds(rep).join(' | ')}`);
  });
}

test('the command exits 1 on a red line', () => {
  const r = tool('check-module.mjs', [path.join(KIT, 'tests', 'bad', 'bad-eval')]);
  assert.equal(r.code, 1); assert.match(r.out, /Do not add this module as it is\./);
});

test('shape: a taken id, number or official place, core kind and an id that does not match its folder are red', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-shape-'));
  try {
    const d = path.join(tmp, 'mail'); fs.mkdirSync(d);
    fs.writeFileSync(path.join(d, 'module.json'), JSON.stringify({ id: 'mail', number: 17, name: 'M', description: 'A module that takes names the desk already uses.', kind: 'core', status: 'works', menu: [{ id: 'chat', label: 'Chat' }], pages: [] }));
    const rep = await checkModule(d, { run: false });
    const r = reds(rep).join(' | ');
    assert.match(r, /already a module of the desk/); assert.match(r, /number 17 is already used/); assert.match(r, /cannot be "core"/); assert.match(r, /official places/);
    const e = path.join(tmp, 'other-name'); copyFolder(path.join(KIT, 'samples', 'hello-notes'), e);
    assert.match(reds(await checkModule(e, { run: false })).join(' '), /folder is called "other-name" but the id is "hello-notes"/);
    const h = path.join(tmp, 'hello-notes'); copyFolder(path.join(KIT, 'samples', 'hello-notes'), h);
    fs.writeFileSync(path.join(h, '.hidden'), 'x'); fs.symlinkSync('/etc/hostname', path.join(h, 'link.md'));
    fs.mkdirSync(path.join(h, 'node_modules')); fs.writeFileSync(path.join(h, 'node_modules', 'x.js'), '');
    fs.writeFileSync(path.join(h, 'run.exe'), 'MZ');
    const r2 = reds(await checkModule(h, { run: false })).join(' | ');
    assert.match(r2, /hidden file/); assert.match(r2, /is a link/); assert.match(r2, /node_modules folder/); assert.match(r2, /may hold only js, mjs, json, md, css, svg and png/);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('a zip is checked like a folder, and a zip entry that climbs out is refused', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-zip-'));
  try {
    const dir = path.join(KIT, 'samples', 'hello-notes');
    const entries = fs.readdirSync(dir).map((f) => ({ name: 'hello-notes/' + f, data: fs.readFileSync(path.join(dir, f)) }));
    fs.writeFileSync(path.join(tmp, 'good.zip'), makeZip(entries));
    const ok = tool('check-module.mjs', [path.join(tmp, 'good.zip'), '--no-run']);
    assert.equal(ok.code, 0, ok.out); assert.match(ok.out, /Hello notes \(hello-notes\)/);
    fs.writeFileSync(path.join(tmp, 'bad.zip'), makeZip([...entries, { name: 'hello-notes/../../evil.js', data: 'x' }]));
    const bad = tool('check-module.mjs', [path.join(tmp, 'bad.zip')]);
    assert.equal(bad.code, 1); assert.match(bad.out, /would be written outside the folder/);
    assert.ok(!fs.existsSync(path.join(os.tmpdir(), 'evil.js')));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('the reviewer\'s other tricks: the lexer reads {} / 2 as Node does; css, the harness name and a built SQL table name are named', async () => {
  const lines = async (n) => (await checkModule(path.join(KIT, 'tests', 'bad', n))).sections.flatMap((s) => s.lines).map((l) => l.level + ' ' + l.text).join(' | ');
  const lx = await lines('bad-lexer');
  assert.match(lx, /red [^|]*calls fetch directly/); assert.match(lx, /red [^|]*outside host evil\.example/);
  assert.match(await lines('bad-ui-image'), /red style\.css line 1: loads https:\/\/evil\.example\/pixel\.png/);
  assert.match(await lines('bad-detects-check'), /red [^|]*reads APD_KIT_HARNESS, which only the kit's stand-in desk sets/);
  assert.match(await lines('bad-sql-built'), /yellow [^|]*a table name built at run time\): SQL the checker cannot read\. The desk itself does not stop/);
});

test('host scan: address-like words in a sentence are not hosts, a test file\'s host is only noted, and "*" reads any address', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-hosts-'));
  try {
    const d = path.join(tmp, 'reading-list');
    fs.mkdirSync(d);
    fs.writeFileSync(path.join(d, 'module.json'), JSON.stringify({ id: 'reading-list', number: 70, name: 'Reading list', description: 'Saves links the owner types in and reads each page once.', kind: 'switch-on', status: 'partial', tools: [], hosts: ['*'] }));
    fs.writeFileSync(path.join(d, 'server.js'), "export async function activate(ctx) {\n  const why = 'Give an address that starts with https:// or http://.';\n  ctx.route('GET', '/x', async (req, res) => { try { await ctx.fetch(String(req.url)); } catch {} ctx.json(res, { why }); });\n  return { deactivate() {} };\n}\n");
    fs.writeFileSync(path.join(d, 'reading-list.test.js'), "import test from 'node:test';\ntest('x', () => { const u = 'https://other.test/page'; return u; });\n");
    const all = (await checkModule(d)).sections.flatMap((s) => s.lines);
    assert.equal(all.filter((l) => l.level === 'red').length, 0, JSON.stringify(all.filter((l) => l.level === 'red')));
    assert.ok(all.some((l) => l.level === 'info' && /a test names other\.test/.test(l.text)));
    assert.ok(all.some((l) => l.level === 'yellow' && /It may reach any address \("hosts": \["\*"\]\)/.test(l.text)));
    fs.writeFileSync(path.join(d, 'module.json'), JSON.stringify({ id: 'reading-list', number: 70, name: 'Reading list', description: 'Saves links the owner types in and reads each page once.', kind: 'switch-on', status: 'partial', tools: [], hosts: ['example.com'] }));
    fs.writeFileSync(path.join(d, 'server.js'), "export async function activate(ctx) { const u = 'https://news.example.org/a'; return { u, deactivate() {} }; }\n");
    const r = (await checkModule(d)).sections.flatMap((s) => s.lines).filter((l) => l.level === 'red').map((l) => l.text).join(' ');
    assert.match(r, /outside host news\.example\.org.*\. Declare it; or, if this is not an address the module calls \(a sentence on screen, say\), reword it/);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('folders nested too deep are red; a zip with two entries of one name says so in a sentence, and leaves no temp folder', async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-deep-'));
  try {
    const d = path.join(tmp, 'hello-notes'); copyFolder(path.join(KIT, 'samples', 'hello-notes'), d);
    const deep = path.join(d, ...Array(10).fill('a')); fs.mkdirSync(deep, { recursive: true }); fs.writeFileSync(path.join(deep, 'x.md'), 'x');
    assert.match(reds(await checkModule(d)).join(' '), /folders nested 9 deep; at most 8/);
    const own = path.join(tmp, 'own-tmp'); fs.mkdirSync(own);
    fs.writeFileSync(path.join(tmp, 'dup.zip'), makeZip([{ name: 'z1/module.json', data: '{}' }, { name: 'z1/server.js', data: 'a' }, { name: 'z1/server.js', data: 'b' }]));
    const r = tool('check-module.mjs', [path.join(tmp, 'dup.zip')], { env: { TMPDIR: own, TEMP: own, TMP: own } });
    assert.equal(r.code, 1); assert.match(r.out, /the zip holds two entries named "z1\/server\.js"/); assert.doesNotMatch(r.out, /EEXIST/);
    assert.deepEqual(fs.readdirSync(own), [], 'no temp folder left behind');
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('a bad --key gives one plain sentence; the closing paragraph is printed every time, --json included', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-key-'));
  try {
    fs.writeFileSync(path.join(tmp, 'x.key'), '-----BEGIN PRIVATE KEY-----\nnot really\n-----END PRIVATE KEY-----\n');
    for (const k of [path.join(tmp, 'x.key'), path.join(tmp, 'missing.pub.json')]) {
      const r = tool('check-module.mjs', [path.join(KIT, 'samples', 'hello-notes'), '--key', k]);
      assert.equal(r.code, 2); assert.match(r.out, /That is not a public key file \(.*\)\. Give the file that ends in \.pub\.json, never the \.key file\./);
      assert.doesNotMatch(r.out, /SyntaxError|ENOENT|\n\s+at /); assert.match(r.out, /run a program from\./);
    }
    const j = tool('check-module.mjs', [path.join(KIT, 'tests', 'bad', 'bad-builtins'), '--json']);
    assert.match(j.out, /run a program from\./); assert.equal(j.code, 1);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});
