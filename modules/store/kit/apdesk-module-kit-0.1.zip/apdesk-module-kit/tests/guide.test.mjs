// The guide cannot drift from the samples: every line of a code block marked "from samples/..." is in that file,
// and every "samples/<x> line N" reference points at a line that holds the words quoted beside it.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { KIT } from './helpers/run.mjs';

const guide = fs.readFileSync(path.join(KIT, 'GUIDE.md'), 'utf8');

test('every code block taken from a sample matches the sample, line by line', () => {
  const blocks = [...guide.matchAll(/<!-- from (samples\/[^ ]+) -->\n```\w*\n([\s\S]*?)```/g)];
  assert.ok(blocks.length >= 20, `found ${blocks.length} blocks`);
  for (const [, file, body] of blocks) {
    const src = fs.readFileSync(path.join(KIT, file), 'utf8').split('\n').map((l) => l.trim());
    for (const line of body.split('\n').map((l) => l.trim()).filter(Boolean)) assert.ok(src.includes(line), `${file} has no line: ${line}`);
  }
});

test('line references point at the quoted code', () => {
  const refs = [...guide.matchAll(/\(`([^`]+)` at (samples\/[^ ]+) line (\d+)\)/g)];
  assert.ok(refs.length >= 15, `found ${refs.length} references`);
  for (const [, quote, file, n] of refs) {
    const line = fs.readFileSync(path.join(KIT, file), 'utf8').split('\n')[Number(n) - 1] || '';
    assert.ok(line.includes(quote), `${file} line ${n} does not hold ${quote}: ${line.trim()}`);
  }
});

test('START-HERE says what the check does and does not do, in true words', () => {
  const t = fs.readFileSync(path.join(KIT, 'START-HERE.md'), 'utf8');
  for (const untrue of [/changes nothing/, /stand-in desk with no network/, /key you sign desk\s+updates with works too/]) assert.doesNotMatch(t, untrue);
  for (const must of [/It does not run the module's code/, /--yes/, /--run/, /fingerprint/, /by another way/, /never the `\.key` file/, /does\s+not stop one module from reading another module's tables/, /list of English words/, /<id>\.old-<date>/]) assert.match(t, must);
});
