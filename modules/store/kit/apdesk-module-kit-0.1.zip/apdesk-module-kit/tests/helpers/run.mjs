// Run one of the kit's tools as the owner would, and keep what it printed.
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
export const KIT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const tool = (name, args = [], opts = {}) => {
  const r = spawnSync(process.execPath, [path.join(KIT, 'tools', name), ...args], { encoding: 'utf8', cwd: opts.cwd || KIT, input: opts.input, env: { ...process.env, ...(opts.env || {}) }, timeout: 240000 });
  return { code: r.status, out: (r.stdout || '') + (r.stderr || '') };
};
