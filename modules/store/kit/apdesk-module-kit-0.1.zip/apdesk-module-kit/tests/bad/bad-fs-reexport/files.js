export * from 'node:fs';
