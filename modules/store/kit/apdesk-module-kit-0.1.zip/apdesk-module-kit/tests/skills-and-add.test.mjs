// Skills (check and import, nothing run) and adding a module to a desk folder.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { KIT, tool } from './helpers/run.mjs';
import { makeZip } from './helpers/zip-writer.mjs';
import { checkSkill, deskSkill } from '../tools/lib/skill.mjs';
import { install, oldName } from '../tools/add-module.mjs';
import { hashFolder } from '../tools/lib/sig.mjs';
import { SKILLS } from '../tools/lib/hostile.mjs';

test('the honest example skill has no red line', () => {
  const r = checkSkill(path.join(KIT, 'samples', 'skill-example'));
  assert.equal(r.red, 0, JSON.stringify(r.lines)); assert.equal(r.title, 'Compare supplier quotes');
});

test('the bad example trips every check, each with its line', () => {
  const r = checkSkill(path.join(KIT, 'samples', 'skill-bad-example'));
  const text = r.lines.map((l) => `${l.level}: ${l.text}`).join('\n');
  for (const re of [/red: Line 9 acts without asking the owner/, /red: Line 10 tells the agent to ignore earlier instructions/, /red: Line 11 changes the desk's settings or safety/, /red: Line 12 reveals keys/, /red: Line 13 fetches an address and follows what it says/, /red: Line 15 holds invisible/, /red: Line 16 mixes letters from another alphabet/, /red: Line 17 hides text in an HTML comment/, /yellow: Left out: scripts\/setup\.sh\. The desk does not run files that come with a skill\. Line 14 mentions it/]) assert.match(text, re);
});

// the one hostile list, shared with the desk
for (const [name, why] of Object.entries(SKILLS)) test(`hostile skill ${name} is red for the right reason`, () => {
  const r = checkSkill(path.join(KIT, 'tests', 'bad', 'skills', name));
  assert.ok(r.lines.some((l) => l.level === 'red' && why.test(l.text)), r.lines.map((l) => l.level + ' ' + l.text).join('\n'));
});

test('the skill report opens with what the check is, and import takes out every hidden character', () => {
  const r = tool('check-skill.mjs', [path.join(KIT, 'samples', 'skill-example')]);
  assert.match(r.out.split('\n').slice(0, 4).join(' '), /a list of English words and phrases, read line by line and paragraph by paragraph\. It misses other languages/);
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-strip-'));
  try {
    const f = path.join(tmp, 'tidy.md');
    fs.writeFileSync(f, '---\nname: tidy\ndescription: Use when tidying a list.\n---\n# Tidy\n\n1. Sort the list.\u00AD\n2. Remove repeats.\u200B\u{E0041}\n');
    const k = checkSkill(f); assert.ok(k.red > 0, 'hidden characters are red');
    const d = deskSkill(k);   // what the import would write (it refuses a red skill; this shows the stripping alone)
    assert.doesNotMatch(d.body, /[\u00AD\u200B]|\u{E0041}/u); assert.match(d.body, /Sort the list\.\n2\. Remove repeats\.$/);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('a long single-file skill says where the desk will cut it', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-skill-'));
  try {
    const f = path.join(tmp, 'long.md');
    fs.writeFileSync(f, '---\nname: long-one\ndescription: Use when testing the size limit.\n---\n' + Array.from({ length: 120 }, (_, i) => `${i + 1}. Step number ${i + 1} of a very long skill text.`).join('\n'));
    const r = checkSkill(f);
    assert.match(r.lines.map((l) => l.text).join('\n'), /The text has \d+ characters; the desk keeps 4000\. It will be cut on line \d+/);
    assert.match(r.lines.map((l) => l.text).join('\n'), /a single file carries no signature/);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('import-skill writes exactly { title, body, description } and refuses a red skill', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-import-'));
  try {
    const out = path.join(tmp, 'quotes.json');
    const r = tool('import-skill.mjs', [path.join(KIT, 'samples', 'skill-example'), '--out', out]);
    assert.equal(r.code, 0, r.out);
    const j = JSON.parse(fs.readFileSync(out, 'utf8'));
    assert.deepEqual(Object.keys(j).sort(), ['body', 'description', 'title']);
    assert.equal(j.title, 'Compare supplier quotes'); assert.match(j.body, /^# Compare supplier quotes/); assert.ok(j.body.length <= 4000);
    assert.match(r.out, /Agents, open an agent, the tab "Tools and skills", press "Write a skill"/);
    const bad = tool('import-skill.mjs', [path.join(KIT, 'samples', 'skill-bad-example'), '--out', path.join(tmp, 'bad.json')]);
    assert.equal(bad.code, 1); assert.ok(!fs.existsSync(path.join(tmp, 'bad.json')));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

function fakeDesk() {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-desk-'));
  fs.mkdirSync(path.join(d, 'app'), { recursive: true }); fs.writeFileSync(path.join(d, 'app', 'server.js'), '// stand-in\n');
  fs.mkdirSync(path.join(d, 'modules'));
  return d;
}

test('add-module copies only the files the check read: a file changed after the check refuses the copy', () => {
  const desk = fakeDesk(); const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-swap-'));
  try {
    const dir = path.join(tmp, 'hello-notes'); fs.cpSync(path.join(KIT, 'samples', 'hello-notes'), dir, { recursive: true });
    const before = hashFolder(dir, '');
    fs.appendFileSync(path.join(dir, 'server.js'), '\n// changed after the check\n');   // what the reviewer's h18 did while it ran
    assert.throws(() => install(dir, 'hello-notes', desk, { hashes: before }), /Refused: server\.js changed after it was checked\. Nothing was changed in the desk\./);
    assert.ok(!fs.existsSync(path.join(desk, 'modules', 'hello-notes')));
  } finally { fs.rmSync(desk, { recursive: true, force: true }); fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('add-module: refuses red, asks about yellow, copies with --yes, keeps the old copy on --replace', () => {
  const desk = fakeDesk();
  try {
    const red = tool('add-module.mjs', [path.join(KIT, 'tests', 'bad', 'bad-eval'), '--desk', desk, '--yes']);
    assert.equal(red.code, 1); assert.match(red.out, /Not added: there is at least one red line/); assert.ok(!fs.existsSync(path.join(desk, 'modules', 'bad-eval')));
    const noTty = tool('add-module.mjs', [path.join(KIT, 'samples', 'hello-notes'), '--desk', desk], { input: 'y\n' });
    assert.equal(noTty.code, 1); assert.match(noTty.out, /run again with --yes/);
    const ok = tool('add-module.mjs', [path.join(KIT, 'samples', 'hello-notes'), '--desk', desk, '--yes']);
    assert.equal(ok.code, 0, ok.out); assert.match(ok.out, /Next: restart the desk/); assert.match(ok.out, /switch it on in Settings › Modules/);
    assert.ok(fs.existsSync(path.join(desk, 'modules', 'hello-notes', 'server.js')));
    const again = tool('add-module.mjs', [path.join(KIT, 'samples', 'hello-notes'), '--desk', desk, '--yes']);
    assert.equal(again.code, 1); assert.match(again.out, /already has a module called "hello-notes"/);
    const rep = tool('add-module.mjs', [path.join(KIT, 'samples', 'hello-notes'), '--desk', desk, '--yes', '--replace']);
    assert.equal(rep.code, 0, rep.out);
    const kept = fs.readdirSync(path.join(desk, 'modules')).find((n) => n.startsWith('hello-notes.old-'));
    assert.ok(kept); assert.ok(fs.existsSync(path.join(desk, 'modules', kept, 'module.json.old'))); assert.ok(!fs.existsSync(path.join(desk, 'modules', kept, 'module.json')), 'the old copy cannot load as a second module');
    assert.ok(fs.existsSync(path.join(desk, 'modules', kept, 'hello-notes.test.js.old')) && !fs.existsSync(path.join(desk, 'modules', kept, 'hello-notes.test.js')), 'its tests do not run in the desk');
    const notDesk = tool('add-module.mjs', [path.join(KIT, 'samples', 'hello-notes'), '--desk', os.tmpdir(), '--yes']);
    assert.equal(notDesk.code, 1); assert.match(notDesk.out, /does not look like an AP Desk folder/);
  } finally { fs.rmSync(desk, { recursive: true, force: true }); }
});

test('add-module takes a zip and refuses one with a climbing entry', () => {
  const desk = fakeDesk(); const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-addzip-'));
  try {
    const dir = path.join(KIT, 'samples', 'advisor');
    const entries = fs.readdirSync(dir).map((f) => ({ name: 'advisor/' + f, data: fs.readFileSync(path.join(dir, f)) }));
    fs.writeFileSync(path.join(tmp, 'advisor.zip'), makeZip(entries));
    const ok = tool('add-module.mjs', [path.join(tmp, 'advisor.zip'), '--desk', desk, '--yes']);
    assert.equal(ok.code, 0, ok.out); assert.ok(fs.existsSync(path.join(desk, 'modules', 'advisor', 'module.json')));
    fs.writeFileSync(path.join(tmp, 'evil.zip'), makeZip([{ name: 'x/module.json', data: '{}' }, { name: 'x/../../../escaped.js', data: 'x' }]));
    const bad = tool('add-module.mjs', [path.join(tmp, 'evil.zip'), '--desk', desk, '--yes']);
    assert.equal(bad.code, 1); assert.match(bad.out, /outside the folder/);
  } finally { fs.rmSync(desk, { recursive: true, force: true }); fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('the kept copy gets a new name each time', () => {
  const desk = fakeDesk();
  try {
    const m = path.join(desk, 'modules'); const day = new Date('2026-11-22T10:00:00Z');
    assert.equal(oldName(m, 'advisor', day), 'advisor.old-2026-11-22');
    fs.mkdirSync(path.join(m, 'advisor.old-2026-11-22'));
    assert.equal(oldName(m, 'advisor', day), 'advisor.old-2026-11-22-2');
    assert.throws(() => install(path.join(KIT, 'samples', 'advisor'), 'advisor', desk, {}) && install(path.join(KIT, 'samples', 'advisor'), 'advisor', desk, {}), /already has a module called "advisor"/);
  } finally { fs.rmSync(desk, { recursive: true, force: true }); }
});
