// The "Runs clean" step: the module's code runs only in a separate, locked-down Node process (tools/lib/sandbox.mjs),
// never in the checker's own; and it is off unless --run is given.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import net from 'node:net';
import path from 'node:path';
import { KIT, tool } from './helpers/run.mjs';
import { prepare, runOnceLocked, runTestsLocked } from '../tools/lib/sandbox.mjs';
import { copyFolder } from '../tools/lib/files.mjs';

test('a module run in the locked-down process cannot start a program, write or read outside, open a socket or see the environment', async () => {
  const seen = []; const server = net.createServer((s) => s.on('data', (d) => seen.push(String(d)))).listen(0, '127.0.0.1');
  await new Promise((r) => server.on('listening', r));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-sbx-')); const dir = path.join(tmp, 'run-powers');
  copyFolder(path.join(KIT, 'tests', 'bad', 'run-powers'), dir);
  fs.writeFileSync(path.join(dir, 'port.json'), JSON.stringify({ port: server.address().port }));
  const box = prepare(dir, 'run-powers');
  const secret = path.resolve(box.moduleDir, '..', '..', '..', '..', 'apd-kit-secret-run.txt'); fs.writeFileSync(secret, 'secret');
  try {
    const r = runOnceLocked(box);
    const line = r.lines.find((l) => /REPORT/.test(l.text)); assert.ok(line, JSON.stringify(r.lines));
    const got = JSON.parse(line.text.slice(line.text.indexOf('REPORT ') + 7));
    assert.equal(got.program, 'ERR_ACCESS_DENIED');
    assert.equal(got.write, 'ERR_ACCESS_DENIED'); assert.ok(!fs.existsSync(path.resolve(box.moduleDir, '..', '..', '..', '..', 'apd-kit-canary-run.txt')));
    assert.equal(got.read, 'ERR_ACCESS_DENIED');
    assert.match(got.net, /No network during the check/); assert.match(String(got.fetch), /No network during the check/);
    await new Promise((res) => setTimeout(res, 200)); assert.deepEqual(seen, [], 'nothing reached the listener');
    assert.deepEqual(got.env.split(',').filter((k) => !['TEMP', 'TMP', 'TMPDIR', 'SystemRoot'].includes(k)), [], 'a bare environment');
  } finally { box.cleanup(); fs.rmSync(secret, { force: true }); fs.rmSync(tmp, { recursive: true, force: true }); server.close(); }
});

test('the module\'s own tests run locked down too, one process per test file', () => {
  // the test file is kept as locked.check.js so the kit's own `node --test` does not run it; here it becomes a module test
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-env-')); const dir = path.join(tmp, 'run-env');
  copyFolder(path.join(KIT, 'tests', 'bad', 'run-env'), dir); fs.renameSync(path.join(dir, 'locked.check.js'), path.join(dir, 'run-env.test.js'));
  const box = prepare(dir, 'run-env');
  try { const t = runTestsLocked(box); assert.equal(t.fail, 0, JSON.stringify(t.files)); assert.equal(t.pass, 1); }
  finally { box.cleanup(); fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('something still running after switch-off is red, and the check still ends (the process is ended)', () => {
  const t0 = Date.now();
  const r = tool('check-module.mjs', [path.join(KIT, 'tests', 'bad', 'run-timer-chain'), '--run']);
  assert.equal(r.code, 1, r.out); assert.match(r.out, /After it was switched off, something it started is still running/);
  assert.ok(Date.now() - t0 < 60000);
  const r2 = tool('check-module.mjs', [path.join(KIT, 'tests', 'bad', 'bad-timer'), '--run']);
  assert.equal(r2.code, 1, r2.out); assert.match(r2.out, /still running/);
});

test('without --run the module\'s code is never loaded: the checker only reads files', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-norun-')); const dir = path.join(tmp, 'hello-notes');
  try {
    copyFolder(path.join(KIT, 'samples', 'hello-notes'), dir);
    // a line that would leave a mark if activate() ran in the checker's process
    const f = path.join(dir, 'server.js'); fs.writeFileSync(f, fs.readFileSync(f, 'utf8').replace('export async function activate(ctx) {', 'export async function activate(ctx) {\n  await writeFile(ctx.dir + \'/ran.md\', \'ran\');'));
    const r = tool('check-module.mjs', [dir]);
    assert.match(r.out, /Not run\. Add --run/); assert.ok(!fs.existsSync(path.join(dir, 'ran.md')));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});
