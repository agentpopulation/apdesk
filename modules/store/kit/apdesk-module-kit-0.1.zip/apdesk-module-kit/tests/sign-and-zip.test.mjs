// Signing (same key format as the desk's update keys) and the zip reader, including Windows-style names and paths.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { KIT, tool } from './helpers/run.mjs';
import { makeZip } from './helpers/zip-writer.mjs';
import { safeEntryName, readZip, unzipTo } from '../tools/lib/zip.mjs';
import { copyFolder, deskModulesDir } from '../tools/lib/files.mjs';
import { verifyFolder } from '../tools/lib/sig.mjs';

test('make keys, sign, verify: signed and unchanged; unknown key is yellow; a changed or added file is red', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-sign-'));
  try {
    const key = path.join(tmp, 'me.key');
    const mk = tool('make-module-keys.mjs', [key, '--id', 'test-key']);
    assert.equal(mk.code, 0, mk.out); assert.ok(fs.existsSync(key + '.pub.json'));
    assert.equal(tool('make-module-keys.mjs', [path.join(KIT, 'x.key')]).code, 1, 'refuses a key inside the kit');
    const dir = path.join(tmp, 'hello-notes'); copyFolder(path.join(KIT, 'samples', 'hello-notes'), dir);
    const s = tool('sign-module.mjs', [dir, '--key', key, '--publisher', 'Test Publisher']);
    assert.equal(s.code, 0, s.out); assert.match(s.out, /Signed 5 files of hello-notes as Test Publisher \(key test-key\)/);
    const good = tool('check-module.mjs', [dir, '--key', key + '.pub.json', '--no-run']);
    assert.match(good.out, /ok {5}Signed with the key you gave \(fingerprint [0-9a-f]{4}( [0-9a-f]{4}){7}\), files unchanged since signing\. The name in the signature, "Test Publisher", is what the signer typed/);
    const unknown = tool('check-module.mjs', [dir, '--no-run']);
    assert.match(unknown.out, /YELLOW Signed with a key you have not said you trust \(fingerprint [0-9a-f ]{39}; the signer typed the name "Test Publisher"\)\. Files unchanged since signing\. A key that came in the same zip or message proves nothing/);
    fs.appendFileSync(path.join(dir, 'ui.js'), '\n// changed\n');
    const changed = tool('check-module.mjs', [dir, '--key', key + '.pub.json', '--no-run']);
    assert.equal(changed.code, 1); assert.match(changed.out, /RED {4}A file changed after signing: ui\.js/);
    fs.writeFileSync(path.join(dir, 'ui.js'), fs.readFileSync(path.join(KIT, 'samples', 'hello-notes', 'ui.js')));
    fs.writeFileSync(path.join(dir, 'extra.md'), 'added later');
    assert.match(tool('check-module.mjs', [dir, '--key', key + '.pub.json', '--no-run']).out, /A file was added after signing: extra\.md/);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('a key made the way the desk makes its update keys signs a module, and the desk-style key list verifies it', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-deskkey-'));
  try {
    // the desk's tools/make-update-keys.mjs: generateKeyPairSync('ed25519'), private PKCS#8 PEM, public { id, added, publicKey: SPKI DER base64 }
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    fs.writeFileSync(path.join(tmp, 'release.key'), privateKey.export({ type: 'pkcs8', format: 'pem' }));
    fs.writeFileSync(path.join(tmp, 'update-keys.json'), JSON.stringify({ keys: [{ id: 'apdesk-2026-11-22', added: '2026-11-22', publicKey: publicKey.export({ type: 'spki', format: 'der' }).toString('base64') }] }));
    const dir = path.join(tmp, 'advisor'); copyFolder(path.join(KIT, 'samples', 'advisor'), dir);
    assert.equal(tool('sign-module.mjs', [dir, '--key', path.join(tmp, 'release.key'), '--publisher', 'The owner', '--id', 'apdesk-2026-11-22']).code, 0);
    const v = verifyFolder(dir, JSON.parse(fs.readFileSync(path.join(tmp, 'update-keys.json'), 'utf8')).keys);
    assert.equal(v.state, 'signed', v.line);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('zip names: Windows-style and climbing names are refused, plain ones pass', () => {
  for (const bad of ['../evil.js', 'a/../../evil.js', '..\\evil.js', 'a\\..\\..\\evil.js', 'C:\\Windows\\evil.js', 'C:/evil.js', '/etc/evil', 'x/..']) assert.equal(safeEntryName(bad), false, bad);
  for (const ok of ['hello-notes/module.json', 'ui/part.js', 'a..b.md', 'README.md']) assert.equal(safeEntryName(ok), true, ok);
});

test('zip reader: stored and deflated entries read back; links, other methods and climbing entries are refused', () => {
  const z = makeZip([{ name: 'm/a.txt', data: 'stored', method: 0 }, { name: 'm/b.txt', data: 'deflated '.repeat(50) }]);
  const e = readZip(z);
  assert.equal(e.find((x) => x.name === 'm/a.txt').data.toString(), 'stored');
  assert.equal(e.find((x) => x.name === 'm/b.txt').data.toString(), 'deflated '.repeat(50));
  assert.throws(() => readZip(makeZip([{ name: 'm/l', data: '/etc/passwd', method: 0, link: true }])), /is a link/);
  assert.throws(() => readZip(makeZip([{ name: 'm/x', data: 'x', method: 12 }])), /packing method this tool does not read \(12\)/);
  assert.throws(() => readZip(makeZip([{ name: '..\\..\\x.js', data: 'x', method: 0 }])), /outside the folder/);
  assert.throws(() => readZip(Buffer.from('not a zip at all, just text')), /not a zip file/);
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-unzip-'));
  try { const r = unzipTo(z, path.join(tmp, 'out')); assert.equal(r.folder, 'm'); assert.equal(fs.readFileSync(path.join(tmp, 'out', 'a.txt'), 'utf8'), 'stored'); }
  finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});

test('the --desk path works for Windows and for other systems', () => {
  assert.equal(deskModulesDir('C:\\apdesk', path.win32), 'C:\\apdesk\\modules');
  assert.equal(deskModulesDir('D:\\Tools\\AP Desk\\', path.win32), 'D:\\Tools\\AP Desk\\modules');
  assert.equal(deskModulesDir('/home/me/apdesk', path.posix), '/home/me/apdesk/modules');
  assert.throws(() => deskModulesDir(''), /Say where the desk is/);
});
