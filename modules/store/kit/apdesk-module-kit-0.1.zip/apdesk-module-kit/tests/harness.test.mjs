// The stand-in desk refuses what the real desk refuses, where a module would notice the difference.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { KIT } from './helpers/run.mjs';
import { openHost } from '../tools/harness.mjs';

const dir = path.join(KIT, 'samples', 'hello-notes');

test('ctx: core tables, reserved events, escaping paths and a second statement are refused', async () => {
  const h = await openHost({ dir });
  try {
    const { ctx } = h;
    assert.throws(() => ctx.db.all('SELECT * FROM secrets'), /not allowed for a module \(table secrets\)/);
    assert.throws(() => ctx.db.run("INSERT INTO jobs (id) VALUES ('x')"), /table jobs is read-only/);
    assert.equal(ctx.db.all('SELECT COUNT(*) AS n FROM calls')[0].n, 0, 'reading the calls table is allowed');
    assert.throws(() => ctx.db.run('SELECT 1; SELECT 2'), /one statement at a time/);
    assert.throws(() => ctx.db.exec('CREATE TRIGGER t AFTER INSERT ON m_hello_notes_notes BEGIN SELECT 1; END'), /triggers and views/);
    assert.throws(() => ctx.events.emit('approval', {}), /Only the core emits 'approval' events/);
    assert.throws(() => ctx.events.emit('two words', {}), /one plain word/);
    assert.throws(() => ctx.workspacePath('..', 'x'), /escapes the workspace/);
    assert.ok(ctx.workspacePath('reports', 'a.md').startsWith(h.workspace));
    assert.throws(() => ctx.tool({ name: 'x' }), /needs name and run/);
  } finally { await h.close(); }
});

test('ctx.fetch is refused unless the test allows the host; Offline and Panic refuse it too', async () => {
  const h = await openHost({ dir, allowHosts: ['api.example.com'], fetchImpl: async (u) => new Response(JSON.stringify({ host: u.hostname })) });
  try {
    await assert.rejects(h.ctx.fetch('https://other.example.com/'), /does not reach other\.example\.com/);
    assert.deepEqual(await (await h.ctx.fetch('https://api.example.com/x')).json(), { host: 'api.example.com' });
    h.setSetting('online', false);
    await assert.rejects(h.ctx.fetch('https://api.example.com/x'), /offline/);
    h.setSetting('online', true); await h.panic();
    await assert.rejects(h.ctx.fetch('https://api.example.com/x'), /Everything is stopped/);
  } finally { await h.close(); }
});

test('model door: names the model, refuses online picks while Offline, refuses paid models of the model-router provider, stops on Panic', async () => {
  const h = await openHost({ dir, script: () => 'hi', localModels: [{ name: 'big-local:14b', parameters: '14.8B' }, { name: 'tiny-local:3b', parameters: '3.2B' }] });
  try {
    const m = h.ctx.model;
    const r = await m.chat({ messages: [{ role: 'user', content: 'x' }] });
    assert.equal(r.label, 'Free API · fake-model'); assert.equal(r.provider, 'router');
    const small = await m.chat({ model: { provider: 'ollama', model: 'tiny-local:3b' }, messages: [] });
    assert.equal(small.small, true, 'a small local model is marked');
    h.setSetting('online', false);
    await assert.rejects(m.chat({ model: { provider: 'router', model: null }, messages: [] }), (e) => e.code === 'offline');
    assert.equal((await m.chat({ messages: [] })).provider, 'ollama', 'Offline: only local models answer');
    h.setSetting('online', true);
    await assert.rejects(m.chat({ model: { provider: 'openrouter', model: 'big/paid' }, messages: [] }), /not available|Paid models of the model-router provider/);
    await h.panic();
    await assert.rejects(m.chat({ messages: [] }), (e) => e.code === 'halted');
  } finally { await h.close(); }
});

test('approval door: send.person always asks; assertGranted holds the exact payload, once', async () => {
  const h = await openHost({ dir });
  try {
    h.answer = 'approve';
    const d = await h.ctx.approval.request({ action: 'send.person', title: 'Mail Asha', payload: { to: 'a@example.com', body: 'hi' } });
    assert.equal(d.ok, true); assert.equal(d.how, 'owner');
    assert.throws(() => h.ctx.approval.assertGranted(d.id, 'send.person', { to: 'b@example.com', body: 'hi' }), /not the item the owner approved/);
    assert.equal(h.ctx.approval.assertGranted(d.id, 'send.person', { to: 'a@example.com', body: 'hi' }), true);
    assert.throws(() => h.ctx.approval.assertGranted(d.id, 'send.person', { to: 'a@example.com', body: 'hi' }), /No approval was granted/);
    assert.equal((await h.ctx.approval.request({ action: 'net.post', title: 'x' })).how, 'level', 'Open allows net.post');
    assert.equal((await h.ctx.approval.request({ action: 'x', title: 'x', payload: 'y'.repeat(300 * 1024) })).reason, 'too_large');
  } finally { await h.close(); }
});

test('the two samples carry the same test host, unchanged', () => {
  const a = fs.readFileSync(path.join(KIT, 'samples', 'hello-notes', 'testhost.js'), 'utf8');
  assert.equal(fs.readFileSync(path.join(KIT, 'samples', 'advisor', 'testhost.js'), 'utf8'), a);
});
