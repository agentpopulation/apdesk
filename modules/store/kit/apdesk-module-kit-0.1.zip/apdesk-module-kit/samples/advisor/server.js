// Advisor: a big model plans and checks, a small model does the work, the owner gives the last yes.
//   1. the advisor (an online API model, free or paid, or a large local model of the 14B to 27B kind) writes a brief:
//      the goal in one line, the steps, and checks that can be answered yes or no;
//   2. a worker (a small model, 1B to 7B, or the desk's usual free chain) does the steps;
//   3. the advisor answers every check yes / no / cannot tell with a reason and gives a verdict; "needs work" gives the
//      worker one more round with the advisor's notes; two rounds at most;
//   4. the owner sees the result, the checks, who did what and the cost, and presses Accept or Send back.
// A run is done only when the advisor said "done" AND the owner pressed Accept.
// Choices are the model's (as JSON this code checks for shape) or the owner's (his picks and switches). The code never reads
// the owner's words with patterns to decide anything.
const ROUNDS_MAX = 2;
const ADVISOR_CALLS_MAX = (1 + ROUNDS_MAX) * 2;   // a brief and two reviews, each with at most one second try
const ANSWERS = ['yes', 'no', 'cannot tell'];
const VERDICTS = ['done', 'needs work'];
const LOCAL = (p) => p === 'ollama' || p === 'llama' || String(p).startsWith('lan:');
const FREE_OR = (m) => /:free$/.test(String(m || '')) || m === 'openrouter/free';
const J = (x, f = null) => { try { return x ? JSON.parse(x) : f; } catch { return f; } };
const fail = (code, message) => Object.assign(new Error(message), { code });
const clean = (v, max) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);

export async function activate(ctx) {
  ctx.db.migrate(1, `CREATE TABLE IF NOT EXISTS m_advisor_runs (
    id TEXT PRIMARY KEY, task TEXT NOT NULL, parent TEXT, status TEXT NOT NULL, advisor TEXT, worker TEXT,
    brief TEXT, rounds TEXT, verdict TEXT, owner TEXT, owner_note TEXT, cost TEXT, job_id TEXT, why TEXT,
    created TEXT NOT NULL, updated TEXT NOT NULL)`);
  // a run that was working when the desk stopped is never resumed by itself
  ctx.db.run("UPDATE m_advisor_runs SET status = 'interrupted', why = 'The desk stopped while this was running.' WHERE status = 'working'");
  const mine = new Set();   // jobs this module started in this space, stopped on deactivate

  // ---------- the owner's choices (kv): which model advises, which works, and whether a paid advisor may be called
  const picks = () => ({ advisor: ctx.kv.get('advisor', null), worker: ctx.kv.get('worker', null), allowPaid: ctx.kv.get('allowPaid', false) === true });
  const tiers = () => ctx.model.providers();                     // { id: { tier: 'paid' | 'free-signup' | 'custom' } }
  const ownerMark = (p) => {                                       // the owner's own word on his key: 'free' | 'paid' | null
    const ks = (ctx.model.keys.list()[p] || []).filter((k) => k.enabled);
    return ks.some((k) => k.meta?.tier === 'paid') ? 'paid' : ks.length && ks.every((k) => k.meta?.tier === 'free') ? 'free' : null;
  };
  /** What a pick costs, as far as the desk can know: local, free, paid, or maybe (billing depends on the owner's account). */
  function kindOf(pick) {
    if (!pick?.provider) return null;
    const p = pick.provider;
    if (LOCAL(p)) return 'local';
    if (p === 'router') return 'free';
    if (p === 'openrouter') return FREE_OR(pick.model) ? 'free' : 'paid';
    const mark = ownerMark(p); if (mark) return mark;
    return tiers()[p]?.tier === 'paid' ? 'paid' : 'maybe';
  }
  /** Why this pick may not be called now, in one plain sentence; null when it may. Checked before every call. */
  function refusal(pick, role) {
    if (!pick?.provider) return role === 'advisor' ? 'Choose your advisor first, on the Advisor page.' : null;
    const kind = kindOf(pick);
    if (ctx.settings.get('online') === false && kind !== 'local') return `The desk is offline and your ${role} is an online model. Choose a local model or go online.`;
    if (kind !== 'paid' && kind !== 'maybe') return null;
    // a "maybe" (billing depends on the owner's account) is treated as paid: it needs the same switch
    if (!picks().allowPaid) return kind === 'maybe' ? `Your ${role} may be billed by your account with that provider, so it is treated as paid, and paid calls are off for the Advisor. Switch them on in Settings › Advisor, or mark that key as free on the Models page.` : `Your ${role} is a paid model and paid calls are off for the Advisor. Switch them on in Settings › Advisor, or choose a free or local model.`;
    if (pick.provider === 'openrouter' && ctx.settings.get('openrouter.allowPaid') !== true) return 'Paid models of the model-router provider are switched off in the desk (Models, the Paid models switch beside its keys).';
    const st = ctx.approval.state();   // read-only: the owner's limits and what was spent, in minor units of his currency
    if (st.limits.perDay != null && st.spentToday >= st.limits.perDay) return "Today's spend limit is reached, so no paid model is called.";
    if (st.limits.perMonth != null && st.spentMonth >= st.limits.perMonth) return "This month's spend limit is reached, so no paid model is called.";
    return null;
  }
  /** The most a run's advisor calls can cost: a brief and up to two reviews, each with one second try when the answer is
   *  not in the agreed form, so up to 6 calls; priced from the desk's own record of earlier calls to that model. */
  function likelyCost(pick) {
    const kind = kindOf(pick);
    if (!kind) return null;
    if (kind === 'local' || kind === 'free') return { known: true, free: true, minor: 0 };
    const rows = (ctx.model.usage().recent || []).filter((r) => r.provider === pick.provider && (!pick.model || r.model === pick.model) && r.ok && r.cost_minor != null && r.cost_minor > 0);
    if (!rows.length) return { known: false, why: kind === 'maybe' ? 'it depends on your account with that provider' : 'there is no earlier call to this model to go by' };
    const per = rows.reduce((a, r) => a + r.cost_minor, 0) / rows.length;
    return { known: true, free: false, upTo: true, minor: Math.ceil(per * ADVISOR_CALLS_MAX), from: rows.length };
  }
  // ---------- every call of a run is counted by the row the desk wrote for that very answer (not by provider or time),
  // so a worker that ran on the desk's own chain is counted too, and another module's calls are not
  const tallyOf = () => ({ minor: 0, unknown: 0, calls: 0, currency: ctx.settings.get('currency') || null });
  async function call(tally, opts) {
    const before = ctx.model.usage().recent?.[0]?.id ?? 0;
    const r = await ctx.model.chat(opts);
    const row = (ctx.model.usage().recent || []).filter((x) => x.id > before && x.ok && x.provider === r.provider && x.model === r.model).pop();
    tally.calls++; if (row && row.cost_minor != null) tally.minor += row.cost_minor; else tally.unknown++;
    return r;
  }
  /** The worker's steps: the owner's pick; or else the desk's own chain, holding only the steps that may be called now
   *  (while paid calls are off for the Advisor: free and local ones only). Each step is then named to the door. */
  function workerSteps(worker) {
    if (worker?.provider) return [worker];
    return (ctx.model.resolve(null).chain || []).map((c) => ({ provider: c.provider, model: c.model || null })).filter((c) => !refusal(c, 'worker'));
  }
  async function askWorker(tally, worker, messages, signal) {
    const steps = workerSteps(worker); let last = null;
    if (!steps.length) throw fail('refused', 'No free or local model is set up for the worker, and paid calls are off for the Advisor. Choose a worker on the Advisor page, or set up a free or local model in Models.');
    for (const step of steps) {
      try { return await call(tally, { model: step, purpose: 'small', messages, signal, maxTokens: 2000 }); }
      catch (e) { if (signal.aborted || e.code === 'aborted' || e.code === 'halted') throw e; last = e; }
    }
    throw fail('no_worker', `No model answered for the worker: ${last?.message || 'not known why'}`);
  }

  // ---------- the prompts: built from the owner's task and the desk's settings, never from patterns on his words
  const place = () => {
    const zone = ctx.settings.get('timeZone') || 'UTC';
    const today = new Date().toLocaleDateString('en-GB', { timeZone: zone, day: 'numeric', month: 'long', year: 'numeric' });
    const company = clean(ctx.settings.get('companyName'), 120);
    return `About the owner: country ${ctx.settings.get('country') || 'not given'}, currency ${ctx.settings.get('currency') || 'not given'}, time zone ${zone}, today is ${today}.${company ? ' Business: ' + company + '.' : ''}`;
  };
  const briefPrompt = (task) => [
    { role: 'system', content: `You are the owner's advisor. A smaller model will do the work; you plan it now and check it later.
Reply with one JSON object only, in this form: {"goal": "the goal in one line", "steps": ["a step", "..."], "checks": ["a yes-or-no question about the finished work", "..."]}
Give 2 to 6 steps and 2 to 6 checks. Each check must be answerable with yes or no by reading the finished work alone.
Do not add facts the owner did not give. Where the work needs a fact nobody gave, add a step that says to write "not checked" for it.
${place()}` },
    { role: 'user', content: 'The work the owner asked for:\n' + task },
  ];
  const workPrompt = (task, brief, last) => [
    { role: 'system', content: `You do a piece of work for the owner, following the steps you are given. Write the finished work only, in plain words.
Where a fact was not given and you cannot know it, write "not checked" instead of guessing. ${place()}` },
    { role: 'user', content: `Goal: ${brief.goal}\nSteps:\n${brief.steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\nYour work will be checked against:\n${brief.checks.map((c) => '- ' + c.text).join('\n')}\nThe owner's words:\n${task}`
      + (last ? `\n\nYour last try was checked and needs work. The advisor's notes: ${last.review.notes || 'none'}\nChecks not passed: ${last.review.answers.filter((a) => a.answer !== 'yes').map((a) => brief.checks.find((c) => c.id === a.check).text + ' (' + a.reason + ')').join('; ')}\nYour last try:\n${last.text}\n\nWrite the whole work again.` : '') },
  ];
  const reviewPrompt = (brief, text) => [
    { role: 'system', content: `You are the owner's advisor. Check the finished work against each check.
Reply with one JSON object only: {"answers": [{"check": "c1", "answer": "yes" or "no" or "cannot tell", "reason": "one line"}], "verdict": "done" or "needs work", "notes": "what to fix, short; empty when done"}
Answer every check exactly once. The verdict is "done" only when every answer is yes.` },
    { role: 'user', content: `Goal: ${brief.goal}\nChecks:\n${brief.checks.map((c) => `${c.id}: ${c.text}`).join('\n')}\n\nThe finished work:\n${text}` },
  ];

  // ---------- the checks on the model's answers: code, for shape only
  function checkBrief(j) {
    if (!j || typeof j !== 'object') return { why: 'it was not a JSON object' };
    const goal = clean(j.goal, 300); if (!goal) return { why: 'the goal is missing' };
    const list = (x) => (Array.isArray(x) ? x.map((s) => clean(typeof s === 'string' ? s : s?.text, 400)).filter(Boolean) : []);
    const steps = list(j.steps), checks = list(j.checks);
    if (steps.length < 1 || steps.length > 8) return { why: `it has ${steps.length} steps; 1 to 8 are needed` };
    if (checks.length < 1 || checks.length > 8) return { why: `it has ${checks.length} checks; 1 to 8 are needed` };
    return { ok: { goal, steps, checks: checks.map((text, i) => ({ id: 'c' + (i + 1), text })) } };
  }
  function checkReview(j, brief) {
    if (!j || typeof j !== 'object' || !Array.isArray(j.answers)) return { why: 'there is no list of answers' };
    const answers = [];
    for (const c of brief.checks) {
      const mine = j.answers.filter((a) => String(a?.check || '').trim().toLowerCase() === c.id);
      if (mine.length !== 1) return { why: `check ${c.id} was answered ${mine.length} times` };
      const answer = String(mine[0].answer || '').trim().toLowerCase();
      if (!ANSWERS.includes(answer)) return { why: `check ${c.id} has the answer "${clean(answer, 30)}"; only yes, no or cannot tell` };
      const reason = clean(mine[0].reason, 300); if (!reason) return { why: `check ${c.id} has no reason` };
      answers.push({ check: c.id, answer, reason });
    }
    const verdict = String(j.verdict || '').trim().toLowerCase();
    if (!VERDICTS.includes(verdict)) return { why: 'the verdict is not "done" or "needs work"' };
    if (verdict === 'done' && answers.some((a) => a.answer !== 'yes')) return { why: 'the verdict is "done" but not every answer is yes' };
    return { ok: { answers, verdict, notes: clean(j.notes, 1000) } };
  }
  /** One JSON answer from the advisor, checked for shape; one second try with the reason, then a plain failure. */
  async function askJson(tally, pick, messages, check, signal, purpose) {
    let r = await call(tally, { model: pick, messages, json: true, purpose, signal, maxTokens: 1200 });
    let c = check(r.json);
    if (c.ok) return { value: c.ok, label: r.label };
    r = await call(tally, { model: pick, json: true, purpose, signal, maxTokens: 1200, messages: [...messages, { role: 'assistant', content: r.text }, { role: 'user', content: `That was not in the agreed form: ${c.why}. Reply again with the JSON object only.` }] });
    c = check(r.json);
    if (c.ok) return { value: c.ok, label: r.label };
    throw fail('bad_form', `The advisor did not answer in the agreed form (${c.why}), so the run stopped.`);
  }

  // ---------- runs
  const out = (r) => r && { id: r.id, task: r.task, parent: r.parent, status: r.status, advisor: J(r.advisor), worker: J(r.worker), brief: J(r.brief), rounds: J(r.rounds, []), verdict: r.verdict, owner: r.owner, ownerNote: r.owner_note, cost: J(r.cost), jobId: r.job_id, why: r.why, created: r.created, updated: r.updated, done: r.verdict === 'done' && r.owner === 'accepted' };
  const get = (id) => out(ctx.db.get('SELECT * FROM m_advisor_runs WHERE id = ?', String(id)));
  const list = () => ctx.db.all('SELECT * FROM m_advisor_runs ORDER BY created DESC LIMIT 30').map(out);
  const save = (id, patch) => {
    const cols = Object.keys(patch); if (!cols.length) return get(id);
    ctx.db.run(`UPDATE m_advisor_runs SET ${cols.map((c) => c + ' = ?').join(', ')}, updated = ? WHERE id = ?`, ...cols.map((c) => (patch[c] && typeof patch[c] === 'object' ? JSON.stringify(patch[c]) : patch[c])), new Date().toISOString(), id);
    ctx.events.emit('advisor', { id });   // the page redraws
    return get(id);
  };

  async function start(task, { parent = null, chatId = null, agentId = null } = {}) {
    const t = String(task ?? '').trim();
    if (!t) throw Object.assign(new Error('Write the work you want done first.'), { status: 400 });
    if (t.length > 4000) throw Object.assign(new Error(`The work is at most 4000 characters; this has ${t.length}.`), { status: 400 });
    const { advisor, worker } = picks();
    const id = 'run_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); const at = new Date().toISOString();
    ctx.db.run('INSERT INTO m_advisor_runs (id, task, parent, status, advisor, worker, rounds, created, updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', id, t, parent, 'working', JSON.stringify(advisor), JSON.stringify(worker), '[]', at, at);
    const no = refusal(advisor, 'advisor') || refusal(worker, 'worker');
    if (no) return save(id, { status: 'refused', why: no });   // nothing was called
    const job = await ctx.jobs.start({ kind: 'advisor.run', title: 'Advisor: ' + clean(t, 70), agentId, chatId, input: { runId: id }, run: (job) => work(id, t, job) });
    mine.add(job.id);
    return save(id, { job_id: job.id });
  }

  async function work(id, task, job) {
    const { advisor, worker } = JSON.parse(JSON.stringify(picks()));
    const tally = tallyOf(); const rounds = [];
    try {
      const gate = () => { const no = refusal(advisor, 'advisor') || refusal(worker, 'worker'); if (no) throw fail('refused', no); };
      gate(); job.progress(0.05, 'The advisor is writing the brief');
      const b = await askJson(tally, advisor, briefPrompt(task), checkBrief, job.signal, 'plan');
      const brief = { ...b.value, by: b.label };
      save(id, { brief });
      for (let n = 1; n <= ROUNDS_MAX; n++) {
        job.progress(0.15 + 0.4 * (n - 1), n === 1 ? 'The worker is doing the steps' : 'The worker is doing round 2 with the advisor\'s notes');
        gate();
        // the worker: the owner's pick, or the desk's usual chain (only its free and local steps while paid calls are off)
        const w = await askWorker(tally, worker, workPrompt(task, brief, rounds[n - 2]), job.signal);
        const round = { n, text: w.text.trim(), by: w.label, small: !!w.small };
        job.progress(0.35 + 0.4 * (n - 1), 'The advisor is checking the work');
        gate();
        const rv = await askJson(tally, advisor, reviewPrompt(brief, round.text || '(empty)'), (j) => checkReview(j, brief), job.signal, 'plan');
        round.review = { ...rv.value, by: rv.label };
        rounds.push(round);
        save(id, { rounds });
        if (round.review.verdict === 'done') break;
      }
      const last = rounds[rounds.length - 1];
      save(id, { status: 'waiting', verdict: last.review.verdict, cost: tally });
      return { runId: id, verdict: last.review.verdict, text: last.review.verdict === 'done' ? 'The advisor says done. It is waiting for your Accept.' : `The advisor says it still needs work after ${rounds.length} round${rounds.length === 1 ? '' : 's'}. It is waiting for you.` };
    } catch (e) {
      const stopped = job.signal.aborted || e.code === 'aborted' || e.code === 'halted';
      save(id, { status: stopped ? 'stopped' : e.code === 'refused' ? 'refused' : 'failed', why: stopped ? 'Stopped before it finished.' : e.message, rounds, cost: tally });
      throw e;
    } finally { mine.delete(job.id); }
  }

  // ---------- routes (owner-only where something changes)
  const own = (res, owner) => { if (owner) return false; ctx.json(res, { error: 'This is done from the desk window.' }, 403); return true; };
  const pickIn = (x) => (x == null ? null : typeof x === 'object' && typeof x.provider === 'string' && /^[a-z0-9:_-]{1,40}$/.test(x.provider) ? { provider: x.provider, model: x.model ? clean(x.model, 200) : null } : undefined);

  ctx.route('GET', '/state', async (req, res) => {
    const p = picks(); const active = await ctx.model.active();
    const sizeOf = (d) => { const b = parseFloat(String(d?.parameters || '').replace(/[^0-9.]/g, '')); return Number.isFinite(b) && b > 0 ? b : null; };
    const choices = active.map((a) => ({ provider: a.provider, label: a.shortLabel || a.label, kind: a.kind, ok: a.ok !== false, models: (a.detail || []).length ? a.detail.map((d) => ({ id: d.name, sizeB: sizeOf(d) })) : (a.models || []).map((m) => ({ id: m, sizeB: null })) }));
    const about = (pick, role) => (pick ? { pick, kind: kindOf(pick), refusal: refusal(pick, role), likelyCost: likelyCost(pick) } : null);
    ctx.json(res, { ...p, advisorInfo: about(p.advisor, 'advisor'), workerInfo: about(p.worker, 'worker'), choices, paidProviders: Object.entries(tiers()).filter(([, v]) => v.tier === 'paid').map(([k]) => k), online: ctx.settings.get('online') !== false, currency: ctx.settings.get('currency') || null, limits: ctx.approval.state().limits });
  });
  ctx.route('POST', '/settings', (req, res, { body, owner }) => {
    if (own(res, owner)) return;
    if ('advisor' in (body || {})) { const v = pickIn(body.advisor); if (v === undefined) return ctx.json(res, { error: 'That is not a model choice.' }, 400); ctx.kv.set('advisor', v); }
    if ('worker' in (body || {})) { const v = pickIn(body.worker); if (v === undefined) return ctx.json(res, { error: 'That is not a model choice.' }, 400); ctx.kv.set('worker', v); }
    if ('allowPaid' in (body || {})) { if (typeof body.allowPaid !== 'boolean') return ctx.json(res, { error: 'allowPaid is true or false.' }, 400); ctx.kv.set('allowPaid', body.allowPaid); ctx.activity(body.allowPaid ? 'Paid advisor calls switched on' : 'Paid advisor calls switched off'); }
    ctx.json(res, picks());
  });
  ctx.route('GET', '/runs', (req, res) => ctx.json(res, { runs: list() }));
  ctx.route('GET', '/runs/:id', (req, res, { params }) => { const r = get(params.id); r ? ctx.json(res, r) : ctx.json(res, { error: 'There is no such run.' }, 404); });
  ctx.route('POST', '/runs', async (req, res, { body, owner }) => {
    if (own(res, owner)) return;
    try { ctx.json(res, await start(body?.task)); } catch (e) { ctx.json(res, { error: e.message }, e.status || 500); }
  });
  ctx.route('POST', '/runs/:id/accept', (req, res, { params, owner }) => {
    if (own(res, owner)) return;
    const r = get(params.id); if (!r) return ctx.json(res, { error: 'There is no such run.' }, 404);
    if (r.status !== 'waiting') return ctx.json(res, { error: 'Only a run that is waiting for you can be accepted.' }, 409);
    const a = save(r.id, { status: 'accepted', owner: 'accepted' });
    ctx.activity('Accepted an Advisor result', clean(r.task, 200));
    ctx.json(res, { run: a, message: a.done ? 'Accepted. The advisor and you both said yes: this run is done.' : 'Accepted by you. The advisor still had doubts, so it is not marked done.' });
  });
  ctx.route('POST', '/runs/:id/sendback', async (req, res, { params, body, owner }) => {
    if (own(res, owner)) return;
    const r = get(params.id); if (!r) return ctx.json(res, { error: 'There is no such run.' }, 404);
    if (r.status !== 'waiting') return ctx.json(res, { error: 'Only a run that is waiting for you can be sent back.' }, 409);
    const note = String(body?.note ?? '').trim();
    if (!note) return ctx.json(res, { error: 'Say what to change, in a line or two.' }, 400);
    save(r.id, { status: 'sent back', owner: 'sent back', owner_note: note.slice(0, 1000) });
    try { const next = await start(`${r.task}\n\nThe owner sent the last result back with this note: ${note.slice(0, 1000)}`, { parent: r.id }); ctx.json(res, { run: next, message: 'Sent back. A new run started with your note.' }); }
    catch (e) { ctx.json(res, { error: e.message }, e.status || 500); }
  });

  // ---------- the Coordinator hands work to the advisor; typing /advisor in chat needs a desk addition (see the guide)
  ctx.tool({
    name: 'advisor_ask',
    description: 'Hand a piece of work to the owner\'s advisor: a bigger model writes a brief with yes-or-no checks, a smaller model does it, the advisor checks it, and the owner accepts it on the Advisor page.',
    parameters: { type: 'object', properties: { task: { type: 'string', description: 'the work, in the owner\'s words' } }, required: ['task'] },
    async run(args, call) {
      const r = await start(args.task, { chatId: call.chatId || null, agentId: call.agentId || null });
      return r.status === 'refused' ? { ok: false, text: r.why } : { ok: true, runId: r.id, text: 'Your advisor is on it. The result waits for your Accept on the Advisor page.' };
    },
  });
  ctx.expose({ start: (task) => start(task), get, list });

  return { async deactivate() { for (const j of mine) ctx.jobs.stop(j, 'The Advisor was switched off'); mine.clear(); } };
}
