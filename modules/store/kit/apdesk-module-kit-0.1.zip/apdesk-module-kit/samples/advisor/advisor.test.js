// Advisor: the plumbing with the fake model (brief, work, review, second round, stop after two, owner Accept and Send
// back, paid advisor refused). Runs in a real AP Desk (npm test) and in the module kit (node --test).
// The fake model answers from a script, so nothing here shows that a real advisor writes good checks: "not checked".
import test from 'node:test';
import assert from 'node:assert/strict';
import { openHost, hostKind } from './testhost.js';

const skip = hostKind ? false : 'no desk and no kit harness next to this module';
const A = '/api/m/advisor/';
const roleOf = (body) => { const s = String(body.messages?.[0]?.content || ''); return s.includes('you plan it now') ? 'brief' : s.includes('Check the finished work') ? 'review' : 'work'; };
const BRIEF = JSON.stringify({ goal: 'A short follow-up plan', steps: ['List the customers', 'Write one line each'], checks: ['Does it name three customers?', 'Is every line under 20 words?'] });
const review = (verdict, a1 = 'yes', a2 = 'yes', notes = '') => JSON.stringify({ answers: [{ check: 'c1', answer: a1, reason: 'seen in the text' }, { check: 'c2', answer: a2, reason: 'counted' }], verdict, notes });
/** A fake model that answers each kind of call from its own queue (the last answer repeats). */
function scripted(q) {
  const seen = { brief: 0, work: 0, review: 0 };
  return (body) => { const r = roleOf(body); const list = q[r] || ['FAKE']; const out = list[Math.min(seen[r], list.length - 1)]; seen[r]++; return typeof out === 'function' ? out(body) : out; };
}
async function host(q, settings) {
  const h = await openHost({ script: scripted(q), settings });
  await h.call('POST', A + 'settings', { advisor: { provider: 'router', model: null } });   // the Free API as advisor, for plumbing
  return h;
}
const run = async (h, task = 'Plan follow-ups for three customers') => {
  const r = await h.call('POST', A + 'runs', { task });
  assert.equal(r.status, 200, r.text);
  if (r.json.jobId) await h.waitJob(r.json.jobId);
  return (await h.call('GET', A + 'runs/' + r.json.id)).json;
};

test('no advisor chosen: refused in plain words, no model called', { skip }, async () => {
  const h = await openHost({ script: scripted({}) });
  try {
    const r = await h.call('POST', A + 'runs', { task: 'anything' });
    assert.equal(r.json.status, 'refused'); assert.equal(r.json.why, 'Choose your advisor first, on the Advisor page.');
    assert.equal(h.modelCalls.length, 0);
    assert.equal((await h.call('POST', A + 'runs', { task: '  ' })).status, 400);
  } finally { await h.close(); }
});

test('one round: brief, work, review "done"; waiting for the owner; Accept makes it done', { skip }, async () => {
  const h = await host({ brief: [BRIEF], work: ['Asha, Ben and Chen: call each on Monday.'], review: [review('done')] });
  try {
    const r = await run(h);
    assert.equal(r.status, 'waiting'); assert.equal(r.verdict, 'done'); assert.equal(r.done, false, 'not done before the owner says yes');
    assert.equal(r.brief.checks.length, 2); assert.deepEqual(r.brief.checks.map((c) => c.id), ['c1', 'c2']);
    assert.equal(r.rounds.length, 1); assert.match(r.rounds[0].by, /^Free API · /); assert.match(r.rounds[0].review.by, /^Free API · /);
    assert.equal(h.modelCalls.length, 3);
    assert.match(JSON.stringify(h.modelCalls[0].messages), /time zone/, 'the brief is built with the desk settings');
    const a = await h.call('POST', A + `runs/${r.id}/accept`);
    assert.equal(a.json.run.done, true); assert.match(a.json.message, /both said yes/);
    assert.equal((await h.call('POST', A + `runs/${r.id}/accept`)).status, 409, 'accepted once');
  } finally { await h.close(); }
});

test('needs work, then a second round with the advisor\'s notes', { skip }, async () => {
  const h = await host({ brief: [BRIEF], work: ['Asha only.', 'Asha, Ben and Chen.'], review: [review('needs work', 'no', 'yes', 'Name all three.'), review('done')] });
  try {
    const r = await run(h);
    assert.equal(r.rounds.length, 2); assert.equal(r.verdict, 'done'); assert.equal(r.status, 'waiting');
    const second = h.modelCalls.filter((b) => roleOf(b) === 'work')[1];
    assert.match(JSON.stringify(second.messages), /Name all three\./); assert.match(JSON.stringify(second.messages), /Asha only\./);
  } finally { await h.close(); }
});

test('stops after two rounds; Accept then is "accepted, not done"', { skip }, async () => {
  const h = await host({ brief: [BRIEF], work: ['weak'], review: [review('needs work', 'no', 'no', 'Try again.')] });
  try {
    const r = await run(h);
    assert.equal(r.rounds.length, 2); assert.equal(r.verdict, 'needs work'); assert.equal(r.status, 'waiting');
    assert.equal(h.modelCalls.length, 5, 'one brief, two works, two reviews, no more');
    const a = await h.call('POST', A + `runs/${r.id}/accept`);
    assert.equal(a.json.run.done, false); assert.match(a.json.message, /not marked done/);
  } finally { await h.close(); }
});

test('Send back needs a note and starts a new run that carries it', { skip }, async () => {
  const h = await host({ brief: [BRIEF], work: ['ok'], review: [review('done')] });
  try {
    const r = await run(h);
    assert.equal((await h.call('POST', A + `runs/${r.id}/sendback`, { note: ' ' })).status, 400);
    const s = await h.call('POST', A + `runs/${r.id}/sendback`, { note: 'Add phone numbers.' });
    assert.equal(s.status, 200); assert.equal(s.json.run.parent, r.id); assert.match(s.json.run.task, /Add phone numbers\./);
    assert.equal((await h.call('GET', A + 'runs/' + r.id)).json.status, 'sent back');
    await h.waitJob(s.json.run.jobId);
    assert.equal((await h.call('GET', A + 'runs/' + s.json.run.id)).json.status, 'waiting');
  } finally { await h.close(); }
});

test('a paid advisor is refused while paid calls are off, and never called', { skip }, async () => {
  const h = await host({});
  try {
    const paid = (await h.call('GET', A + 'state')).json.paidProviders[0];   // a provider the desk lists as always paid
    await h.call('POST', A + 'settings', { advisor: { provider: paid, model: 'a-big-paid-model' } });
    const st = (await h.call('GET', A + 'state')).json;
    assert.equal(st.advisorInfo.kind, 'paid'); assert.equal(st.advisorInfo.likelyCost.known, false); assert.match(st.advisorInfo.refusal, /paid calls are off/);
    const r = await h.call('POST', A + 'runs', { task: 'x' });
    assert.equal(r.json.status, 'refused'); assert.match(r.json.why, /paid calls are off for the Advisor/);
    await h.call('POST', A + 'settings', { allowPaid: true, advisor: { provider: 'openrouter', model: 'some/paid-model' } });
    const r2 = await h.call('POST', A + 'runs', { task: 'x' });
    assert.equal(r2.json.status, 'refused'); assert.match(r2.json.why, /Paid models of the model-router provider are switched off in the desk/);
    assert.equal(h.modelCalls.length, 0);
    assert.equal((await h.call('POST', A + 'settings', { allowPaid: 'yes' })).status, 400);
    assert.equal((await h.call('POST', A + 'settings', { allowPaid: true }, { owner: false })).status, 403);
  } finally { await h.close(); }
});

test('a brief in the wrong form gets one second try, then the run fails in plain words', { skip }, async () => {
  const h = await host({ brief: ['not json', '{"goal": "x", "steps": [], "checks": ["a"]}'] });
  try {
    const r = await run(h);
    assert.equal(r.status, 'failed'); assert.match(r.why, /did not answer in the agreed form \(it has 0 steps/);
    assert.equal(h.modelCalls.length, 2);
  } finally { await h.close(); }
  const h2 = await host({ brief: ['nonsense', BRIEF], work: ['w'], review: [JSON.stringify({ answers: [{ check: 'c1', answer: 'yes', reason: 'r' }], verdict: 'done' }), review('done')] });
  try {
    const r = await run(h2);
    assert.equal(r.status, 'waiting', r.why || ''); assert.equal(r.rounds[0].review.answers.length, 2, 'a review that skipped a check was asked again');
  } finally { await h2.close(); }
});

test('the Coordinator tool starts a run; Panic stops it', { skip }, async () => {
  const h = await host({ brief: [BRIEF], work: [{ text: 'slow', delayMs: 3000 }], review: [review('done')] });
  try {
    const t = await h.runTool('advisor_ask', { task: 'Plan follow-ups' }, { agentId: 'coordinator' });
    assert.equal(t.ok, true); assert.ok(t.runId);
    await new Promise((res) => setTimeout(res, 300));
    await h.panic();
    const r0 = (await h.call('GET', A + 'runs/' + t.runId)).json;
    await h.waitJob(r0.jobId);
    const r = (await h.call('GET', A + 'runs/' + t.runId)).json;
    assert.equal(r.status, 'stopped'); assert.equal(h.job(r.jobId).status, 'stopped');
    h.resume();
  } finally { await h.close(); }
});

// The three below need stand-in keys and prices for providers, which only the kit's harness can give (a real desk has no
// fake paid key): in a desk they are skipped, with this reason.
const harnessOnly = !hostKind ? skip : hostKind === 'desk' ? 'needs the kit harness: stand-in paid keys and prices' : false;

test('no worker picked and paid calls off: the worker never falls through to a paid key, and every call is counted', { skip: harnessOnly }, async () => {
  const q = scripted({ brief: [BRIEF], work: ['the work'], review: [review('done')] });
  // the Free API is busy for the worker's calls; the only other step is a paid key
  const h = await openHost({ keys: { 'paid-api': 1 }, prices: () => 5000, script: (b) => (roleOf(b) === 'work' ? { status: 429, text: 'busy' } : q(b)) });
  try {
    await h.call('POST', A + 'settings', { advisor: { provider: 'router', model: null }, allowPaid: false });
    const r = await run(h);
    assert.equal(h.modelCalls.filter((c) => c.provider === 'paid-api').length, 0, 'no paid call');
    assert.equal(r.status, 'failed'); assert.match(r.why, /No model answered for the worker/);
    assert.equal(r.cost.calls, 1, 'answered calls are counted (a call that failed costs nothing)'); assert.equal(r.cost.minor, 0);
  } finally { await h.close(); }
  const h2 = await openHost({ keys: { 'paid-api': 1 }, prices: () => 5000, script: q });
  try {   // with paid calls on, a picked paid worker is called and its cost is counted from the desk's own record
    await h2.call('POST', A + 'settings', { advisor: { provider: 'router', model: null }, worker: { provider: 'paid-api', model: 'small-7b' }, allowPaid: true });
    const r = await run(h2);
    assert.equal(r.status, 'waiting', r.why || ''); assert.equal(r.cost.minor, 5000); assert.equal(r.cost.unknown, 0); assert.equal(r.cost.calls, 3);
  } finally { await h2.close(); }
});

test('a provider of unknown billing ("maybe") needs the paid switch, like a paid one', { skip: harnessOnly }, async () => {
  const h = await openHost({ keys: { custom: 1 }, script: scripted({ brief: [BRIEF], work: ['w'], review: [review('done')] }) });
  try {
    await h.call('POST', A + 'settings', { advisor: { provider: 'custom', model: 'big-27b' }, allowPaid: false });
    const st = (await h.call('GET', A + 'state')).json;
    assert.equal(st.advisorInfo.kind, 'maybe'); assert.match(st.advisorInfo.refusal, /may be billed by your account/);
    const r = await h.call('POST', A + 'runs', { task: 'x' });
    assert.equal(r.json.status, 'refused'); assert.equal(h.modelCalls.length, 0);
  } finally { await h.close(); }
});

test('the most a run can cost counts 6 advisor calls (a brief and two reviews, each with one second try)', { skip: harnessOnly }, async () => {
  const h = await openHost({ keys: { 'paid-api': 1 }, prices: () => 100, script: scripted({ brief: [BRIEF], work: ['w'], review: [review('done')] }) });
  try {
    await h.call('POST', A + 'settings', { advisor: { provider: 'paid-api', model: 'big' }, allowPaid: true });
    assert.equal((await run(h)).status, 'waiting');   // one earlier call priced 100 per call by the desk's record
    const c = (await h.call('GET', A + 'state')).json.advisorInfo.likelyCost;
    assert.equal(c.known, true); assert.equal(c.upTo, true); assert.equal(c.minor, 600);
  } finally { await h.close(); }
});
