// The test host: one way for this module's tests to run in either place, with the same calls.
//   - Inside an AP Desk folder (modules/<id>/ next to ../../test/helpers/desk.js): a real throwaway desk with the
//     desk's own fake model. This is what the desk's `npm test` uses.
//   - Inside the module kit (samples/<id>/ next to ../../tools/harness.mjs), or wherever APD_KIT_HARNESS names the
//     kit's tools/harness.mjs: the kit's stand-in desk.
// In both places the same options work: allowHosts and fetchImpl decide what ctx.fetch reaches (nothing else does:
// in a desk, every outside address is refused unless the test allows it; the desk's own fake model on this PC still answers).
// Copy this file unchanged into your own module folder. It is not a test itself (its name does not end in .test.js).
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = new URL('.', import.meta.url);
const deskHelper = new URL('../../test/helpers/desk.js', here);
const kitHarness = process.env.APD_KIT_HARNESS ? pathToFileURL(process.env.APD_KIT_HARNESS) : new URL('../../tools/harness.mjs', here);
const exists = (u) => { try { return fs.existsSync(fileURLToPath(u)); } catch { return false; } };

/** Where these tests will run: 'desk', 'harness' or null (neither found). */
export const hostKind = exists(deskHelper) ? 'desk' : exists(kitHarness) ? 'harness' : null;

/** openHost({ script, settings, with: ['chat'], modules: { chat: {...} } }) -> host with call, runTool, pendingApprovals, decide, nextApproval, waitJob, job,
 *  setSetting, panic, resume, switchOn, switchOff, modelCalls, events, api, kind, close. */
export async function openHost(opts = {}) {
  const dir = fileURLToPath(here);
  // with: other desk modules to switch on in a real desk; modules: stand-ins for them in the kit's harness
  if (hostKind === 'harness') { const { openHost: open } = await import(kitHarness.href); return open({ dir, ...opts }); }
  if (hostKind !== 'desk') throw new Error('Neither an AP Desk folder nor the module kit was found next to this module.');
  const id = JSON.parse(fs.readFileSync(new URL('module.json', here), 'utf8')).id;
  const { testDesk } = await import(deskHelper.href);
  // ctx.fetch in the desk calls the global fetch: while this host is open, outside addresses go to opts.fetchImpl when the
  // test allows the host, and are refused otherwise, exactly as in the kit's harness
  const realFetch = globalThis.fetch; const LOOP = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
  globalThis.fetch = async (input, init) => {
    const u = new URL(String(input?.url ?? input));
    if (LOOP.has(u.hostname)) return realFetch(input, init);
    if ((opts.allowHosts || []).includes(u.hostname) && typeof opts.fetchImpl === 'function') return opts.fetchImpl(u, init);
    throw Object.assign(new Error(`The harness does not reach ${u.hostname}. Allow it in the test (allowHosts and fetchImpl).`), { code: 'refused' });
  };
  let t; try { t = await testDesk({ modules: [id, ...(opts.with || [])], script: opts.script }); } catch (e) { globalThis.fetch = realFetch; throw e; }
  const core = t.core;
  for (const [k, v] of Object.entries(opts.settings || {})) core.settings.set(k, v);
  const events = [];
  const host = {
    kind: 'desk', id, core, events, cards: [], answer: null,
    get modelCalls() { return t.fake ? t.fake.calls : []; },
    get api() { return core.modules.api(id); },
    get isOn() { return core.modules.isOn(id); },
    async call(method, path, body, { owner = true } = {}) { const r = await t.call(path, { method, body, session: owner }); return { status: r.status, json: r.json, text: r.text }; },
    runTool: (name, args = {}, call = {}) => core.modules.runTool(name, args, { agentId: 'coordinator', emitCard: () => null, ...call }),
    pendingApprovals: () => core.approval.listPending(),
    decide: (aid, decision) => core.approval.decide(aid, decision),
    async nextApproval(ms = 5000) { const t0 = Date.now(); while (Date.now() - t0 < ms) { const p = core.approval.listPending()[0]; if (p) return p; await new Promise((r) => setTimeout(r, 20)); } return null; },
    waitJob: (jid, ms) => core.jobs.wait(jid, ms),
    job: (jid) => core.jobs.get(jid),
    setSetting: (k, v) => core.settings.set(k, v),
    panic: () => core.panic.stopAll('Panic'),
    resume: () => core.panic.resume(),
    switchOn: () => core.modules.set(id, true),
    switchOff: () => core.modules.set(id, false),
    close: async () => { try { await t.close(); } finally { globalThis.fetch = realFetch; } },
  };
  core.events.on((type, data) => {
    events.push({ type, data });
    if (type === 'approval' && data?.status === 'pending' && host.answer) {
      const a = typeof host.answer === 'function' ? host.answer(data) : host.answer;
      if (a === 'approve' || a === 'deny') setImmediate(() => core.approval.decide(data.id, a));
    }
  });
  for (const other of opts.with || []) if (!core.modules.isOn(other)) await core.modules.set(other, true);
  await core.modules.set(id, true);
  return host;
}
