// Advisor page and its Settings section. Built only from the shell kit and shell.css classes.
const API = 'm/advisor/';
const STATUS = {
  working: ['Working', 'run'], 'sent back': ['Sent back', 'off'], refused: ['Not started', 'fail'], failed: ['Failed', 'fail'],
  stopped: ['Stopped', 'off'], interrupted: ['Interrupted', 'off'],
};
const statusOf = (r) => r.status === 'waiting' ? (r.verdict === 'done' ? ['Waiting for you', 'slow'] : ['Waiting for you: still needs work', 'slow'])
  : r.status === 'accepted' ? (r.done ? ['Done', 'live'] : ['Accepted, not done', 'slow']) : STATUS[r.status] || [r.status, 'off'];
const KIND = { local: 'Local model: free, stays on this PC', free: 'Free', paid: 'Paid', maybe: 'May be billed by your account with that provider' };
const sizeWord = (b) => (b == null ? '' : b >= 14 ? ` · ${b}B, large` : b <= 8 ? ` · ${b}B, small` : ` · ${b}B`);

export const pages = {
  advisor: {
    title: 'Advisor',
    async render(el, ui) {
      const { h, card, btn, line, empty, pill, statusChip, savedMark, toast, fmt, md, spinner } = ui;
      let st = null; let openId = null;
      const picksBody = h('div', { class: 'stack' }, spinner());
      const runsBody = h('div', null, spinner());
      const detail = h('div', { class: 'stack' });
      const task = h('textarea', { rows: 4, maxlength: 4000, placeholder: 'Write a one-page plan to follow up with the three customers who asked for prices last week', 'aria-label': 'The work' });
      const sendMark = savedMark();
      const sendBtn = btn('Hand to the advisor', { onClick: () => send() });
      const money = (minor) => fmt.money(minor, st?.currency || undefined);

      // ---- the two model choices: provider from what the desk has now (Models page), model name typed or picked
      function chooser(role, pick, info) {
        const mark = savedMark();
        const sel = h('select', { 'aria-label': role === 'advisor' ? 'Advisor model provider' : 'Worker model provider' },
          role === 'worker' ? h('option', { value: '' }, "The desk's usual free chain") : h('option', { value: '' }, 'Choose…'),
          st.choices.map((c) => h('option', { value: c.provider, selected: pick?.provider === c.provider }, c.label + (c.ok ? '' : ' (not answering now)'))));
        const listId = 'adv-models-' + role;
        const model = h('input', { type: 'text', list: listId, value: pick?.model || '', placeholder: 'model name, or empty for its default', 'aria-label': 'Model name', style: { minWidth: '0', flex: '1 1 180px' } });
        const options = () => h('datalist', { id: listId }, (st.choices.find((c) => c.provider === sel.value)?.models || []).map((m) => h('option', { value: m.id }, m.id + sizeWord(m.sizeB))));
        let dl = options();
        const save = () => mark.run(async () => { await ui.api(API + 'settings', { body: { [role]: sel.value ? { provider: sel.value, model: model.value.trim() || null } : null } }); await load(); });
        sel.addEventListener('change', () => { const n = options(); dl.replaceWith(n); dl = n; save(); });
        model.addEventListener('change', save);
        const words = [];
        if (info) {
          words.push(KIND[info.kind] || '');
          const c = info.likelyCost;
          if (c && !c.free) words.push(c.known ? `up to about ${money(c.minor)} a run (at most 6 advisor calls, priced from ${c.from} earlier call${c.from === 1 ? '' : 's'})` : `cost not known: ${c.why}`);
        }
        return h('div', { class: 'stack', style: { gap: '6px' } },
          h('b', null, role === 'advisor' ? 'Your advisor (plans and checks)' : 'Your worker (does the steps)'),
          h('p', { class: 'sub' }, role === 'advisor' ? 'A bigger model: an online API model, free or paid, or a large local one (14B to 27B).' : 'A small model (1B to 7B), local or free, or the desk\'s usual free chain.'),
          h('div', { class: 'row' }, sel, model, mark), dl,
          words.filter(Boolean).length ? h('p', { class: 'sub' }, words.filter(Boolean).join(' · ')) : null,
          info?.refusal ? h('div', { class: 'caution' }, info.refusal) : null);
      }
      function paintPicks() {
        // replaceChildren and append write a null as the word "null": leave empty parts out (h() itself skips null)
        picksBody.replaceChildren(...[chooser('advisor', st.advisor, st.advisorInfo), chooser('worker', st.worker, st.workerInfo),
          h('p', { class: 'sub' }, `Paid advisor calls: ${st.allowPaid ? 'on, inside your spend limits' : 'off'}. Change it in Settings › Advisor.`),
          st.online ? null : h('div', { class: 'caution' }, 'The desk is offline: only local models answer.')].filter(Boolean));
      }
      async function send() {
        sendBtn.disabled = true;
        const ok = await sendMark.run(async () => { const r = await ui.api(API + 'runs', { body: { task: task.value } }); openId = r.id; if (r.status === 'refused') throw new Error(r.why); }, { word: 'Started' });
        sendBtn.disabled = false;
        if (ok) task.value = '';
        await paintRuns();
      }
      async function paintRuns() {
        let d; try { d = await ui.api(API + 'runs'); } catch (e) { runsBody.replaceChildren(empty('The runs could not be read just now: ' + e.message)); return; }
        runsBody.replaceChildren(...(d.runs.length ? d.runs.map((r) => { const [w, k] = statusOf(r); const open = () => { openId = r.id; paintDetail(); }; return h('div', { class: 'line', role: 'button', tabindex: '0', style: { cursor: 'pointer' }, onclick: open, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } } }, h('div', { style: { minWidth: 0 } }, h('b', null, r.task.split('\n')[0]), h('span', { class: 'd' }, fmt.when(r.created))), statusChip(w, k)); })
          : [empty('Nothing handed to the advisor yet. Write the work above and press Hand to the advisor.')]));
        await paintDetail();
      }
      async function paintDetail() {
        if (!openId) return detail.replaceChildren();
        let r; try { r = await ui.api(API + 'runs/' + encodeURIComponent(openId)); } catch { return detail.replaceChildren(); }
        const [w, k] = statusOf(r); const last = r.rounds[r.rounds.length - 1];
        const answerPill = (a) => pill(a.answer, a.answer === 'yes' ? 'ok' : a.answer === 'no' ? 'stop' : 'wait');
        const who = [r.brief ? `Brief: ${r.brief.by}` : null, ...r.rounds.flatMap((x) => [`Round ${x.n} written by ${x.by}${x.small ? ' (a small local model)' : ''}`, `Round ${x.n} checked by ${x.review.by}`])].filter(Boolean);
        const cost = r.cost ? (r.cost.unknown ? `${money(r.cost.minor)} known, and ${r.cost.unknown} call${r.cost.unknown === 1 ? '' : 's'} whose cost is not known` : r.cost.minor ? money(r.cost.minor) : 'Nothing: every call was free or local') : 'Not counted yet';
        const actions = r.status === 'waiting' ? h('div', { class: 'row' },
          btn('Accept', { onClick: async () => { try { const x = await ui.api(API + `runs/${r.id}/accept`, { method: 'POST' }); toast(x.message, 'ok'); paintRuns(); } catch (e) { toast(e.message, 'err'); } } }),
          btn('Send back', { kind: 'ghost', onClick: async () => { const note = await ui.ask('What should change?', { multiline: true, ok: 'Send back' }); if (!note) return; try { const x = await ui.api(API + `runs/${r.id}/sendback`, { body: { note } }); openId = x.run.id; toast(x.message, 'ok'); paintRuns(); } catch (e) { toast(e.message, 'err'); } } })) : null;
        detail.replaceChildren(h('div', { class: 'work' },
          h('div', { class: 'work-head' }, h('h3', null, r.brief?.goal || r.task.split('\n')[0]), h('span', { class: 'grow' }), statusChip(w, k)),
          h('div', { class: 'work-body' },
            r.why ? h('div', { class: 'caution' }, r.why) : null,
            r.brief ? h('div', { class: 'stack', style: { gap: '4px' } }, h('div', { class: 'lbl' }, 'Steps'), h('ol', { style: { margin: 0, paddingLeft: '20px' } }, r.brief.steps.map((s) => h('li', null, s)))) : null,
            last ? h('div', { class: 'stack', style: { gap: '4px' } }, h('div', { class: 'lbl' }, `Checks, round ${last.n} of at most 2`),
              ui.table([{ key: 'text', label: 'Check' }, { key: 'answer', label: 'Advisor', render: (a) => answerPill(a) }, { key: 'reason', label: 'Why' }], last.review.answers.map((a) => ({ ...a, text: r.brief.checks.find((c) => c.id === a.check)?.text || a.check })))) : null,
            last?.review.notes ? h('p', { class: 'sub' }, 'Advisor\'s notes: ' + last.review.notes) : null,
            last ? h('div', { class: 'stack', style: { gap: '4px' } }, h('div', { class: 'lbl' }, 'The work'), h('div', { class: 'well' }, md(last.text || 'The worker sent back nothing.'))) : null,
            who.length ? h('div', { class: 'stack', style: { gap: '2px' } }, h('div', { class: 'lbl' }, 'Who did what'), who.map((x) => h('span', { class: 'sub' }, x))) : null,
            line('Cost', 'As the desk recorded it', h('span', { class: 'val' }, cost)),
            r.ownerNote ? h('p', { class: 'sub' }, 'Your note: ' + r.ownerNote) : null,
            actions)));
      }
      async function load() { st = await ui.api(API + 'state'); paintPicks(); }

      el.append(
        h('div', { class: 'phead' }, h('div', { class: 't' }, h('h2', null, ui.label('advisor', 'Advisor')), h('p', { class: 'sub' }, 'A bigger model plans the work and checks it; a smaller one does it; you give the last yes.'))),
        h('div', { class: 'two' },
          card(h('h3', null, 'Models'), picksBody),
          h('div', { class: 'work' }, h('div', { class: 'work-head' }, h('h3', null, 'New piece of work')),
            h('div', { class: 'work-body' }, task, h('div', { class: 'row' }, sendBtn, sendMark), h('p', { class: 'sub' }, 'Nothing is sent to anyone. The result waits here for your Accept.')))),
        card(h('h3', null, 'Runs'), runsBody),
        detail);
      ui.on('advisor', () => paintRuns());
      ui.on('models', () => load());
      try { await load(); } catch (e) { picksBody.replaceChildren(empty('The model list could not be read just now: ' + e.message)); }
      await paintRuns();
    },
  },
};

export const settings = {
  advisor: {
    title: 'Advisor',
    async render(el, ui) {
      const { h, card, line, sw, savedMark } = ui;
      const st = await ui.api(API + 'state');
      const mark = savedMark();
      el.append(card(h('h3', null, 'Advisor'),
        line('Paid advisor calls', 'Off: a paid model is never called. On: it may be called while your spend limits allow; the page shows the most a run can cost first.',
          h('span', { class: 'field' }, sw(st.allowPaid, 'Paid advisor calls', (on) => mark.run(() => ui.api(API + 'settings', { body: { allowPaid: on } }))), mark))));
    },
  },
};
