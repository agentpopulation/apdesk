// Guide extras: the GUIDE.md examples that hello-notes and advisor do not show, each in one route, each run in a desk.
export async function activate(ctx) {
  // ---- Bench mode (GUIDE chapter 7): read its money choice. Bench exposes gate() and view(); it has no door to take work.
  ctx.route('GET', '/bench', (req, res) => {
    const bench = ctx.modules.api('bench');                // null while Bench mode is off
    if (!bench?.gate) return ctx.json(res, { on: false, text: 'Bench mode is off.' });
    const g = bench.gate();                                // { option: 'local' | 'free' | 'paid' | null, chosen, capSessionMinor, capDayMinor, limits }
    ctx.json(res, { on: true, chosen: g.chosen, option: g.option, capDayMinor: g.capDayMinor, currency: ctx.settings.get('currency') || null });
  });

  // ---- a card in a chat (GUIDE chapter 9). The Chat module draws kinds it knows (text, table, progress, file, draft, actions).
  ctx.route('POST', '/card', (req, res, { body, owner }) => {
    if (!owner) return ctx.json(res, { error: 'From the desk window only.' }, 403);
    const posted = ctx.chatCard(String(body?.chatId || 'dm-coordinator'), { kind: 'table', title: 'Two suppliers', columns: ['Supplier', 'Price'], rows: [['North Paper', 'not stated'], ['Lakeside Print', 'not stated']] });
    ctx.json(res, { posted: !!posted });                   // null when Chat is off or the chat is gone
  });

  // ---- an outside call (GUIDE chapter 10): only through ctx.fetch, to a host declared in module.json "hosts"
  ctx.route('GET', '/rate', async (req, res) => {
    try {
      const r = await ctx.fetch('https://api.example.com/rate', { signal: ctx.panic.signal });
      ctx.json(res, { ok: r.ok });
    } catch (e) {
      const why = e.code === 'offline' ? 'The desk is offline, so the rate was not checked.' : e.code === 'halted' ? 'Everything is stopped. Press Resume first.' : 'The rate could not be read just now.';
      ctx.json(res, { error: why, code: e.code || null }, 503);
    }
  });

  // ---- a secret (GUIDE chapter 11): stored in the desk's secrets table, never sent back, never logged
  ctx.route('POST', '/token', (req, res, { body, owner }) => {
    if (!owner) return ctx.json(res, { error: 'From the desk window only.' }, 403);
    ctx.secrets.set('token', String(body?.token || ''));   // an empty value removes it
    ctx.json(res, { saved: ctx.secrets.has('token') });     // say whether it is there, never what it is
  });

  // ---- another module's API (GUIDE chapter 11): never its tables
  ctx.route('GET', '/notes-count', (req, res) => {
    const notes = ctx.modules.api('hello-notes');           // null while Hello notes is off
    ctx.json(res, { count: notes ? notes.count() : null, text: notes ? null : 'Hello notes is off.' });
  });

  return { async deactivate() {} };
}
