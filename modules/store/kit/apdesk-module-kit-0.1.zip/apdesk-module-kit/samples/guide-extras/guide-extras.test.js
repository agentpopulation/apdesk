// The guide's extra examples, run in a real desk (with Bench, Chat and Hello notes switched on there) or in the kit's harness
// (with stand-ins for them). No outside call is made: the Offline example shows the refusal before any network.
import test from 'node:test';
import assert from 'node:assert/strict';
import { openHost, hostKind } from './testhost.js';

const skip = hostKind ? false : 'no desk and no kit harness next to this module';
const G = '/api/m/guide-extras/';
const stand = { bench: { gate: () => ({ option: null, chosen: false, capSessionMinor: 0, capDayMinor: 0, limits: {} }) }, 'hello-notes': { count: () => 0 } };

test('Bench: its money choice reads as "not chosen" on a fresh desk', { skip }, async () => {
  const h = await openHost({ with: ['bench'], modules: stand });
  try {
    const r = await h.call('GET', G + 'bench');
    assert.equal(r.json.on, true); assert.equal(r.json.chosen, false); assert.equal(r.json.option, null);
  } finally { await h.close(); }
});

test('a card goes into the Coordinator chat (null when Chat is off)', { skip }, async () => {
  const h = await openHost({ with: ['chat'], modules: stand });
  try {
    const r = await h.call('POST', G + 'card', { chatId: 'dm-coordinator' });
    assert.equal(r.status, 200);
    if (h.kind === 'desk') { assert.equal(r.json.posted, true); const c = await h.call('GET', '/api/m/chat/chats/dm-coordinator'); assert.equal(c.json.last, 'Two suppliers', 'the chat shows the card as its last line'); }
    else assert.equal(h.cards[0].card.title, 'Two suppliers');
  } finally { await h.close(); }
});

test('Offline: ctx.fetch refuses before any network, and the route says so in plain words', { skip }, async () => {
  const h = await openHost({ settings: { online: false } });
  try {
    const r = await h.call('GET', G + 'rate');
    assert.equal(r.status, 503); assert.equal(r.json.code, 'offline'); assert.equal(r.json.error, 'The desk is offline, so the rate was not checked.');
  } finally { await h.close(); }
});

test('an outside call: the test allows one host and answers for it, in the desk and in the harness alike', { skip }, async () => {
  const seen = [];
  const fetchImpl = async (u) => { seen.push(u.hostname); return new Response('{"rate":83}', { status: 200, headers: { 'content-type': 'application/json' } }); };
  const h = await openHost({ allowHosts: ['api.example.com'], fetchImpl });
  try {
    const r = await h.call('GET', G + 'rate');
    assert.equal(r.status, 200, r.text); assert.deepEqual(r.json, { ok: true }); assert.deepEqual(seen, ['api.example.com']);
  } finally { await h.close(); }
  const h2 = await openHost();   // no host allowed: refused before any network, the same in both places
  try { const r = await h2.call('GET', G + 'rate'); assert.equal(r.status, 503); assert.equal(r.json.code, 'refused'); }
  finally { await h2.close(); }
});

test('a secret is kept and never sent back', { skip }, async () => {
  const h = await openHost();
  try {
    const r = await h.call('POST', G + 'token', { token: 'tok_example_123456' });
    assert.deepEqual(r.json, { saved: true }); assert.doesNotMatch(r.text, /tok_example/);
    assert.deepEqual((await h.call('POST', G + 'token', { token: '' })).json, { saved: false });
  } finally { await h.close(); }
});

test('another module through its API, and null while it is off', { skip }, async () => {
  const h = await openHost();
  try { const r = await h.call('GET', G + 'notes-count'); assert.equal(r.json.count, null); assert.equal(r.json.text, 'Hello notes is off.'); }
  finally { await h.close(); }
});
