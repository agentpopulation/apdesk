// Hello notes: the smallest module that shows every common thing once.
// The desk calls activate(ctx) when the module is switched on (at start, or from the Module Store) and calls the
// deactivate() it returns when the module is switched off. Everything the module holds lives inside activate:
// the desk can switch the same module on in more than one person's space in one process, and each gets its own ctx.
import { writeFile, mkdir } from 'node:fs/promises';   // used only on paths from ctx.workspacePath (see /export)

const MAX_TEXT = 500;   // a note is short; longer text is refused with a plain sentence, never cut silently

export async function activate(ctx) {
  // ---- storage: one table of our own. Table names start with m_<id>_ (dashes in the id become underscores).
  // migrate(version, sql) runs once per version, ever; add a version 2 later for a new column, never edit version 1.
  ctx.db.migrate(1, `
    CREATE TABLE IF NOT EXISTS m_hello_notes_notes (
      id TEXT PRIMARY KEY,
      text TEXT NOT NULL,
      by TEXT NOT NULL,          -- 'you' or the agent that added it
      created TEXT NOT NULL      -- ISO time in UTC; the page shows it in the owner's zone
    );`);

  // ---- the module's own setting, kept in kv (namespaced to this module by the desk)
  const newestFirst = () => ctx.kv.get('newestFirst', true);

  const list = () => ctx.db.all(`SELECT id, text, by, created FROM m_hello_notes_notes ORDER BY created ${newestFirst() ? 'DESC' : 'ASC'}, rowid ${newestFirst() ? 'DESC' : 'ASC'}`);
  const add = (text, by) => {
    const t = String(text ?? '').trim();
    if (!t) throw Object.assign(new Error('Write something first.'), { status: 400 });
    if (t.length > MAX_TEXT) throw Object.assign(new Error(`A note is at most ${MAX_TEXT} characters; this one has ${t.length}.`), { status: 400 });
    const note = { id: 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text: t, by, created: new Date().toISOString() };
    ctx.db.run('INSERT INTO m_hello_notes_notes (id, text, by, created) VALUES (?, ?, ?, ?)', note.id, note.text, note.by, note.created);
    ctx.events.emit('hello-notes', { change: 'added', id: note.id });   // open pages redraw (ui.on('hello-notes'))
    return note;
  };

  // ---- routes: served at /api/m/hello-notes/<path>. `owner` is true only when the request came from the desk's own window.
  ctx.route('GET', '/notes', (req, res) => ctx.json(res, { notes: list(), newestFirst: newestFirst(), lastSummary: ctx.kv.get('lastSummary', null) }));

  ctx.route('POST', '/notes', (req, res, { body, owner }) => {
    if (!owner) return ctx.json(res, { error: 'Notes are added from the desk window.' }, 403);
    try { ctx.json(res, { note: add(body?.text, 'you'), message: 'Note saved.' }); }
    catch (e) { ctx.json(res, { error: e.message }, e.status || 500); }
  });

  ctx.route('POST', '/settings', (req, res, { body, owner }) => {
    if (!owner) return ctx.json(res, { error: 'Settings change from the desk window only.' }, 403);
    if (typeof body?.newestFirst !== 'boolean') return ctx.json(res, { error: 'newestFirst is true or false.' }, 400);
    ctx.kv.set('newestFirst', body.newestFirst);
    ctx.json(res, { newestFirst: newestFirst() });
  });

  // ---- one action behind the approval door, run as a job: write the notes to a file in the workspace.
  // 'file.write' is allowed at the Open level and asked at Careful and Strict; the module never decides that itself.
  // It is a job because an approval can wait a long time for the owner: the route answers at once, and the job shows
  // "Waiting for you" in Tasks and in the footer until he decides.
  ctx.route('POST', '/export', async (req, res, { owner }) => {
    if (!owner) return ctx.json(res, { error: 'Save from the desk window.' }, 403);
    const notes = list();
    if (!notes.length) return ctx.json(res, { error: 'There are no notes to save yet.' }, 409);
    const rel = 'reports/hello-notes.md';
    const job = await ctx.jobs.start({
      kind: 'hello-notes.export', title: `Save my notes to ${rel}`, input: { count: notes.length },
      async run(job) {
        const d = await ctx.approval.request({ jobId: job.id, action: 'file.write', title: `Save ${notes.length} note${notes.length === 1 ? '' : 's'} to ${rel}`, detail: 'Workspace › reports', payload: { path: rel, notes: notes.length }, signal: job.signal });
        if (!d.ok) return { saved: false, text: d.reason === 'denied' ? 'Not saved: you said no.' : `Not saved (${d.reason}).` };
        // ctx.workspacePath refuses a path that climbs out of the workspace; node:fs is used only on such a path
        await mkdir(ctx.workspacePath('reports'), { recursive: true });
        await writeFile(ctx.workspacePath(...rel.split('/')), '# Notes\n\n' + notes.map((n) => `- ${n.text}`).join('\n') + '\n', 'utf8');
        ctx.activity(`Saved ${notes.length} notes to ${rel}`);   // one plain line in the owner's activity log
        return { saved: true, path: rel, text: `Saved to ${rel} in your workspace.` };
      },
    });
    ctx.json(res, { jobId: job.id, message: 'Saving. If the desk asks you first, the request is under Waiting for you.' });
  });

  // ---- one model call, as a job: "Summarise my notes". A job keeps running when the page closes; Stop and Panic end it.
  ctx.route('POST', '/summary', async (req, res, { owner }) => {
    if (!owner) return ctx.json(res, { error: 'Ask from the desk window.' }, 403);
    const notes = list();
    if (!notes.length) return ctx.json(res, { error: 'There are no notes to summarise yet.' }, 409);
    const job = await ctx.jobs.start({
      kind: 'hello-notes.summary', title: 'Summarise my notes', input: { count: notes.length },
      async run(job) {
        job.progress(0.2, 'Asking a model');
        // Every model call goes through ctx.model. No model is named: the desk's usual chain answers (free first).
        const r = await ctx.model.chat({
          purpose: 'small', signal: job.signal, maxTokens: 120,
          messages: [
            { role: 'system', content: 'Summarise the owner\'s notes in one plain sentence of at most 25 words. Use only what the notes say.' },
            { role: 'user', content: notes.map((n) => '- ' + n.text).join('\n') },
          ],
        });
        // r.label names the model that really answered ("Free API · ..."); show it, never a name of our own
        const summary = { text: r.text.trim(), by: r.label, small: !!r.small, at: new Date().toISOString() };
        ctx.kv.set('lastSummary', summary);   // the page shows the last one after a reload
        return summary;
      },
    });
    ctx.json(res, { jobId: job.id, message: 'Summarising. It shows here when it is ready.' });
  });

  // ---- one tool the Coordinator can call from Chat ("add a note: call the bank on Monday")
  ctx.tool({
    name: 'notes_add',   // letters, digits and underscores only; listed in module.json "tools" too
    description: 'Add a short note to the owner\'s Hello notes list when he asks to note something down.',
    parameters: { type: 'object', properties: { text: { type: 'string', description: 'the note, in the owner\'s words' } }, required: ['text'] },
    async run(args, call) {
      const note = add(args.text, call.agentId || 'an agent');
      return { ok: true, text: `Noted: ${note.text}`, id: note.id };   // a plain object; the Coordinator reads it back
    },
  });

  // ---- what other modules may use: ctx.modules.api('hello-notes') returns this object while the module is on
  ctx.expose({ count: () => ctx.db.get('SELECT COUNT(*) AS n FROM m_hello_notes_notes').n, list: () => list() });

  // ---- a listener we must remove on deactivate (the same rule holds for timers)
  const offSettings = ctx.settings.onChange((key) => { if (key === 'timeZone') ctx.events.emit('hello-notes', { change: 'zone' }); });

  return {
    async deactivate() {
      offSettings();   // routes, tools and the exposed API are removed by the desk; what we started, we stop
    },
  };
}
