// Hello notes: one page and one Settings section, built only from the shell kit (`ui`) and the classes in the desk's
// shell.css. No own colours, no own fonts, no framework. The shell loads this file from /modules/hello-notes/ui.js
// while the module is on, and calls render(el, ui) with `el` = the page area (a flex column that scrolls inside the pane).
const API = 'm/hello-notes/';

export const pages = {
  'hello-notes': {
    title: 'Notes',
    async render(el, ui) {
      const { h, card, btn, line, empty, pill, statusChip, savedMark, toast, fmt, spinner } = ui;
      // the owner may have renamed this place in Settings › Menu: ui.label gives his name, else ours
      const title = ui.label('hello-notes', 'Notes');

      const box = h('textarea', { rows: 3, maxlength: 500, placeholder: 'Call the bank on Monday about the loan papers', 'aria-label': 'New note' });
      const mark = savedMark();
      const addBtn = btn('Add note', { onClick: () => addNote() });
      const listBody = h('div', null, spinner());
      const count = pill('…');
      const summaryBody = h('div', { class: 'stack' });
      const mine = new Map();   // job id -> what it is, for the jobs this page started

      async function addNote() {
        addBtn.disabled = true;
        // savedMark shows "Saving…", then a tick, or a cross with the reason; the owner always sees an answer
        const ok = await mark.run(() => ui.api(API + 'notes', { body: { text: box.value } }), { word: 'Added' });
        addBtn.disabled = false;
        if (ok) { box.value = ''; box.focus(); await paint(); }
      }
      async function startJob(path, what) {
        try { const r = await ui.api(API + path, { method: 'POST' }); mine.set(r.jobId, what); toast(r.message); }
        catch (e) { toast(e.message, 'err'); }
      }
      function showSummary(s, running) {
        if (running) return summaryBody.replaceChildren(h('div', { class: 'row' }, statusChip('Working', 'run'), h('span', { class: 'sub' }, 'A model is reading your notes.')));
        if (!s) return summaryBody.replaceChildren(h('p', { class: 'sub' }, 'No summary yet. Press Summarise when you have a few notes.'));
        // replaceChildren writes a null as the word "null", so the optional line is left out with filter(Boolean)
        summaryBody.replaceChildren(...[
          h('p', { style: { margin: 0 } }, s.text || 'The model sent back an empty answer.'),
          h('p', { class: 'sub' }, `Written by ${s.by} · ${fmt.when(s.at)}`),
          s.small ? h('p', { class: 'sub' }, 'A small local model wrote this; check it against your notes.') : null].filter(Boolean));
      }
      async function paint() {
        let d;
        try { d = await ui.api(API + 'notes'); }
        catch (e) { listBody.replaceChildren(empty('The notes could not be read just now: ' + e.message)); return; }
        count.textContent = d.notes.length === 1 ? '1 note' : `${d.notes.length} notes`;
        // an empty state says why it is empty and what to do
        listBody.replaceChildren(...(d.notes.length
          ? d.notes.map((n) => line(n.text, `${n.by === 'you' ? 'You' : 'Added by ' + (ui.agent(n.by)?.name || 'an agent')} · ${fmt.when(n.created)}`))
          : [empty('No notes yet. Write one above, or ask the Coordinator in Chat to note something down.')]));
        if (![...mine.values()].includes('summary')) showSummary(d.lastSummary, false);
      }

      el.append(
        h('div', { class: 'phead' },
          h('div', { class: 't' }, h('h2', null, title), h('p', { class: 'sub' }, 'Short notes you or the Coordinator write. They stay on this PC.')),
          h('div', { class: 'row' }, btn('Summarise', { kind: 'ghost', onClick: () => { showSummary(null, true); startJob('summary', 'summary'); } }), btn('Save to a file', { kind: 'ghost', onClick: () => startJob('export', 'export') }))),
        // the page is a flex column: a panel that hides its overflow (.work) must not shrink when the list grows long
        h('div', { class: 'work', style: { flexShrink: '0' } },
          h('div', { class: 'work-head' }, h('h3', null, 'New note')),
          h('div', { class: 'work-body' }, box, h('div', { class: 'row' }, addBtn, mark))),
        h('div', { class: 'two' },
          card(h('div', { class: 'row' }, h('h3', null, 'Your notes'), h('span', { class: 'grow' }), count), listBody),
          card(h('h3', null, 'Summary'), summaryBody)));

      // events while this page is on screen (ui.on is removed by the shell when the page leaves)
      ui.on('hello-notes', () => paint());
      ui.on('job', (j) => {
        const what = mine.get(j?.id); if (!what || ['running', 'waiting'].includes(j.status)) return;
        mine.delete(j.id);
        const words = j.status === 'done' ? j.output?.text || 'Done.' : j.status === 'stopped' ? 'Stopped.' : 'It did not work: ' + (j.error || 'no reason was given');
        toast(what === 'summary' ? (j.status === 'done' ? 'Summary ready.' : words) : words, j.status === 'done' && j.output?.saved !== false ? 'ok' : 'err');
        paint();
      });
      box.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) addNote(); });
      await paint();
    },
  },
};

export const settings = {
  'hello-notes': {
    title: 'Hello notes',
    async render(el, ui) {
      const { h, card, line, sw, savedMark } = ui;
      const d = await ui.api(API + 'notes');
      const mark = savedMark();
      // a switch that saves by itself; savedMark answers with a tick or the reason it did not save
      const toggle = sw(d.newestFirst, 'Newest note first', (on) => mark.run(() => ui.api(API + 'settings', { body: { newestFirst: on } })));
      el.append(card(h('h3', null, 'Hello notes'), line('Newest note first', 'Off puts your oldest note at the top', h('span', { class: 'field' }, toggle, mark))));
    },
  },
};
