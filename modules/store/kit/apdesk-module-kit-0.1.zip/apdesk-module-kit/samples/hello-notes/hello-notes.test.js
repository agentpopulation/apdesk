// Hello notes: the plumbing, with the fake model. It runs in a real AP Desk (npm test) and in the module kit (node --test).
// The fake model answers from a script; nothing here is proof that a real model writes a good summary ("not checked").
import test from 'node:test';
import assert from 'node:assert/strict';
import { openHost, hostKind } from './testhost.js';

const skip = hostKind ? false : 'no desk and no kit harness next to this module';

test('add, list, refuse an empty note, and only from the desk window', { skip }, async () => {
  const host = await openHost();
  try {
    const empty = await host.call('GET', '/api/m/hello-notes/notes');
    assert.equal(empty.status, 200); assert.deepEqual(empty.json.notes, []);
    const add = await host.call('POST', '/api/m/hello-notes/notes', { text: '  Call the bank on Monday  ' });
    assert.equal(add.status, 200); assert.equal(add.json.note.text, 'Call the bank on Monday'); assert.equal(add.json.message, 'Note saved.');
    const bad = await host.call('POST', '/api/m/hello-notes/notes', { text: '   ' });
    assert.equal(bad.status, 400); assert.equal(bad.json.error, 'Write something first.');
    const long = await host.call('POST', '/api/m/hello-notes/notes', { text: 'x'.repeat(501) });
    assert.equal(long.status, 400); assert.match(long.json.error, /at most 500 characters; this one has 501/);
    const outside = await host.call('POST', '/api/m/hello-notes/notes', { text: 'from a script' }, { owner: false });
    assert.equal(outside.status, 403);
    const after = await host.call('GET', '/api/m/hello-notes/notes');
    assert.equal(after.json.notes.length, 1);
    assert.equal(host.api.count(), 1, 'the exposed API answers');
  } finally { await host.close(); }
});

test('the Coordinator tool adds a note and names the agent', { skip }, async () => {
  const host = await openHost();
  try {
    const r = await host.runTool('notes_add', { text: 'Order printer paper' }, { agentId: 'scout' });
    assert.equal(r.ok, true); assert.equal(r.text, 'Noted: Order printer paper');
    const d = await host.call('GET', '/api/m/hello-notes/notes');
    assert.equal(d.json.notes[0].by, 'scout');
  } finally { await host.close(); }
});

test('the setting is kept per module and read back', { skip }, async () => {
  const host = await openHost();
  try {
    await host.call('POST', '/api/m/hello-notes/notes', { text: 'first' });
    await new Promise((r) => setTimeout(r, 5));
    await host.call('POST', '/api/m/hello-notes/notes', { text: 'second' });
    assert.equal((await host.call('GET', '/api/m/hello-notes/notes')).json.notes[0].text, 'second');
    const s = await host.call('POST', '/api/m/hello-notes/settings', { newestFirst: false });
    assert.equal(s.json.newestFirst, false);
    assert.equal((await host.call('GET', '/api/m/hello-notes/notes')).json.notes[0].text, 'first');
    assert.equal((await host.call('POST', '/api/m/hello-notes/settings', { newestFirst: 'yes' })).status, 400);
  } finally { await host.close(); }
});

test('summary: a job, one model call through the door, the label of the model that answered', { skip }, async () => {
  const host = await openHost({ script: () => 'Two errands this week.' });
  try {
    await host.call('POST', '/api/m/hello-notes/notes', { text: 'Call the bank' });
    await host.call('POST', '/api/m/hello-notes/notes', { text: 'Order paper' });
    const r = await host.call('POST', '/api/m/hello-notes/summary');
    assert.equal(r.status, 200); assert.ok(r.json.jobId);
    const job = await host.waitJob(r.json.jobId);
    assert.equal(job.status, 'done', job.error || '');
    assert.equal(job.output.text, 'Two errands this week.');
    assert.match(job.output.by, /^Free API · /, 'the label comes from the door');
    assert.equal(host.modelCalls.length, 1);
    assert.match(JSON.stringify(host.modelCalls[0].messages), /Call the bank/);
    assert.equal((await host.call('GET', '/api/m/hello-notes/notes')).json.lastSummary.text, 'Two errands this week.');
  } finally { await host.close(); }
});

test('save to a file asks at Careful: yes writes it, no does not', { skip }, async () => {
  const host = await openHost({ settings: { 'security.level': 'careful' } });
  try {
    await host.call('POST', '/api/m/hello-notes/notes', { text: 'Keep the receipts' });
    const r = await host.call('POST', '/api/m/hello-notes/export');
    const ask = await host.nextApproval();
    assert.ok(ask, 'the door asked the owner'); assert.equal(ask.action, 'file.write'); assert.match(ask.title, /Save 1 note to reports\/hello-notes\.md/);
    assert.equal(host.job(r.json.jobId).status, 'waiting', 'the job waits for the owner');
    host.decide(ask.id, 'deny');
    const no = await host.waitJob(r.json.jobId);
    assert.equal(no.output.saved, false); assert.equal(no.output.text, 'Not saved: you said no.');
    const r2 = await host.call('POST', '/api/m/hello-notes/export');
    host.decide((await host.nextApproval()).id, 'approve');
    const yes = await host.waitJob(r2.json.jobId);
    assert.equal(yes.output.saved, true); assert.equal(yes.output.path, 'reports/hello-notes.md');
  } finally { await host.close(); }
});

test('Panic stops a running summary; switching off removes the routes and the tool', { skip }, async () => {
  const host = await openHost({ script: () => ({ text: 'late', delayMs: 3000 }) });
  try {
    await host.call('POST', '/api/m/hello-notes/notes', { text: 'one' });
    const r = await host.call('POST', '/api/m/hello-notes/summary');
    await new Promise((res) => setTimeout(res, 100));
    await host.panic();
    const job = await host.waitJob(r.json.jobId);
    assert.equal(job.status, 'stopped');
    host.resume();
    await host.switchOff();
    assert.equal((await host.call('GET', '/api/m/hello-notes/notes')).status, 404);
    await assert.rejects(host.runTool('notes_add', { text: 'x' }), /No such tool/);
    await host.switchOn();
    assert.equal((await host.call('GET', '/api/m/hello-notes/notes')).json.notes.length, 1, 'what it saved stays');
  } finally { await host.close(); }
});
