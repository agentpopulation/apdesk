---
name: compare-supplier-quotes
description: Use when the owner has two or more quotes from suppliers for the same thing and wants to know which to take.
---
# Compare supplier quotes

## Steps

1. Ask the owner for the quotes if they are not in the chat yet: the supplier, the price, what is included, delivery time and payment terms.
2. Put the quotes side by side in a table: price, what is included, delivery, payment terms, warranty.
3. Show every price in the owner's currency as the quote states it. If a quote is in another currency, say so and do not convert it unless the owner gives the rate.
4. Mark anything a quote does not say as "not stated". Do not fill it in.
5. Give a one-line pick for the owner's need, and one line on when the other quote would be better.
6. Stop there. The owner decides and writes to the supplier himself.

## Checks

- Every number in the table comes from a quote
- Nothing a quote leaves out is filled in
- Nothing is sent to a supplier
