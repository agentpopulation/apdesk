#!/bin/sh
# Example of a file that comes with a skill. The kit never runs it; the desk never runs files that come with a skill.
echo "this is never run"
