# Note for the coding agent: build a module for AP Desk 0.1.1

You have this zip and nothing else: no access to the AP Desk code. Everything you need is in it. Work top to bottom.

## What AP Desk is

1. A desktop assistant that runs on the owner's own PC: a Node.js server on 127.0.0.1 and a page in his browser.
2. Node 22.13 or later, ES modules, no build step, plain JavaScript in the browser, no framework.
3. One SQLite file and one workspace folder per person and space; nothing leaves the PC unless the owner allows it.
4. Agents (a Coordinator and helpers) answer in Chat and call tools; models come through one model door (free first).
5. Every side effect asks the owner through one approval door; the red Panic button stops everything at once.

## What a module is

A folder `modules/<id>/` with `module.json` (what it is), `server.js` (routes, tools, jobs, through `ctx`), `ui.js` (its page
and Settings section, built from the desk's kit), and `*.test.js`. The desk loads it at start and the owner switches it on
in the Module Store. The full reference is CONTRACT.md; the reasons and examples are in GUIDE.md.

## The contract, in your working order

1. **module.json.** Fill it like `samples/hello-notes/module.json`. Fields and meanings: CONTRACT.md section 2. Your id is
   lower-case with dashes and equals the folder name; `kind` is `switch-on`; `defaultOn` is `false`; `number` 60 or above
   and not 61, 62, 63 (the kit's samples); `status` honest (GUIDE chapter 3); list every tool in `tools` and every outside
   host in `hosts`. A module that reads addresses the owner types in (any page he saves) declares `"hosts": ["*"]`; the
   report then shows one yellow line saying so. The desk 0.1.1 itself ignores `hosts`: it is the owner's label, which the
   checker compares with your code, and your code can read it as `ctx.manifest.hosts` to refuse other hosts. A filled example:
   ```json
   { "id": "price-watch", "number": 70, "name": "Price watch",
     "description": "Watches the price of products on pages you name and tells you when one drops. It reads those pages only; nothing is bought or sent.",
     "kind": "switch-on", "defaultOn": false, "menu": [{ "id": "price-watch", "label": "Prices", "order": 160 }],
     "pages": ["price-watch"], "settings": [{ "id": "price-watch", "label": "Price watch" }], "agentTabs": [],
     "tools": ["price_watch_add"], "requires": [], "npm": {}, "hosts": ["shop.example.com"], "attribution": [], "status": "partial" }
   ```
2. **server.js.** `export async function activate(ctx)` registers everything and returns `{ deactivate }`
   (GUIDE chapter 1). The members of `ctx` you may use, each with its example in the guide:
   - `ctx.route`, `ctx.json`, the `owner` flag: chapter 8 and `samples/hello-notes/server.js`
   - `ctx.db` with `migrate`, `ctx.kv`, `ctx.secrets`, `ctx.workspacePath`: chapter 11
   - `ctx.model.chat` (and `active`, `providers`, `usage`): chapters 5 and 6
   - `ctx.approval.request`, `assertGranted`, `state`: chapter 10 and CONTRACT.md section 7
   - `ctx.jobs.start` with `job.progress` and `job.signal`; `ctx.tool`; `ctx.chatCard`: chapter 9
   - `ctx.fetch`, `ctx.panic.signal`, `ctx.panic.onStop`, Offline: chapter 10
   - `ctx.settings.get` (read-only), `ctx.events.emit`, `ctx.expose`, `ctx.modules.api`, `ctx.activity`, `ctx.log`:
     chapters 8 and 11, CONTRACT.md section 4
3. **ui.js.** `export const pages = { '<page id>': { title, render(el, ui) } }` and `export const settings = {...}`; build only
   from the kit helpers and CSS classes listed in GUIDE chapter 4; copy the page pattern of `samples/hello-notes/ui.js`.
4. **Tests.** Copy `samples/hello-notes/testhost.js` unchanged into your folder and write `<id>.test.js` with `node:test`
   like `samples/hello-notes/hello-notes.test.js` (GUIDE chapter 13).

## Hard rules (the checker refuses most of these)

- Write only inside your own module folder. Never touch `app/` or another module.
- Tables named `m_<id>_...` (dashes as underscores), created by `ctx.db.migrate`. No other module's tables, no core tables;
  talk to other modules through `ctx.modules.api('<id>')`.
- Every model call through `ctx.model`. Never a model library, a key, or a socket to a provider.
- Every side effect that leaves the PC or changes something for a person through `ctx.approval`; a send to a person
  (`send.person`) with `assertGranted` right before it. An approval that sends nothing (the owner only says yes to
  something) uses the action `custom`: its card reads "Action" with an "Approve" button, not "Approve and send".
- Long work, model calls and approvals that may wait run as a job, with `job.signal` passed on.
- Outside calls only through `ctx.fetch`, to hosts listed in `hosts` (or `["*"]`, see above).
- State inside `activate`: never in module-level variables. Stop your timers and listeners in `deactivate`.
- No `node:child_process`, `worker_threads`, `net`, `http`, `https`, `tls`, `dgram`, `dns`, `vm`, `cluster`, `inspector`,
  `sqlite`, `module`, `os`, `process`, `timers`; no `eval`, `new Function`, `.constructor(...)`, `require`, dynamic import
  of a computed path, `process.getBuiltinModule`, `process.binding`; no `globalThis[...]`, `process[...]` or `ctx[...]`
  with a name built at run time, and no `const g = globalThis`; no changes to built-ins or globals (`JSON.parse = ...`,
  `Date.now = ...`, a prototype held in a name); no `\u` escapes in names. The checker reads text; these are what it
  cannot follow, so they are red.
- `node:fs` only on paths from `ctx.workspacePath(...)`, `ctx.dir` or `ctx.dataDir`, joined with plain words
  (`path.join(ctx.dir, 'notes.md')`); a `..` anywhere in the path is red.
- SQL with its table names written out. A table name built at run time is yellow: the desk does not stop a module from
  reading another module's tables, so the owner is told.
- No npm package unless you list it under `npm` and say why in your hand-back; the desk installs nothing for you.
- Secrets only in `ctx.secrets`; never in kv, logs, events or answers.
- The page calls only your own routes (`ui.api('m/<id>/...')`); never `fetch`, `new Image`, `window.open`, an `src`
  built at run time, an outside `url(...)` in css, `ui.decide`, `ui.setLevel` or the desk's own routes. The desk lets a
  page load outside pictures, and a picture address can carry what is on the screen to another host.
- Text on screen that looks like an address (`https://` with a host after it) counts as a host, in test files too (those
  are only noted). Write "an address that starts with https" rather than "https://...".
- Never call `ctx.model.keys.add/remove/toggle/tier`, never write settings.

## Words on screen

Plain short words. No emoji. No bold on small controls. No internal ids. Never `null`, `undefined` or `NaN` on screen.
Times with `ui.fmt.when` (the owner's zone) and money with `ui.fmt.money` (the owner's currency), taken from settings,
never typed in. Every action answers back (the saved mark, a toast, or the reason it did not work). Say "not checked"
where nothing was checked. Never invent data. Good and bad side by side: GUIDE chapter 12.

## Test without the desk, then with it

Put your folder in this kit's `samples/` (so `../../tools/harness.mjs` is beside it), or set `APD_KIT_HARNESS` to the full
path of `tools/harness.mjs`. Then, from the kit folder:
```
node --test samples/<id>/<id>.test.js
node tools/check-module.mjs samples/<id> --run
```
`--run` starts your module once and runs your tests in a locked-down Node process (no programs, no workers, no network,
writes only in a temp folder, an empty environment). A test that passes in the harness and fails there is reaching for
something the desk would not give it either.
If you have a desk: put the folder in `<desk>/modules/<id>/` (or use `node tools/add-module.mjs samples/<id> --desk <desk> --yes`),
then from the desk folder: `node --test modules/<id>/<id>.test.js` and `node tools/smoke.mjs --quick`.
`testhost.js` gives the same options in both places for `ctx.fetch`: `allowHosts` and `fetchImpl` (in a desk, every
outside address is refused unless the test allows it, as in the harness). `keys`, `prices` and `localModels` exist only in
the harness; a test that needs them skips in a desk with that reason (see `samples/advisor/advisor.test.js`).

**What the harness does not copy.** The HTTP layer (the session token, paired browsers, cross-site refusals: a route
called with `owner: false` reaches your handler in the harness, while the desk refuses every non-GET request without the
session before it gets there); the real model chain (fallback order, learning, free-host back-off, time limits,
streaming; the fake model answers every call); the desk's SQL guard by asking SQLite which tables a statement opens (the
harness checks by position only); several spaces and people, Incognito, keeper-only routes; the 24-hour approval timeout;
spend days counted in the owner's zone; settings taken from the computer (the harness starts with India, INR, Asia/Kolkata);
the Chat module drawing your cards (the harness only records them); the shell and your `ui.js` (they never run in the harness:
look at your page in a desk; two faults seen only there are in GUIDE chapter 4, "Two layout traps"); times shown by your
page in the owner's zone (`ui.fmt.when` runs only in the page); where a failed job's reason is shown (in a desk: the Tasks
page, and a toast without the reason); a fresh desk's first run (a role chooser, then pairing the browser by a six-digit
code the desk prints in its window); the look, which follows the desk's own sun/moon button, not the browser's colour scheme.
The harness's own messages and labels name no products ("the local model server"); the desk's may.

## Steps

1. Read GUIDE.md chapters 1 to 13 and the owner's sheet (specs/NEW-MODULE-TEMPLATE.md or specs/ADVISOR-SPEC.md).
2. Copy `samples/hello-notes` to `samples/<id>`; rename the id, number, table prefix, routes and texts.
3. Write the failing test for the first thing the sheet asks; make it pass; repeat.
4. Run `node tools/check-module.mjs samples/<id> --run` until it shows no red line; answer each yellow line in your hand-back.
5. If you can, run it in a desk and take pictures of your page at 390 and 1366 px wide, dark and light.
6. Fill the hand-back list below.

## What "done" means

- `node tools/check-module.mjs samples/<id> --run` ends with "Result: no red line".
- `node --test samples/<id>/<id>.test.js` passes, and shows what it tested.
- It switches on and off cleanly in a desk (or you say you had no desk: "not checked in a desk").
- The hand-back list is filled.

## What to hand back

1. The module folder as a zip (`<id>/` at the top of the zip, no `node_modules`, no hidden files).
2. The checker's report, as printed.
3. The test output, as printed.
4. A list of what was not checked (a real model, a paid model, Windows, a desk, an outside service), each in one line.
5. One line per yellow line of the report: why it is there.
