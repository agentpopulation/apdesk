// Turns a checked skill into the small JSON file AP Desk's "add a custom skill" route takes, and says how to add it.
//   node tools/import-skill.mjs <skill folder or .md file> [--out <file.json>] [--key <public key file>]
// It refuses on a red line. Bundled scripts and files are never copied or run: only the text goes in.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkSkill, printSkill, deskSkill } from './lib/skill.mjs';
import { loadKeys } from './lib/sig.mjs';

const KIT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
const target = args.find((a, i) => !a.startsWith('--') && !['--key', '--out'].includes(args[i - 1]));
if (!target) { console.error('Use: node tools/import-skill.mjs <skill folder or .md file> [--out <file.json>]'); process.exit(2); }
if (opt('--key') && !(() => { try { return loadKeys(opt('--key')).length > 0; } catch { return false; } })()) { console.log(`That is not a public key file (${opt('--key')}). Give the file that ends in .pub.json, never the .key file.`); process.exit(2); }
let r;
try { r = checkSkill(target, { trusted: loadKeys(opt('--key') || path.join(KIT, 'tools', 'trusted-keys.json')) }); }
catch (e) { console.error(`The skill could not be read: ${e.message}`); process.exit(1); }
printSkill(r);
console.log('');
if (r.red) { console.log('Not imported: there is at least one red line. No file was written.'); process.exit(1); }
const out = path.resolve(opt('--out') || `${r.name}.skill.json`);
if (fs.existsSync(out)) { console.log(`Not imported: ${out} already exists. Choose another name with --out.`); process.exit(1); }
const s = deskSkill(r);
fs.writeFileSync(out, JSON.stringify(s, null, 1) + '\n', { flag: 'wx' });
console.log(`Written: ${out}
It holds { title, body, description }, the shape the desk's route POST /api/m/agents/skills takes.

Two ways to add it:
1. In the desk: Agents, open an agent, the tab "Tools and skills", press "Write a skill". Paste the name
   "${s.title}" in the first box and the "body" text in the second. The skill is added and switched on for that agent.
2. In the desk's own window only, its browser console (F12, Console), paste:
     await apd.api('m/agents/skills', { body: <the whole contents of ${path.basename(out)}> })
   It is added switched off; tick it on for an agent in Tools and skills. A script outside the desk's window cannot
   call this route: it needs the window's session and the paired browser.`);
