// The genuineness check for an AP Desk module (a folder or a zip). No dependencies.
//   node tools/check-module.mjs <folder or zip> [--key <publisher public key file>] [--run] [--json]
// Four parts: Shape, What it can do (the label), Signed by, Runs clean. Exits 1 on any red line.
// The check itself is tools/lib/check.mjs, a copy of the desk's own (app/core/module-check): the desk's Module Store and
// this kit check a module the same way. This file is only the command: it reads the kit's trusted keys (or --key), names
// the kit's own test host, and with --run hands in the kit's locked-down run (tools/lib/sandbox.mjs).
// This process only READS the module's files: it never loads the module's code. It cannot prove that code is harmless.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { checkModule as checkShared, openTarget, printReport, HONEST, LIMITS } from './lib/check.mjs';
import { loadKeys } from './lib/sig.mjs';
import { quietSqliteWarning } from './lib/desk-facts.mjs';
import { prepare, runOnceLocked, runTestsLocked } from './lib/sandbox.mjs';

export { openTarget, printReport, HONEST, LIMITS };
const KIT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const testhost = () => { try { return crypto.createHash('sha256').update(fs.readFileSync(path.join(KIT, 'samples', 'hello-notes', 'testhost.js'))).digest('hex'); } catch { return null; } };
const runner = (dir, id) => { const box = prepare(dir, id); try { const r = runOnceLocked(box); return { ...r, tests: runTestsLocked(box) }; } finally { box.cleanup(); } };

/** The kit's check: keys from tools/trusted-keys.json unless --key names a file; run only when asked. */
export function checkModule(dir, { keys = null, run = false, ...rest } = {}) {
  return checkShared(dir, { keys: keys || path.join(KIT, 'tools', 'trusted-keys.json'), testhost: testhost(), runner: run ? runner : null, ...rest });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  quietSqliteWarning();
  const args = process.argv.slice(2);
  const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
  const target = args.find((a, i) => !a.startsWith('--') && args[i - 1] !== '--key');
  let t = null;
  try {
    if (!target) { console.error('Say which module to check:\n  node tools/check-module.mjs <module folder or zip> [--key <publisher public key file>] [--run]'); process.exitCode = 2; }
    else if (opt('--key') && !(() => { try { return loadKeys(opt('--key')).length > 0; } catch { return false; } })()) { console.log(`That is not a public key file (${opt('--key')}). Give the file that ends in .pub.json, never the .key file.`); process.exitCode = 2; }
    else {
      try { t = openTarget(target); } catch (e) { console.log(`Module check: ${target}\n\nShape\n  RED    ${e.message}\n\nResult: 1 red line.`); process.exitCode = 1; }
      if (t) {
        const rep = await checkModule(t.dir, { keys: opt('--key'), run: args.includes('--run') });
        if (args.includes('--json')) console.log(JSON.stringify(rep, null, 1)); else printReport(rep);
        process.exitCode = rep.red ? 1 : 0;
      }
    }
  } catch (e) { console.log(`The check stopped: ${e.message}`); process.exitCode = 1; }
  finally { t?.cleanup(); const say = args.includes('--json') ? console.error : console.log; say(''); say(HONEST); }   // always, whatever happened above
}
