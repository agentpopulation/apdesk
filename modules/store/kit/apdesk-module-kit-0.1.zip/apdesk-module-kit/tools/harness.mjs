// A stand-in for AP Desk 0.1.1, so a module's server.js and its tests run with only this kit (no desk).
// It builds the same `ctx` the desk hands to activate(ctx) (CONTRACT.md), with every member a module may use, and gives
// tests a small "host" to drive it: call routes in-process, run tools, answer approvals, wait for jobs, press Panic.
//
//   import { openHost } from '<kit>/tools/harness.mjs';
//   const host = await openHost({ dir: '<module folder>', script: (body, n) => 'model reply' });
//   const r = await host.call('GET', '/api/m/<id>/notes');      // { status, json }
//   await host.close();
//
// What it does NOT copy from the desk is listed in NOTE-FOR-THE-CODING-AGENT.md ("What the harness does not copy").
// The fake model answers from a script. It tests plumbing only and is never proof that a feature works.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { pathToFileURL } from 'node:url';

// ---- what the desk 0.1.1 knows (copied from its app/core; ids only)
import { OFFICIAL_PLACES, DESK_MODULES, DESK_NUMBERS } from './lib/desk-facts.mjs';
export { OFFICIAL_PLACES, DESK_MODULES, DESK_NUMBERS };
// Stand-in providers, one of each tier the desk knows. The real desk lists its own provider ids (see its Models page);
// 'openrouter' is kept by name because the desk treats it specially (its "Paid models" switch, ":free" model ids).
const PROVIDERS = { 'paid-api': 'paid', 'signup-api': 'free-signup', openrouter: 'free-signup', custom: 'custom' };
const RESERVED_EVENTS = new Set(['panic', 'security', 'approval', 'modules', 'settings', 'agents', 'job', 'restart']);
const ACTIONS = ['file.write', 'file.delete', 'file.read.outside', 'shell.run', 'browser.open', 'browser.act', 'net.post', 'send.person', 'spend', 'module.toggle', 'install', 'login', 'calendar.write', 'custom'];
const POLICY = { 'file.write': ['allow', 'once', 'ask'], 'file.delete': ['allow', 'ask', 'ask'], 'file.read.outside': ['ask', 'ask', 'ask'], 'shell.run': ['ask', 'ask', 'ask'], 'browser.open': ['allow', 'ask', 'ask'], 'browser.act': ['allow', 'once', 'ask'], 'net.post': ['allow', 'ask', 'ask'], 'calendar.write': ['ask', 'ask', 'ask'], 'module.toggle': ['ask', 'ask', 'ask'], install: ['ask', 'ask', 'ask'], login: ['ask', 'ask', 'ask'], custom: ['ask', 'ask', 'ask'], 'send.person': ['ask', 'ask', 'ask'], spend: ['limit', 'ask', 'ask'] };
const LEVELS = ['open', 'careful', 'strict'];
const SQL_FORBIDDEN = new Set(['secrets', 'settings', 'approvals', 'activity', 'kv', 'migrations', 'modules']);
const SQL_READ_ONLY = new Set(['agents', 'jobs', 'calls']);
const DEFAULT_SETTINGS = { theme: 'dark', online: true, ownerName: '', companyName: '', 'business.about': '', country: 'IN', currency: 'INR', timeZone: 'Asia/Kolkata', locale: 'en-IN', 'router.enabled': true, 'model.defaultChain': ['router', 'ollama', 'keyed'], 'openrouter.allowPaid': false, 'spend.perItem': 200000, 'spend.perDay': 500000, 'spend.perMonth': 2000000, 'security.level': 'open', 'model.smallLocalLast': true };
const SEED_AGENTS = [['coordinator', 'Coordinator'], ['scout', 'Scout'], ['closer', 'Closer'], ['operator', 'Operator'], ['coder', 'Coder']];

const now = () => new Date().toISOString();
const rid = (p) => p + crypto.randomBytes(5).toString('hex');
const err = (code, message, extra = {}) => Object.assign(new Error(message), { code, ...extra });
const isLocal = (p) => p === 'ollama' || p === 'llama' || String(p).startsWith('lan:');
const freeOR = (m) => /:free$/.test(String(m || '')) || m === 'openrouter/free';
const tableOk = (id) => 'm_' + id.replace(/-/g, '_') + '_';

// ---- SQL guard (a simplified copy of the desk's: by position only; the desk also asks SQLite which tables a statement opens)
export function splitSql(sql) {
  const out = []; let cur = ''; let q = null; const s = String(sql);
  for (let i = 0; i < s.length; i++) {
    const c = s[i], n = s[i + 1];
    if (q) { cur += c; if (c === q) { if (n === q) { cur += n; i++; } else q = null; } continue; }
    if (c === '-' && n === '-') { const e = s.indexOf('\n', i); i = e < 0 ? s.length : e; cur += ' '; continue; }
    if (c === '/' && n === '*') { const e = s.indexOf('*/', i + 2); i = e < 0 ? s.length : e + 1; cur += ' '; continue; }
    if (c === "'" || c === '"' || c === '`') { q = c; cur += c; continue; }
    if (c === ';') { if (cur.trim()) out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
export function checkSql(stmt, moduleId) {
  const bare = String(stmt).replace(/'(?:[^']|'')*'/g, "''").replace(/["`[\]]/g, ' ').toLowerCase();
  const refuse = (why) => { throw err('sql_forbidden', `${moduleId}: this SQL is not allowed for a module (${why}). Use the ctx helpers for core data.`); };
  if (/^\s*(attach|detach)\b/.test(bare)) refuse('attach');
  if (/^\s*vacuum\b/.test(bare)) refuse('vacuum');
  if (/^\s*pragma\b/.test(bare) && !/^\s*pragma\s+(table_info|table_xinfo|index_list|index_info|foreign_key_list|user_version|page_count|page_size|freelist_count)\b/.test(bare)) refuse('pragma');
  if (/^\s*create\s+(temp\s+|temporary\s+)?(trigger|view)\b/.test(bare)) refuse('triggers and views are not available to modules');
  const at = /\b(?:from|join|into|update(?:\s+or\s+[a-z]+)?|table|on|references)\s+(?:if\s+(?:not\s+)?exists\s+)?(?:(?:main|temp)\s*\.\s*)?([a-z_][a-z0-9_]*)/g; let m;
  while ((m = at.exec(bare))) {
    if (SQL_FORBIDDEN.has(m[1])) refuse(`table ${m[1]}`);
    if (SQL_READ_ONLY.has(m[1]) && !/^\s*(select|with|explain)\b/.test(bare)) refuse(`table ${m[1]} is read-only`);
  }
}
export function safeJoin(root, ...parts) {
  const rel = path.normalize(path.join(...(parts.length ? parts.map(String) : ['.'])));
  const abs = path.isAbsolute(rel) ? path.resolve(rel) : path.resolve(root, rel);
  if (abs !== root && !abs.startsWith(root + path.sep)) throw err('escape', 'Path escapes the workspace');
  return abs;
}
const bindHash = (payload, amount) => {
  const norm = (v) => v && typeof v === 'object' ? (Array.isArray(v) ? v.map(norm) : Object.fromEntries(Object.keys(v).sort().map((k) => [k, norm(v[k])]))) : (v ?? null);
  return crypto.createHash('sha256').update(JSON.stringify([norm(payload ?? null), amount != null && Number.isFinite(Number(amount)) ? Math.round(Number(amount)) : null])).digest('hex');
};

/**
 * Open a stand-in desk with one module (and stand-ins for others it talks to).
 *   dir          the module folder (module.json, server.js)
 *   script       (body, n) => string | { text, toolCalls: [{ name, args }], status, delayMs }   the fake model, same shape as the desk's test helper
 *   localModels  [{ name: 'big-local:14b', parameters: '14.8B' }]   what the local model server reports (default none)
 *   keys         { 'paid-api': 1, 'signup-api': 1 }   providers that have a key (no real key is ever used)
 *   prices       (provider, model, usage) => minor units   cost recorded for a paid call (default: null, "not known")
 *   settings     extra settings (zone, currency, level, online ...)
 *   allowHosts   hosts ctx.fetch may reach; fetchImpl  the function used for them (default: refused)
 *   modules      { other: { ...exposed api } }   stand-ins for other modules this one calls
 *   on           false: do not switch the module on yet
 */
export async function openHost({ dir, script = null, localModels = [], keys = {}, prices = null, settings = {}, allowHosts = [], fetchImpl = null, modules = {}, on = true } = {}) {
  const moduleDir = path.resolve(dir);
  const manifest = JSON.parse(fs.readFileSync(path.join(moduleDir, 'module.json'), 'utf8'));
  const id = manifest.id || path.basename(moduleDir);
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'apd-harness-'));
  const dataDir = path.join(base, 'data'), workspace = path.join(dataDir, 'workspace'), backupsDir = path.join(base, 'backups');
  for (const d of [workspace, backupsDir, path.join(workspace, 'reports'), path.join(workspace, 'drafts')]) fs.mkdirSync(d, { recursive: true });

  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE migrations (module TEXT, version INTEGER, applied TEXT, PRIMARY KEY (module, version));
    CREATE TABLE kv (ns TEXT, key TEXT, value TEXT, PRIMARY KEY (ns, key));
    CREATE TABLE agents (id TEXT PRIMARY KEY, name TEXT); CREATE TABLE jobs (id TEXT PRIMARY KEY, kind TEXT, title TEXT, agent_id TEXT, chat_id TEXT, status TEXT, progress REAL, detail TEXT, input TEXT, output TEXT, error TEXT, created TEXT, updated TEXT, finished TEXT);
    CREATE TABLE calls (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, agent_id TEXT, purpose TEXT, provider TEXT, model TEXT, ok INTEGER, ms INTEGER, input_tokens INTEGER, output_tokens INTEGER, cost_minor INTEGER, currency TEXT, error TEXT);
    CREATE TABLE approvals (id TEXT PRIMARY KEY, action TEXT, title TEXT, status TEXT, amount INTEGER, decided TEXT);`);

  const S = { ...DEFAULT_SETTINGS, ...settings };
  const settingListeners = new Set();
  const panicState = { halted: false, ac: new AbortController(), hooks: new Set() };
  const events = []; const eventFns = new Set();
  const cards = []; const logs = []; const activityLog = []; const modelCalls = []; const approvalsAsked = [];
  const agents = new Map(SEED_AGENTS.map(([a, name]) => [a, { id: a, name, role: '', personality: '', instructions: '', model: { main: null, fallback: null }, tools: null, meta: {} }]));
  const secrets = new Map(); const pending = new Map(); const granted = new Map(); const once = new Map();
  const jobsRunning = new Map();
  const host = { id, manifest, dir: moduleDir, kind: 'harness', events, cards, logs, activity: activityLog, modelCalls, approvalsAsked, dataDir, workspace, answer: null, used: new Set() };
  const mark = (what) => host.used.add(what);

  const childSignal = (parent) => {
    const signals = [panicState.ac.signal]; if (parent) signals.push(parent);
    return AbortSignal.any(signals);
  };
  const emitCore = (type, data) => { events.push({ type, data }); for (const fn of eventFns) { try { fn(type, data); } catch {} } };

  // ---- model door
  let calls = 0;
  const modelDoor = {
    async chat(o = {}) {
      mark('model.chat');
      if (panicState.halted) throw err('halted', 'Everything is stopped. Press Resume first.');
      const signal = childSignal(o.signal);
      const online = S.online !== false;
      const a = o.agentId ? agents.get(o.agentId) : null;
      let chain = o.model?.provider ? [{ ...o.model }] : [a?.model?.main, a?.model?.fallback].filter((x) => x?.provider);
      if (!o.model?.provider) {
        if (S['router.enabled'] !== false) chain.push({ provider: 'router', model: null });
        if (localModels.length) chain.push({ provider: 'ollama', model: null });
        for (const p of Object.keys(keys)) chain.push({ provider: p, model: null });
      }
      if (!online) chain = chain.filter((c) => isLocal(c.provider));
      if (!chain.length) throw err(online ? 'no_provider' : 'offline', online ? 'No model is set up. Add a key, or start the local model server or the router, in Models.' : 'The desk is offline and no local model is running. Start the local model server or go online.');
      const attempts = [];
      for (const step of chain.slice(0, 6)) {
        if (signal.aborted) throw err('aborted', 'Stopped.', { attempts });
        const model = step.model || (step.provider === 'router' ? 'fake-model' : step.provider === 'ollama' ? localModels[0]?.name : 'default');
        if (step.provider === 'ollama' && !localModels.length) { attempts.push({ provider: 'ollama', model, ok: false, skipped: true, error: 'not available' }); continue; }
        if (!['router', 'ollama', 'llama'].includes(step.provider) && !step.provider.startsWith('lan:') && !keys[step.provider]) { attempts.push({ provider: step.provider, model, ok: false, skipped: true, error: 'not available' }); continue; }
        const paid = !(step.provider === 'router' || isLocal(step.provider) || freeOR(model));
        if (paid && overLimit()) { attempts.push({ provider: step.provider, model, ok: false, skipped: true, error: `not called: your ${overLimit()} is reached` }); continue; }
        const t0 = Date.now();
        try {
          if (step.provider === 'openrouter' && S['openrouter.allowPaid'] !== true && !freeOR(model)) throw Object.assign(new Error('Paid models of the model-router provider are switched off. Only free models are used.'), { status: 402 });
          const body = { model, messages: o.messages || [], stream: false, ...(o.tools?.length ? { tools: o.tools.map((f) => ({ type: 'function', function: f })) } : {}), ...(o.json ? { response_format: { type: 'json_object' } } : {}) };
          modelCalls.push({ ...body, provider: step.provider, purpose: o.purpose || 'chat' });
          let out = script ? await script(body, ++calls) : null;
          if (out == null) { const u = [...(o.messages || [])].reverse().find((m) => m.role === 'user'); out = 'FAKE: ' + (typeof u?.content === 'string' ? u.content : ''); }
          if (typeof out === 'string') out = { text: out };
          if (out.delayMs) await new Promise((res, rej) => { const t = setTimeout(res, out.delayMs); signal.addEventListener('abort', () => { clearTimeout(t); rej(err('aborted', 'Stopped.')); }, { once: true }); });
          if (signal.aborted) throw err('aborted', 'Stopped.', { attempts });
          if (out.status && out.status !== 200) throw Object.assign(new Error(out.text || 'fake error'), { status: out.status });
          const usage = { input: 10, output: 5 };
          const ms = Date.now() - t0;
          const cost = !paid ? 0 : (prices ? prices(step.provider, model, usage) ?? null : null);
          db.prepare('INSERT INTO calls (at, agent_id, purpose, provider, model, ok, ms, input_tokens, output_tokens, cost_minor, currency) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?)').run(now(), o.agentId || null, o.purpose || 'chat', step.provider, model, ms, usage.input, usage.output, cost, S.currency);
          attempts.push({ provider: step.provider, model, ok: true, ms });
          const small = isLocal(step.provider) && /(^|[:\-_])(0?\.\d+|1|1\.5|2|3|4)b\b/i.test(String(model));
          const text = String(out.text ?? '');
          return { text, json: o.json ? extractJson(text) : undefined, toolCalls: (out.toolCalls || []).map((t, i) => ({ id: 'call_' + i, name: t.name, args: t.args || {} })), model, provider: step.provider, via: null, label: label(step.provider, model), usage, ms, attempts, fallbackUsed: attempts.length > 1, ...(small ? { small: true } : {}) };
        } catch (e) {
          if (signal.aborted || e.code === 'aborted') throw err('aborted', 'Stopped.', { attempts });
          attempts.push({ provider: step.provider, model, ok: false, error: e.message, ms: Date.now() - t0 });
          db.prepare('INSERT INTO calls (at, agent_id, purpose, provider, model, ok, ms, input_tokens, output_tokens, cost_minor, currency, error) VALUES (?, ?, ?, ?, ?, 0, ?, 0, 0, 0, ?, ?)').run(now(), o.agentId || null, o.purpose || 'chat', step.provider, model, Date.now() - t0, S.currency, e.message);
        }
      }
      throw err('all_failed', 'No model answered. ' + attempts.map((x) => `${label(x.provider, x.model)}: ${x.error}`).join('; '), { attempts });
    },
    async embed() { mark('model.embed'); throw err('unavailable', 'No embedding model in the harness.'); },
    async active() {
      const out = [];
      if (S['router.enabled'] !== false) out.push({ provider: 'router', kind: 'router', label: 'Free API by Agent Population Desk', shortLabel: 'Free API', ok: S.online !== false, models: ['fake-model'], model: 'auto' });
      out.push({ provider: 'ollama', kind: 'local', label: 'Local model server', ok: localModels.length > 0, models: localModels.map((m) => m.name), detail: localModels.map((m) => ({ name: m.name, parameters: m.parameters || null, size: m.size || null })), model: localModels[0]?.name || null });
      for (const p of Object.keys(keys)) out.push({ provider: p, kind: 'keyed', label: p, ok: S.online !== false, keys: 1, models: ['default'], model: 'default' });
      return out;
    },
    providers: () => Object.fromEntries(Object.entries(PROVIDERS).map(([k, tier]) => [k, { name: k, tier, defaultModel: 'default', freeNote: null, signup: null, baseUrl: null }])),
    // the desk's order: the agent's own models, then model.defaultChain (router, ollama, then every provider with a key)
    resolve: (agentId) => {
      const a = agents.get(agentId); const chain = [];
      if (a?.model?.main?.provider) chain.push({ ...a.model.main, why: 'agent main' });
      if (a?.model?.fallback?.provider) chain.push({ ...a.model.fallback, why: 'agent fallback' });
      for (const step of S['model.defaultChain'] || ['router', 'ollama', 'keyed']) {
        if (step === 'router') { if (S['router.enabled'] !== false) chain.push({ provider: 'router', model: null, why: 'default' }); }
        else if (step === 'ollama') chain.push({ provider: 'ollama', model: null, why: 'default' });
        else if (step === 'keyed') for (const p of Object.keys(keys)) chain.push({ provider: p, model: null, why: 'default key' });
        else if (keys[step]) chain.push({ provider: step, model: null, why: 'default key' });
      }
      const online = S.online !== false;
      return { main: a?.model?.main || null, fallback: a?.model?.fallback || null, online, chain: online ? chain : chain.filter((c) => isLocal(c.provider)), whenOnline: chain };
    },
    label: (p, m) => label(p, m),
    async listModels(p) { return p === 'router' ? ['fake-model'] : p === 'ollama' ? localModels.map((m) => m.name) : keys[p] ? ['default'] : []; },
    async modelCatalog(p) { return { ok: !!keys[p], models: keys[p] ? [{ id: 'default', price: null }] : [], at: now(), needsKey: !keys[p], total: keys[p] ? 1 : 0, hiddenPaid: 0, error: null }; },
    async ollamaModels() { return { ok: localModels.length > 0, models: localModels.map((m) => ({ name: m.name, size: m.size || null, parameters: m.parameters || null })) }; },
    async routerModels() { return { ok: true, models: ['fake-model'] }; },
    freeRouter: () => ({ note: '', upstreams: [] }), routerCooling: () => [], learned: () => ({ rows: [] }), lastCalls: () => ({}),
    toolMessage: (r) => ({ role: 'assistant', content: r.text || '', tool_calls: (r.toolCalls || []).map((t) => ({ id: t.id, type: 'function', function: { name: t.name, arguments: JSON.stringify(t.args ?? {}) } })) }),
    keys: { list: () => Object.fromEntries(Object.keys(PROVIDERS).map((p) => [p, keys[p] ? [{ id: 'key_' + p, provider: p, label: 'Key 1', value: '••••', enabled: true, meta: {} }] : []])), add() { throw err('forbidden', 'The harness does not keep keys.'); }, toggle() {}, remove() {}, tier() {} },
    usage: () => ({ today: db.prepare('SELECT provider, model, COUNT(*) AS calls, SUM(ok) AS ok, SUM(input_tokens) AS input, SUM(output_tokens) AS output, COALESCE(SUM(cost_minor), 0) AS cost, SUM(CASE WHEN cost_minor IS NULL THEN 1 ELSE 0 END) AS unknown FROM calls GROUP BY provider, model').all(), recent: db.prepare('SELECT * FROM calls ORDER BY id DESC LIMIT 50').all() }),
    get online() { return undefined; },
  };
  const label = (p, m) => { const n = p === 'router' ? 'Free API' : p === 'ollama' ? 'Local model server' : p === 'llama' ? 'Local model on this PC' : String(p).startsWith('lan:') ? 'LAN node' : p; return m ? `${n} · ${m}` : n; };
  const spent = () => (db.prepare('SELECT COALESCE(SUM(cost_minor), 0) AS t FROM calls').get().t || 0) + (db.prepare("SELECT COALESCE(SUM(amount), 0) AS t FROM approvals WHERE action = 'spend' AND status = 'approved'").get().t || 0);
  const overLimit = () => spent() >= Number(S['spend.perDay']) ? 'daily spend limit' : spent() >= Number(S['spend.perMonth']) ? 'monthly spend limit' : null;

  // ---- approval door
  const level = () => (LEVELS.includes(S['security.level']) ? S['security.level'] : 'open');
  const approval = {
    async request(req = {}) {
      mark('approval.request');
      const action = ACTIONS.includes(req.action) ? req.action : 'custom';
      if (panicState.halted) return { ok: false, reason: 'halted', id: null };
      if (req.signal?.aborted) return { ok: false, reason: 'aborted', id: null };
      let size = 0; try { size = JSON.stringify(req.payload ?? null).length; } catch { return { ok: false, reason: 'bad_payload', id: null }; }
      if (size > 256 * 1024) return { ok: false, reason: 'too_large', id: null };
      const row = { id: rid('ap_'), action, title: String(req.title || action).slice(0, 300), detail: req.detail || null, payload: req.payload ?? null, amount: req.amount != null ? Math.round(Number(req.amount)) : null, currency: req.currency || S.currency, agentId: req.agentId || null, chatId: req.chatId || null, jobId: req.jobId || null, status: 'pending', created: now() };
      approvalsAsked.push(row);
      const rule = POLICY[action][LEVELS.indexOf(level())];
      const onceKey = `${action}|${req.agentId || ''}|${req.jobId || req.chatId || 'none'}`;
      let allow = false;
      if (action === 'send.person' || action === 'install') allow = false;
      else if (action === 'spend') { const a = Number(req.amount); allow = rule === 'limit' && Number.isFinite(a) && a > 0 && row.currency === S.currency && a <= S['spend.perItem'] && spent() + a <= S['spend.perDay'] && host.paymentsOn === true; }
      else if (rule === 'allow') allow = true;
      else if (rule === 'once') allow = once.has(onceKey);
      const insert = (status, how) => db.prepare('INSERT INTO approvals (id, action, title, status, amount, decided) VALUES (?, ?, ?, ?, ?, ?)').run(row.id, action, row.title, status, row.amount, now());
      if (allow) { row.status = 'approved'; insert('approved', 'level'); granted.set(row.id, { action, bind: bindHash(req.payload, req.amount) }); return { ok: true, how: 'level', id: row.id }; }
      return new Promise((resolve) => {
        const decide = (decision) => {
          if (!pending.has(row.id)) return; pending.delete(row.id);
          const status = decision === 'approve' ? 'approved' : decision === 'deny' ? 'denied' : decision;
          row.status = status; insert(status, decision === 'approve' || decision === 'deny' ? 'owner' : status);
          if (status === 'approved') { if (rule === 'once') once.set(onceKey, Date.now()); granted.set(row.id, { action, bind: bindHash(req.payload, req.amount) }); }
          emitCore('approval', { ...row });
          resolve(status === 'approved' ? { ok: true, how: 'owner', id: row.id } : { ok: false, reason: status, id: row.id });
        };
        pending.set(row.id, { row, decide });
        if (req.jobId) jobUpdate(req.jobId, { status: 'waiting', detail: 'Waiting for you: ' + row.title });
        emitCore('approval', { ...row });
        req.signal?.addEventListener('abort', () => decide(panicState.halted ? 'halted' : 'aborted'), { once: true });
        const auto = typeof host.answer === 'function' ? host.answer(row) : host.answer;
        if (auto === 'approve' || auto === 'deny') queueMicrotask(() => decide(auto));
      }).finally(() => { if (req.jobId) { const j = jobGet(req.jobId); if (j?.status === 'waiting') jobUpdate(req.jobId, { status: 'running', detail: 'Running' }); } });
    },
    assertGranted(gid, action, payload) {
      mark('approval.assertGranted');
      const g = granted.get(gid);
      if (!g || g.action !== action || g.usedAt) throw err('not_granted', 'No approval was granted for this send.');
      if (payload === undefined) throw err('not_granted', 'The sender must show what it is sending: assertGranted(id, action, payload).');
      if (bindHash(payload, approvalsAsked.find((r) => r.id === gid)?.amount) !== g.bind) throw err('not_granted', 'This is not the item the owner approved.');
      g.usedAt = now(); return true;
    },
    get level() { return undefined; },
    state: () => ({ level: level(), autoApproveUntil: null, pending: pending.size, limits: { perItem: S['spend.perItem'], perDay: S['spend.perDay'], perMonth: S['spend.perMonth'], currency: S.currency }, spentToday: spent(), spentMonth: spent() }),
    listPending: () => [...pending.values()].map((p) => ({ ...p.row })),
    endScope: (scope) => { let n = 0; for (const k of [...once.keys()]) if (k.endsWith('|' + scope)) { once.delete(k); n++; } return n; },
    listStopped: () => approvalsAsked.filter((r) => r.status === 'halted'),
    dismissStopped: () => 0,
    get: (gid) => approvalsAsked.find((r) => r.id === gid) || null,
  };

  // ---- jobs
  const jobRow = (r) => r && { id: r.id, kind: r.kind, title: r.title, agentId: r.agent_id, chatId: r.chat_id, status: r.status, progress: r.progress, detail: r.detail, input: r.input ? JSON.parse(r.input) : null, output: r.output ? JSON.parse(r.output) : null, error: r.error, created: r.created, updated: r.updated, finished: r.finished };
  const jobGet = (jid) => jobRow(db.prepare('SELECT * FROM jobs WHERE id = ?').get(jid));
  const jobUpdate = (jid, patch) => {
    const sets = [], vals = [];
    for (const [k, v] of Object.entries(patch)) { sets.push(`${k} = ?`); vals.push(v && typeof v === 'object' ? JSON.stringify(v) : v); }
    db.prepare(`UPDATE jobs SET ${sets.join(', ')}, updated = ? WHERE id = ?`).run(...vals, now(), jid);
    const j = jobGet(jid); emitCore('job', j); return j;
  };
  const jobs = {
    async start({ kind, title, agentId = null, chatId = null, input = null, quiet = false, run } = {}) {
      mark('jobs.start');
      if (panicState.halted) throw err('halted', 'Everything is stopped. Press Resume first.');
      if (typeof run !== 'function') throw new Error('jobs.start needs run()');
      if (quiet) input = { ...(input && typeof input === 'object' ? input : {}), quiet: true };
      const jid = rid('job_'); const t = now();
      db.prepare("INSERT INTO jobs (id, kind, title, agent_id, chat_id, status, progress, detail, input, created, updated) VALUES (?, ?, ?, ?, ?, 'running', 0, 'Starting', ?, ?, ?)").run(jid, kind, title, agentId, chatId, JSON.stringify(input), t, t);
      const ac = new AbortController(); const signal = childSignal(ac.signal);
      const handle = {
        id: jid, kind, title, agentId, chatId, input, signal,
        progress(p, detail) { if (!signal.aborted) jobUpdate(jid, { progress: Math.max(0, Math.min(1, Number(p) || 0)), detail: detail ?? null }); },
        waiting(detail) { jobUpdate(jid, { status: 'waiting', detail: detail ?? 'Waiting for you' }); },
        resumed(detail) { jobUpdate(jid, { status: 'running', detail: detail ?? 'Running' }); },
        card(card) { if (chatId) cards.push({ chatId, card: { ...card, jobId: jid, agentId } }); },
        throwIfStopped() { if (signal.aborted) throw err('aborted', 'Stopped'); },
      };
      const promise = (async () => {
        try {
          const output = await run(handle);
          if (signal.aborted) jobUpdate(jid, { status: 'stopped', detail: 'Stopped', finished: now() });
          else jobUpdate(jid, { status: 'done', progress: 1, detail: 'Done', output: output ?? null, finished: now() });
        } catch (e) {
          if (signal.aborted || e?.code === 'aborted' || e?.code === 'halted' || e?.name === 'AbortError') jobUpdate(jid, { status: 'stopped', detail: 'Stopped', finished: now() });
          else jobUpdate(jid, { status: 'failed', error: String(e?.message || e), detail: 'Failed', finished: now() });
        } finally { jobsRunning.delete(jid); }
      })();
      jobsRunning.set(jid, { ac, promise });
      emitCore('job', jobGet(jid));
      return jobGet(jid);
    },
    list: ({ status, limit = 100 } = {}) => (status ? db.prepare('SELECT * FROM jobs WHERE status = ? ORDER BY created DESC LIMIT ?').all(status, limit) : db.prepare('SELECT * FROM jobs ORDER BY created DESC LIMIT ?').all(limit)).map(jobRow),
    get: jobGet,
    stop(jid, reason = 'Stopped by owner') { const r = jobsRunning.get(jid); if (r) r.ac.abort(reason); const j = jobGet(jid); if (j && (j.status === 'running' || j.status === 'waiting')) jobUpdate(jid, { status: 'stopped', detail: reason, finished: now() }); return jobGet(jid); },
    async wait(jid, timeoutMs = 30000) { const r = jobsRunning.get(jid); if (r) await Promise.race([r.promise, new Promise((res) => setTimeout(res, timeoutMs).unref?.())]); return jobGet(jid); },
    summary: () => Object.fromEntries(['running', 'waiting', 'done', 'failed', 'stopped', 'interrupted'].map((s) => [s, db.prepare('SELECT COUNT(*) AS c FROM jobs WHERE status = ?').get(s).c])),
  };

  // every call a module makes to a door is noted (host.used), so the checker can say which doors it really called
  const watched = (name, door) => Object.freeze(Object.fromEntries(Object.keys(door).map((k) => {
    const d = Object.getOwnPropertyDescriptor(door, k);
    if (typeof d.value !== 'function') return [k, k === 'keys' ? door.keys : d.get ? undefined : d.value];
    return [k, (...a) => { mark(`${name}.${k}`); return d.value.apply(door, a); }];
  })));

  // ---- the module's own ctx
  const routes = []; const tools = new Map(); let exposed = null; let handle = null; let active = false;
  const moduleApis = { ...modules };
  const ctx = {
    id, manifest: { ...manifest, dir: moduleDir }, dir: moduleDir, port: 0,
    route(method, p, handler) { mark('route'); routes.push({ method: method.toUpperCase(), parts: ('/api/m/' + id + (p.startsWith('/') ? p : '/' + p)).replace(/\/$/, '').split('/'), handler }); },
    json(res, data, status = 200) { if (res.writableEnded) return; res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data ?? null)); },
    readBody: async (req) => Buffer.from(req._raw || ''),
    db: {
      exec: (sql) => { mark('db'); for (const st of splitSql(sql)) { checkSql(st, id); db.exec(st); } },
      prepare: (sql) => { one(sql); return db.prepare(sql); },
      run: (sql, ...p) => { one(sql); return db.prepare(sql).run(...p); },
      get: (sql, ...p) => { one(sql); return db.prepare(sql).get(...p); },
      all: (sql, ...p) => { one(sql); return db.prepare(sql).all(...p); },
      transaction: (fn) => { db.exec('BEGIN'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; } },
      migrate: (version, x) => {
        mark('db.migrate');
        if (db.prepare('SELECT 1 FROM migrations WHERE module = ? AND version = ?').get(id, version)) return false;
        ctx.db.transaction(() => { if (typeof x === 'function') x(ctx.db); else ctx.db.exec(x); db.prepare('INSERT INTO migrations VALUES (?, ?, ?)').run(id, version, now()); });
        return true;
      },
    },
    kv: {
      get: (k, f) => { mark('kv'); const r = db.prepare('SELECT value FROM kv WHERE ns = ? AND key = ?').get('m:' + id, k); if (!r) return f; try { return JSON.parse(r.value); } catch { return f; } },
      set: (k, v) => { mark('kv'); db.prepare('INSERT INTO kv VALUES (?, ?, ?) ON CONFLICT(ns, key) DO UPDATE SET value = excluded.value').run('m:' + id, k, JSON.stringify(v ?? null)); },
      del: (k) => { db.prepare('DELETE FROM kv WHERE ns = ? AND key = ?').run('m:' + id, k); },
      all: () => Object.fromEntries(db.prepare('SELECT key, value FROM kv WHERE ns = ?').all('m:' + id).map((r) => [r.key, JSON.parse(r.value)])),
    },
    workspace, workspacePath: (...parts) => { mark('workspacePath'); return safeJoin(workspace, ...parts); }, dataDir, backupsDir, root: base, deskDataDir: dataDir, houseBackupsDir: null,
    model: watched('model', modelDoor), approval: watched('approval', approval), jobs: watched('jobs', jobs),
    panic: { get signal() { return panicState.ac.signal; }, get halted() { return panicState.halted; }, onStop: (fn) => { panicState.hooks.add(fn); return () => panicState.hooks.delete(fn); }, child: (s) => childSignal(s) },
    events: {
      emit: (type, data) => {
        mark('events.emit');
        if (RESERVED_EVENTS.has(String(type))) throw err('reserved_event', `Only the core emits '${type}' events.`);
        if (!/^[a-zA-Z][a-zA-Z0-9._-]{0,60}$/.test(String(type))) throw err('bad_event', 'An event type is one plain word.');
        emitCore(type, data);
      },
      on: (fn) => { eventFns.add(fn); return () => eventFns.delete(fn); },
    },
    agents: { list: () => [...agents.values()], get: (a) => agents.get(a) || null, update: (a, p) => { const x = agents.get(a); if (!x) return null; Object.assign(x, p); return x; }, create: (a) => { agents.set(a.id, { ...a }); return a; }, remove: (a) => agents.delete(a), systemPrompt: (a, extra) => [`You are ${agents.get(a)?.name || 'an agent'}.`, extra].filter(Boolean).join('\n') },
    settings: {
      get: (k) => { mark('settings.get'); return S[k]; }, all: () => ({ ...S }),
      onChange: (fn) => { settingListeners.add(fn); return () => settingListeners.delete(fn); },
      setOwnerText: (k, v) => { if (k !== 'business.about') throw new Error('Only the owner\'s business text can be saved this way.'); S[k] = String(v ?? '').trim().slice(0, 600); return S[k]; },
    },
    secrets: {
      get: (n) => { mark('secrets'); return secrets.get(n) ?? null; }, set: (n, v) => { mark('secrets'); if (v == null || v === '') secrets.delete(n); else secrets.set(n, String(v)); },
      has: (n) => secrets.has(n), list: () => [...secrets.keys()].map((name) => ({ name, created: now() })),
    },
    serviceKey: (sid) => host.serviceKeys?.[sid] ?? null, services: { list: () => [] }, serviceKeyRefused: () => false,
    tool(def) { mark('tool'); if (!def?.name || typeof def.run !== 'function') throw new Error('ctx.tool needs name and run'); tools.set(def.name, { name: def.name, description: def.description || '', parameters: def.parameters || { type: 'object', properties: {} }, run: def.run }); },
    untool(name) { tools.delete(name); },
    expose(api) { mark('expose'); exposed = api; },
    chatCard(chatId, card) { mark('chatCard'); cards.push({ chatId, card }); return null; },
    modules: { api: (x) => (x === id ? exposed : moduleApis[x] || null), isOn: (x) => x === id ? active : !!moduleApis[x], list: () => [], tools: () => [...tools.values()].map((t) => ({ name: t.name, module: id, description: t.description, parameters: t.parameters })), runTool: (n, a, c) => host.runTool(n, a, c) },
    log: (...a) => logs.push(a.map(String).join(' ')),
    activity: (title, detail) => { mark('activity'); activityLog.push({ title: String(title || '').slice(0, 300), detail: detail ? String(detail).slice(0, 1000) : null }); },
    requestRestart: () => { host.restartRequested = true; },
    async fetch(url, init = {}) {
      mark('fetch');
      const u = new URL(String(url));
      if (S.online === false && !['127.0.0.1', 'localhost', '::1'].includes(u.hostname)) throw err('offline', 'The desk is offline.');
      if (panicState.halted) throw err('halted', 'Everything is stopped. Press Resume first.');
      if (!allowHosts.includes(u.hostname) || typeof fetchImpl !== 'function') throw err('refused', `The harness does not reach ${u.hostname}. Allow it in the test (allowHosts and fetchImpl).`);
      return fetchImpl(u, { ...init, signal: childSignal(init.signal) });
    },
  };
  const one = (sql) => { mark('db'); const parts = splitSql(sql); if (parts.length > 1) throw err('sql_forbidden', `${id}: one statement at a time here; use db.exec for a script.`); if (parts.length) checkSql(parts[0], id); };

  // ---- the host the tests drive
  const match = (method, p) => {
    const parts = p.replace(/\/$/, '').split('/');
    for (const r of routes) {
      if (r.method !== method) continue;
      const params = {}; let ok = r.parts.length === parts.length || r.parts.includes('*');
      for (let i = 0; ok && i < r.parts.length; i++) {
        if (r.parts[i] === '*') { params.rest = parts.slice(i).map(decodeURIComponent).join('/'); break; }
        if (r.parts[i].startsWith(':')) params[r.parts[i].slice(1)] = decodeURIComponent(parts[i] ?? '');
        else if (r.parts[i] !== parts[i]) ok = false;
      }
      if (ok) return { r, params };
    }
    return null;
  };
  Object.assign(host, {
    ctx, tools, settings: S,
    routes: () => routes.map((r) => ({ method: r.method, full: r.parts.join('/'), path: '/' + r.parts.slice(4).join('/') })),
    /** Call one of the module's routes: host.call('POST', '/api/m/<id>/notes', { text }, { owner: true }) -> { status, json } */
    async call(method, p, body, { owner = true } = {}) {
      const url = new URL(p, 'http://harness.local');
      const hit = match(method.toUpperCase(), url.pathname);
      if (!hit) return { status: 404, json: { error: 'That module is off or has no such route.' } };
      let status = 200, text = '', ended = false;
      const res = { headersSent: false, get writableEnded() { return ended; }, setHeader() {}, writeHead(s) { status = s; this.headersSent = true; }, write(c) { text += c; }, end(c) { if (c) text += c; ended = true; } };
      const req = { method: method.toUpperCase(), url: url.pathname + url.search, headers: {}, _raw: body === undefined ? '' : JSON.stringify(body) };
      try { await hit.r.handler(req, res, { query: Object.fromEntries(url.searchParams), params: hit.params, body, owner }); }
      catch (e) { status = e?.status || (e?.code === 'halted' ? 503 : 500); text = JSON.stringify({ error: String(e?.message || e), code: e?.code }); ended = true; }
      if (!ended) { status = 200; text = JSON.stringify({ ok: true }); }
      let json = null; try { json = JSON.parse(text); } catch {}
      return { status, json, text };
    },
    async runTool(name, args = {}, call = {}) {
      const t = tools.get(name); if (!t) throw err('no_tool', `No such tool: ${name}`);
      if (panicState.halted) throw err('halted', 'Everything is stopped. Press Resume first.');
      return t.run(args, { agentId: 'coordinator', chatId: null, emitCard: (c) => cards.push({ chatId: call.chatId || null, card: c }), ...call, signal: childSignal(call.signal) });
    },
    pendingApprovals: () => approval.listPending(),
    decide(aid, decision) { const p = pending.get(aid); if (!p) throw new Error('No such waiting approval.'); p.decide(decision); },
    async nextApproval(timeoutMs = 5000) { const t0 = Date.now(); while (Date.now() - t0 < timeoutMs) { const p = approval.listPending()[0]; if (p) return p; await new Promise((r) => setTimeout(r, 10)); } return null; },
    waitJob: (jid, ms) => jobs.wait(jid, ms),
    job: (jid) => jobGet(jid),
    setSetting(k, v) { S[k] = v; for (const fn of settingListeners) { try { fn(k, v); } catch {} } },
    async panic() { panicState.halted = true; const ac = panicState.ac; panicState.ac = new AbortController(); ac.abort('halted'); for (const fn of panicState.hooks) { try { await fn('Panic'); } catch {} } for (const jid of [...jobsRunning.keys()]) jobs.stop(jid, 'Panic'); for (const p of [...pending.values()]) p.decide('halted'); },
    resume() { panicState.halted = false; },
    async switchOn() {
      if (active) return true;
      routes.length = 0; tools.clear(); exposed = null;
      const mod = await import(pathToFileURL(path.join(moduleDir, 'server.js')).href + '?h=' + Date.now());
      try { handle = typeof mod.activate === 'function' ? (await mod.activate(ctx)) || null : null; active = true; }
      catch (e) { routes.length = 0; tools.clear(); exposed = null; host.startError = String(e?.message || e); throw Object.assign(new Error(`${manifest.name} could not start: ${e?.message || e}`), { status: 500 }); }
      return true;
    },
    async switchOff() { if (!active) return true; try { await handle?.deactivate?.(); } catch (e) { logs.push('deactivate error ' + e.message); } routes.length = 0; tools.clear(); exposed = null; active = false; return true; },
    async close() { for (const jid of [...jobsRunning.keys()]) jobs.stop(jid, 'closing'); await host.switchOff(); try { db.close(); } catch {} fs.rmSync(base, { recursive: true, force: true }); },
  });
  Object.defineProperties(host, { api: { get: () => exposed }, isOn: { get: () => active } });   // live views, not copies
  if (on && fs.existsSync(path.join(moduleDir, 'server.js'))) await host.switchOn();
  return host;
}

export function extractJson(text) {
  if (!text) return null;
  const s = String(text).replace(/```(?:json)?/gi, '').trim();
  try { return JSON.parse(s); } catch {}
  const a = s.indexOf('{'), b = s.lastIndexOf('}'); if (a >= 0 && b > a) { try { return JSON.parse(s.slice(a, b + 1)); } catch {} }
  return null;
}
export { tableOk as tablePrefix };
