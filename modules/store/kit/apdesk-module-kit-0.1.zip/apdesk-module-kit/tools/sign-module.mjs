// Signs a module or skill folder: writes module.sig.json (or skill.sig.json with --skill) listing every file with its
// SHA-256, the publisher's name and key id, and an Ed25519 signature over that list.
//   node tools/sign-module.mjs <folder> --key <private key file> --publisher "Your name" [--skill]
// The key is a PKCS#8 PEM Ed25519 key from tools/make-module-keys.mjs or the desk's tools/make-update-keys.mjs.
// Sign last: any change to any file afterwards shows as "A file changed after signing".
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { signFolder, verifyFolder, SIG_FILE, SKILL_SIG_FILE } from './lib/sig.mjs';

const args = process.argv.slice(2);
const stop = (line) => { console.error(line); process.exit(1); };
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
const dir = args.find((a, i) => !a.startsWith('--') && !['--key', '--publisher', '--id'].includes(args[i - 1]));
const keyFile = opt('--key'); const publisher = opt('--publisher');
if (!dir || !keyFile || !publisher) stop('Use: node tools/sign-module.mjs <folder> --key <private key file> --publisher "Your name" [--skill]');
const folder = path.resolve(dir);
if (!fs.existsSync(folder) || !fs.statSync(folder).isDirectory()) stop(`${folder} is not a folder.`);
const key = path.resolve(keyFile);
if (key.startsWith(folder + path.sep)) stop('Refused: the private key is inside the folder you are signing. Keep it outside.');
const skill = args.includes('--skill');
const sigName = skill ? SKILL_SIG_FILE : SIG_FILE;
let name = path.basename(folder);
if (!skill) { try { name = JSON.parse(fs.readFileSync(path.join(folder, 'module.json'), 'utf8')).id || name; } catch { stop('module.json is missing or not valid JSON; check the module first.'); } }
let keyId = opt('--id');
if (!keyId && fs.existsSync(key + '.pub.json')) { try { keyId = JSON.parse(fs.readFileSync(key + '.pub.json', 'utf8')).id; } catch {} }
let rec;
try { rec = signFolder(folder, { keyFile: key, publisher, keyId: keyId || 'unnamed', name, sigName }); } catch (e) { stop('Not signed: ' + e.message); }
fs.writeFileSync(path.join(folder, sigName), JSON.stringify(rec, null, 1) + '\n');
const back = verifyFolder(folder, [{ id: rec.keyId, publicKey: rec.publicKey }], sigName);
if (back.state !== 'signed') { fs.rmSync(path.join(folder, sigName)); stop('The signature did not check out, so it was removed: ' + back.line); }
console.log(`Signed ${rec.files.length} files of ${name} as ${publisher} (key ${rec.keyId}) into ${path.join(folder, sigName)}.
Public key fingerprint: ${crypto.createHash('sha256').update(rec.publicKey).digest('hex').slice(0, 16)}`);
