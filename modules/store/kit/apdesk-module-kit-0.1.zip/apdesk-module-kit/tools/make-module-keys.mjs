// Makes a key pair for signing modules and skills, in the same format as AP Desk's own update keys
// (the desk's tools/make-update-keys.mjs): an Ed25519 private key in a PKCS#8 PEM file, and a public key entry
// { id, added, publicKey } to give to the people who will check what you sign.
//   node tools/make-module-keys.mjs <file to save the private key in> [--id <name>]
// Use a key of its own for modules, not the key that signs desk updates: if a module key leaks, someone can sign modules
// in your name, but not desk updates.
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { fileURLToPath } from 'node:url'; import { fingerprint } from './lib/sig.mjs';

const KIT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const args = process.argv.slice(2);
const stop = (line) => { console.error(line); process.exit(1); };
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
const target = args.find((a, i) => !a.startsWith('--') && args[i - 1] !== '--id');
if (!target) stop('Say where to save the private key, outside this kit. For example:\n  node tools/make-module-keys.mjs D:\\keys\\modules.key');
const file = path.resolve(target);
if (!fs.existsSync(path.dirname(file))) stop(`The folder ${path.dirname(file)} does not exist. Make it first, or choose another place.`);
const same = (p) => (process.platform === 'win32' ? p.toLowerCase() : p);
const real = same(fs.realpathSync(path.dirname(file))), kit = same(fs.realpathSync(KIT));
if (real === kit || real.startsWith(kit + path.sep)) stop(`Refused: ${file} is inside the kit. A private key must never sit beside what it signs, where it could be zipped and sent.`);
if (fs.existsSync(file)) stop(`Refused: ${file} already exists. Nothing was overwritten.`);
const id = opt('--id') || `modules-${new Date().toISOString().slice(0, 10)}`;
if (!/^[A-Za-z0-9._-]{1,40}$/.test(id)) stop('The --id may use letters, digits, dots, dashes and underscores only.');
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
fs.writeFileSync(file, privateKey.export({ type: 'pkcs8', format: 'pem' }), { flag: 'wx', mode: 0o600 });
const entry = { id, added: new Date().toISOString().slice(0, 10), publicKey: publicKey.export({ type: 'spki', format: 'der' }).toString('base64') };
fs.writeFileSync(file + '.pub.json', JSON.stringify(entry, null, 1) + '\n', { flag: 'wx' });
console.log(`The private key is saved in ${file}
Its public key is saved in ${file}.pub.json:

${JSON.stringify(entry, null, 1)}

Its fingerprint: ${fingerprint(entry.publicKey)}

Keep the private key (${path.basename(file)}) off the internet and out of every folder you zip. Give only the file that ends in
.pub.json, never the .key file. Whoever checks your modules passes it with --key; tell him the fingerprint by another way
(phone, in person), so he knows the key is yours.`);
