// Adds a checked module to an AP Desk folder.
//   node tools/add-module.mjs <module folder or zip> --desk <path to the AP Desk folder> [--key <public key file>] [--run] [--yes] [--replace]
// It runs the check (with --run, also the locked-down run; see tools/check-module.mjs) and prints the label. A red line refuses.
// This process never loads the module's code. Just before the copy every file is hashed again and compared with the
// hashes the check took first; any difference refuses, so what is copied is exactly what was checked. Yellow lines are asked about (y/N); --yes accepts
// yellow lines for scripts and never skips a red one. An existing module of that id is kept unless --replace, and then it is
// kept beside the new one as <id>.old-<date>, with its module.json and test files renamed with ".old", so the desk
// neither loads it as a second module nor runs its tests.
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import { fileURLToPath } from 'node:url';
import { checkModule, openTarget, printReport } from './check-module.mjs';
import { copyFolder, deskModulesDir, listAll } from './lib/files.mjs';
import { hashFolder, loadKeys } from './lib/sig.mjs';
import { HONEST } from './check-module.mjs';
import { quietSqliteWarning } from './lib/desk-facts.mjs';

/** Is this an AP Desk folder? */
export function isDesk(desk) { return fs.existsSync(path.join(desk, 'app', 'server.js')) && fs.existsSync(path.join(desk, 'modules')); }

/** Where the old copy goes: <id>.old-<date>, then -2, -3 ... if that is taken. */
export function oldName(modulesDir, id, date = new Date(), p = path) {
  const d = date.toISOString().slice(0, 10);
  let name = `${id}.old-${d}`; let n = 2;
  while (fs.existsSync(p.join(modulesDir, name))) name = `${id}.old-${d}-${n++}`;
  return name;
}

/** Copy the checked folder into <desk>/modules/<id>. Returns what was done. */
export function install(dir, id, desk, { replace = false, date = new Date(), hashes = null } = {}) {
  const modulesDir = deskModulesDir(desk);
  if (hashes) {   // the files must be the very ones the check read
    const now = new Map(hashFolder(dir, '').map((x) => [x.path, x.sha256])); const then = new Map(hashes.map((x) => [x.path, x.sha256]));
    const diff = [...new Set([...now.keys(), ...then.keys()])].find((p) => now.get(p) !== then.get(p));
    if (diff) throw new Error(`Refused: ${diff} changed after it was checked. Nothing was changed in the desk.`);
  }
  const target = path.join(modulesDir, id);
  let kept = null;
  if (fs.existsSync(target)) {
    if (!replace) throw new Error(`The desk already has a module called "${id}" (${target}). Nothing was changed. Use --replace to put this one in its place; the old one is kept beside it.`);
    kept = oldName(modulesDir, id, date);
    fs.renameSync(target, path.join(modulesDir, kept));
    // the old copy must stay asleep: the desk loads every modules/*/module.json, and its test runner runs every
    // modules/**/*.test.js, so both are renamed with ".old" (rename them back to bring the old copy back)
    for (const x of listAll(path.join(modulesDir, kept))) if (x.kind === 'file' && (x.rel === 'module.json' || /\.test\.m?js$/.test(x.rel))) fs.renameSync(x.abs, x.abs + '.old');
  }
  copyFolder(dir, target);
  return { target, kept };
}

async function main() {
  quietSqliteWarning();
  const args = process.argv.slice(2);
  const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
  const src = args.find((a, i) => !a.startsWith('--') && !['--desk', '--key'].includes(args[i - 1]));
  const desk = opt('--desk');
  if (!src || !desk) { console.error('Use: node tools/add-module.mjs <module folder or zip> --desk <path to the AP Desk folder> [--run] [--yes] [--replace]'); process.exit(2); }
  if (opt('--key') && !(() => { try { return loadKeys(opt('--key')).length > 0; } catch { return false; } })()) { console.error(`That is not a public key file (${opt('--key')}). Give the file that ends in .pub.json, never the .key file. Nothing was changed.`); process.exit(2); }
  const deskDir = path.resolve(desk);
  if (!isDesk(deskDir)) { console.error(`${deskDir} does not look like an AP Desk folder (no app/server.js and modules folder). Nothing was changed.`); process.exit(1); }
  let t;
  try { t = openTarget(src); } catch (e) { console.error(`Refused: ${e.message} Nothing was changed.`); process.exit(1); }
  try {
    const rep = await checkModule(t.dir, { keys: opt('--key'), run: args.includes('--run') });
    printReport(rep);
    console.log(''); console.log(HONEST); console.log('');
    if (rep.red) { console.log('Not added: there is at least one red line. Nothing was changed in the desk.'); process.exitCode = 1; return; }
    if (rep.yellow && !args.includes('--yes')) {
      if (!process.stdin.isTTY) { console.log('Not added: there are yellow lines and no one to ask. Read them, then run again with --yes to accept them.'); process.exitCode = 1; return; }
      const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
      const a = (await rl.question(`Add ${rep.manifest.name} with ${rep.yellow} yellow line${rep.yellow === 1 ? '' : 's'}? Type y to add it, anything else to stop: `)).trim().toLowerCase();
      rl.close();
      if (a !== 'y' && a !== 'yes') { console.log('Not added. Nothing was changed.'); process.exitCode = 1; return; }
    }
    const r = install(t.dir, rep.id, deskDir, { replace: args.includes('--replace'), hashes: rep.hashes });
    console.log(`Added ${rep.manifest.name} to ${r.target}.${r.kept ? ` The old one is kept as ${path.join(path.dirname(r.target), r.kept)} (its module.json and test files renamed with .old, so the desk does not load or test it).` : ''}`);
    console.log('Next: restart the desk (stop.bat then start.bat, or stop and start it the way you usually do).');
    console.log(`Then switch it on in Settings › Modules (the Module Store). It starts off until you do.`);
  } catch (e) { console.error(e.message); process.exitCode = 1; }
  finally { t.cleanup(); }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
