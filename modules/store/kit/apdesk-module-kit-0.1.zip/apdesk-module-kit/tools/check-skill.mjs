// Checks a skill before it is brought into AP Desk. Nothing in it is run.
//   node tools/check-skill.mjs <skill folder with SKILL.md, or a .md file> [--key <publisher public key file>]
// Exits 1 on any red line.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkSkill, printSkill } from './lib/skill.mjs';
import { loadKeys } from './lib/sig.mjs';

const KIT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };
const target = args.find((a, i) => !a.startsWith('--') && args[i - 1] !== '--key');
if (!target) { console.error('Use: node tools/check-skill.mjs <skill folder or .md file> [--key <public key file>]'); process.exit(2); }
if (opt('--key') && !(() => { try { return loadKeys(opt('--key')).length > 0; } catch { return false; } })()) { console.log(`That is not a public key file (${opt('--key')}). Give the file that ends in .pub.json, never the .key file.`); process.exit(2); }
try {
  const r = checkSkill(target, { trusted: loadKeys(opt('--key') || path.join(KIT, 'tools', 'trusted-keys.json')) });
  printSkill(r);
  process.exitCode = r.red ? 1 : 0;
} catch (e) { console.error(`The skill could not be read: ${e.message}`); process.exitCode = 1; }
