# The module contract of AP Desk 0.1.1

The reference that NOTE-FOR-THE-CODING-AGENT.md and GUIDE.md point into. Rewritten short from the desk's own contract
files (`app/core/contracts/MODULES.md`, `STORAGE.md`, `MODEL-DOOR.md`, `APPROVAL-DOOR.md`, `PEOPLE.md`) and checked
against the code of version 0.1.1 (`app/core/modules.js`, `storage.js`, `model-door.js`, `approval-door.js`,
`jobs.js`, `settings.js`, `app/server.js`, `app/ui/kit.js`, `app/ui/shell.js`). Where a contract file and the code
differ, this page says what the code does, and marks it **(code)**.

## 1. The folder

```
modules/<id>/
  module.json     the manifest (required)
  server.js       export async function activate(ctx) { ...; return { deactivate() {} } }   (optional)
  ui.js           browser module: export const pages, settings, agentTabs, chatCards, boot   (optional)
  ui-*.js, ui*.css, ui/...   more browser files: the ONLY other files the desk serves to the browser (code)
  *.test.js       node:test files; the desk's `npm test` runs modules/**/*.test.js
```
The desk reads every `modules/*/module.json` once, when it starts (code: `Modules.discover()` runs in the constructor
only). A new folder is seen after a restart. A folder with no `module.json` is ignored.

## 2. module.json

| field | required | what the desk does with it |
|---|---|---|
| `id` | yes | lower-case letters, digits, dashes; must equal the folder name (the desk falls back to the folder name when it is missing) |
| `number` | yes (kit) | sort order in the Module Store and at start. The desk 0.1.1 uses 1–32, 34, 35, 38. Pick 60 or above |
| `name` | yes | the card title in the Module Store, the Home tile, "X is switched off" notes |
| `description` | yes | the card text in the Module Store |
| `kind` | yes | `switch-on` for every added module. (`core` cannot be switched off; `parked` never starts) |
| `defaultOn` | no | `false` for an added module: it waits for the owner's switch |
| `menu` | no | `[{ id, label, order }]` places added after the eight official ones while the module is on; sorted by `order` (default 100). The desk's own use 113–119 |
| `pages` | no | page ids `ui.js` renders; a menu place must also be a page |
| `settings` | no | `[{ id, label }]` sections added to Settings; a section with the id of a core one replaces it |
| `agentTabs` | no | tabs added to an agent's page |
| `tools` | no | names of Coordinator tools `server.js` registers (shown on the Store card) |
| `requires` | no | module ids that must be on first; switching one of them off is refused while this is on |
| `npm` | no | packages the module needs; the desk installs nothing for a module. Leave it `{}` |
| `attribution` | no | lines for copied open-source parts, shown under Details |
| `boot` | no | `true` only for something on every screen: the shell calls `ui.js`'s `boot(ui)` at start |
| `status` | yes (kit) | `works`, `partial` or `stub`: shown as Works / Partly works / Placeholder |
| `hosts` | kit only | outside hosts the module calls through `ctx.fetch`, or `["*"]` for addresses the owner types in. The desk ignores it and does not enforce it; the kit's checker compares it with the code. It reaches the module as `ctx.manifest.hosts` (the desk hands over the whole manifest), so code can refuse other hosts itself |
| `commands` | kit only | wished-for chat commands, e.g. `[{ "name": "advisor", "hint": "..." }]`. The desk 0.1.1 has no slash commands and ignores it |

## 3. activate(ctx) and deactivate()

`activate` runs when the module is switched on: at start for a module that is on, or from the Module Store. It runs
once per space (a person's Work, Personal or Incognito space) with that space's own `ctx`. Keep everything inside it.
If it throws, the desk records the message, shows "Failed to start" and "Why: <message>" on the Store card, removes
whatever it registered, and goes on starting the others. `deactivate()` runs on switch-off; then the desk removes the
module's routes, tools and exposed API by itself. What the module started (timers, listeners, jobs) it stops itself.

## 4. ctx, member by member (code)

| member | what |
|---|---|
| `id`, `manifest`, `dir`, `port` | this module, its manifest, its folder, the desk's own port |
| `route(method, path, handler)` | registers `/api/m/<id><path>`. `:name` parts become `params.name`; a `*` part gives `params.rest`. `handler(req, res, { query, params, body, owner })`; `body` is parsed JSON; `owner` is true only for a request from the desk's own window |
| `json(res, data, status = 200)` | answers. A handler that throws answers `{ error }` with `e.status` or 500; one that writes nothing answers `{ ok: true }` |
| `readBody(req, limit)` | raw body bytes (for a non-JSON upload) |
| `db` | `exec(script)`, `prepare(sql)`, `run/get/all(sql, ...params)`, `transaction(fn)`, `migrate(version, sqlOrFn)` |
| `kv` | `get(key, fallback)`, `set(key, value)`, `del(key)`, `all()`: JSON values, this module's own |
| `workspace`, `workspacePath(...parts)` | the space's workspace folder; `workspacePath` joins inside it and throws `escape` for a path that leaves it |
| `dataDir`, `backupsDir`, `root` | the space's data folder, its backups folder, the install folder |
| `deskDataDir`, `houseBackupsDir` | the whole desk's data folder (every person's space) and the keeper's backups: for keeping closed, never for reading |
| `model` | the model door (section 6) |
| `approval` | the approval door (section 7) |
| `jobs` | `start({ kind, title, agentId, chatId, input, quiet, run })`, `list({ status, limit })`, `get(id)`, `stop(id)`, `wait(id, ms)`, `summary()` |
| `panic` | `signal` (aborted on Panic), `halted`, `onStop(fn)` (returns a remover), `child(signal)` (a signal that Panic or the parent aborts) |
| `events` | `emit(type, data)` to every open window (type: one word, letters, digits, `.`, `_`, `-`; not `panic`, `security`, `approval`, `modules`, `settings`, `agents`, `job`, `restart`), `on(fn)` in-process listener (returns a remover) |
| `agents` | `list()`, `get(id)`, `update(id, patch)`, `create(a)`, `remove(id)`, `systemPrompt(id, extra)` |
| `settings` | `get(key)`, `all()`, `onChange(fn)` (returns a remover), `setOwnerText('business.about', text)` (the only write; owner routes only) |
| `secrets` | `get(name)`, `set(name, value)` (empty removes), `has(name)`, `list()` (names and dates only) |
| `serviceKey(id)`, `services.list()`, `serviceKeyRefused(id, why)` | the owner's search and audio service keys; `null` when absent |
| `tool({ name, description, parameters, run })`, `untool(name)` | a Coordinator tool; `run(args, call)` with `call = { agentId, chatId, signal, emitCard(card) }`; returns a plain object |
| `expose(api)` | the object other modules get from `ctx.modules.api('<id>')` while this one is on |
| `chatCard(chatId, card)` | posts a card into a chat; `null` when Chat is off or the chat is gone |
| `modules` | `api(id)` (null when off), `isOn(id)`, `list()`, `tools()`, `runTool(name, args, call)` |
| `log(...)`, `activity(title, detail)` | a console line; one line in the owner's activity log |
| `requestRestart(reason)` | restarts the desk; owner routes only |
| `fetch(url, init)` | `fetch` that refuses the desk itself (`forbidden`), refuses while Offline unless the address is a local model server (`offline`), refuses after Panic (`halted`), and is aborted by Panic |

Not in the desk's MODULES.md table but given by the code: `json`, `readBody`, `kv.all`, `panic.child`, `events.on`,
`agents.create/remove/systemPrompt`, `settings.all/onChange`, `services`, `serviceKeyRefused`, `modules.list/tools/runTool`.
`ctx.tool` also stores an `agents` field that nothing reads in 0.1.1 (code).

## 5. Storage

- One SQLite file per space. A module's tables are named `m_<id>_<thing>`, with dashes in the id written as
  underscores (`hello-notes` -> `m_hello_notes_notes`).
- `ctx.db` refuses SQL that names `secrets`, `settings`, `approvals`, `activity`, `kv`, `migrations`, `modules`; allows
  only reading `agents`, `jobs`, `calls`; refuses `ATTACH`, `VACUUM`, most `PRAGMA`s, `CREATE TRIGGER`, `CREATE VIEW`.
  It does **not** stop a module from reading or writing another module's `m_<other>_...` tables: that rule is kept only by
  the module itself and by the kit's checker (which can follow only table names written out in the code).
  `prepare/run/get/all` take one statement; `exec` runs a script one checked statement at a time.
- `migrate(version, sql)` runs once per (module, version), inside a transaction. Never edit a shipped version; add the next.
- Times are stored as ISO strings in UTC; pages show them in the owner's zone. Money is integer minor units with a currency.
- A backup (Settings › Backup) holds the whole SQLite file (so your tables and kv) and the `workspace/` folder; it leaves
  out `secrets` unless the owner ticks "include keys". Files under `ctx.dir` or elsewhere in `ctx.dataDir` are not in it.
- Incognito: the database is in memory and the workspace is a scratch folder deleted on leaving. Nothing a module writes there
  is kept.

## 6. The model door: ctx.model

```js
const r = await ctx.model.chat({ messages, purpose, agentId?, model?: { provider, model }, json?, tools?, temperature?, maxTokens?, signal?, onDelta?, deadlineMs? });
// r = { text, json?, toolCalls: [{ id, name, args }], provider, model, label, usage: { input, output }, ms, attempts, fallbackUsed, small? }
```
- `purpose`: `chat`, `plan`, `research`, `draft`, `council`, `embed`, `vision`, `code`, `small`. It is written in the call
  log and orders the door's learning by kind of ask. Only `research` and `plan` change the chain (the rule below); no
  purpose picks a small or a big model, and none applies when you name a `model`. For a summary, `draft` is the plain choice.
- No `model`: the agent's main then fallback, then the default chain (Free API, then the local model server and the desk's
  own local model, then every provider with a key, in the owner's order, paid ones included). With `model`: that one only.
  `resolve(null).chain` lists that default chain, so a module can walk only its free and local steps (samples/advisor does).
- Provider ids are the desk's code words: `router` (the Free API), `ollama` (the local model server), `llama` (the desk's
  own local model), `lan:<node>`, `openrouter` (the model-router provider with its own Paid models switch), and the keyed
  providers of `providers()`. On screen, use the desk's labels (`r.label`, `active()[].label`), never these ids.
- Offline: only local providers (`ollama`, `llama`, `lan:<node>`) are called; an online pick fails with code `offline`.
- Errors: `ModelError` with `code` `offline`, `halted`, `no_provider`, `all_failed`, `aborted`; `message` is a plain sentence.
- For `purpose` `research` or `plan` and for any call with `tools`, a small local model (4B or less) is moved behind the keyed
  providers, unless the owner set `model.smallLocalLast` to false. `r.small` is true when a small local model answered.
- At most 6 real attempts; a paid model is skipped while the day's or month's spend limit is reached.
- Also: `embed({ texts })`, `active()` (what answers now: `[{ provider, kind, label, ok, models, detail? }]`),
  `providers()` (`{ id: { name, tier: 'paid'|'free-signup'|'custom', defaultModel, freeNote } }`), `listModels(p)`,
  `modelCatalog(p)`, `ollamaModels()`, `routerModels()`, `resolve(agentId)`, `label(p, m)`, `toolMessage(r)`, `usage()`
  (`{ today, recent }`, rows of the call log with `cost_minor`: 0 known free, a number, or null not known), `learned()`,
  `lastCalls()`, `freeRouter()`, `routerCooling()`.
- `keys.list()` gives every provider's keys masked. `keys.add/toggle/remove/tier` are given to every module by the code
  although the contract says only the Models page manages keys (code). An added module must not call them; the checker refuses it.
- `openrouter`: any model id not ending in `:free` is refused while the owner's "Paid models" switch is off. That switch
  (`openrouter.allowPaid`) is the only paid switch in the desk 0.1.1; other paid providers are paid as soon as a key is added.
- Always show `r.label`, never a model name of your own.

## 7. The approval door: ctx.approval

```js
const d = await ctx.approval.request({ action, title, detail?, payload?, amount?, currency?, agentId?, chatId?, jobId?, signal?, from? });
// d = { ok: true, how: 'level' | 'auto' | 'owner', id }  or  { ok: false, reason: 'denied' | 'timeout' | 'halted' | 'aborted' | 'too_large' | 'bad_payload', id }
```
| action | Open | Careful | Strict |
|---|---|---|---|
| `file.write` (in the workspace) | allow | ask once per job or chat turn | ask |
| `file.delete` (to the Bin) | allow | ask | ask |
| `file.read.outside` | ask once per folder, then remembered | same | ask |
| `browser.open` | allow | allow for sites already opened, else ask | ask |
| `browser.act` | allow | ask once per job | ask |
| `net.post` | allow | ask | ask |
| `shell.run`, `calendar.write`, `module.toggle`, `login`, `custom` | ask | ask | ask |
| `install`, `send.person` | ask, always, even in the auto-approve window | same | same |
| `spend` | allow within the limits while the Payments module is on, else ask | ask | ask |

- A request that asks waits until the owner decides (any screen), Panic (`halted`), the signal aborts, or 24 hours (`timeout`).
  Pass `jobId` so the job shows "Waiting for you".
- `title` is the one line the owner reads; `payload` is shown in full (only `login` and `file.read.outside` hide fields
  named like `password` or `token`); a payload over 256 KB is refused.
- Before a send to a person: `ctx.approval.assertGranted(d.id, 'send.person', payload)` with the exact payload; it works once.
- The card: type words from the action (`send.person` reads "Send to a person", `custom` reads "Action") and buttons Deny
  and "Approve and send" for `send.person`, "Approve" for every other action. An approval that records the owner's yes
  and sends nothing uses `custom`.
- Read-only: `state()` (`{ level, autoApproveUntil, pending, limits: { perItem, perDay, perMonth, currency }, spentToday, spentMonth }`),
  `listPending()`, `get(id)`, `listStopped()`. `endScope(chatId)` ends "ask once" grants of a chat turn. A module cannot decide.
- Spend: `spentToday` and `spentMonth` count approved `spend` amounts plus recorded model costs since local midnight of the
  computer, while the model door's own limit check counts from midnight in the owner's zone (code: two clocks).

## 8. Jobs

```js
const job = await ctx.jobs.start({ kind: '<id>.<what>', title: 'What the owner reads', chatId?, agentId?, input: {...}, run: async (job) => {
  job.progress(0.3, 'one line'); job.signal; job.card({ kind: 'progress', ... }); job.throwIfStopped(); job.waiting(); job.resumed();
  return { text: 'shown in Tasks' };
} });
```
Statuses: `running`, `waiting`, `done`, `failed`, `stopped` (Stop or Panic), `interrupted` (the desk restarted; never resumed).
A job with a `chatId` gets a live progress card in that chat. `quiet: true` is for the desk's own upkeep only.

## 9. ui.js

```js
export const pages = { '<page id>': { title, async render(el, ui, route) {}, unmount() {} } };
export const settings = { '<section id>': { title, async render(el, ui) {} } };
export const agentTabs = { '<tab id>': { title, async render(el, ui, agent) {} } };
export const chatCards = { '<id>.<kind>': (card, ui) => HTMLElement };
export function boot(ui) {}   // only with "boot": true
```
`ui` is the shell kit (GUIDE.md chapter 4 lists every helper). `ui.api(path, opts)` calls `/api/<path>` with the window's
session: call only your own routes, `m/<id>/...`. A page renders into one `.view` element, a flex column inside the
rounded pane; the pane scrolls, the window never does.

## 10. Panic and Offline

- Panic aborts `ctx.panic.signal` and every child of it (each job's signal, each model call, each `ctx.fetch`), runs
  `onStop` hooks, marks running jobs `stopped`, cancels waiting approvals as `halted`. While halted the doors refuse new work.
- Offline is one switch for the whole desk. `ctx.fetch` refuses then; so does the model door for online models. The desk
  also guards the process-wide `fetch` while Offline, but a module must still use `ctx.fetch` (Panic, the desk-itself rule).

## 11. What a module may not do

The desk 0.1.1 enforces only some of the list below (the SQL guard on core tables, the reserved events, `ctx.fetch`'s
Offline and Panic rules). It does not check the tools a module registers against `module.json`, nor `hosts`, nor another
module's tables: a module that is added runs with the desk's own powers, and the rest is up to the module and to the
owner's check before he adds it.

Write outside its folder; touch `app/`; name another module's tables or the core tables in SQL; call a model except through
`ctx.model`; cause a side effect that leaves the PC or changes something for a person except through `ctx.approval`; call
outside except through `ctx.fetch`; start a child process; run text as code; keep state outside `activate`; hold a secret
anywhere but `ctx.secrets`; decide an approval; emit the core's event types; change the security level, the spend limits,
the paid switch or Offline.
