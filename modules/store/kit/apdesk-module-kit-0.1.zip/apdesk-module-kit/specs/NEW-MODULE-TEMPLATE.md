# New module: the owner's sheet

Fill this in with short plain answers and give it to the coding agent with the kit zip and NOTE-FOR-THE-CODING-AGENT.md.

**Name** (one or two words, as you would say it):

**What it is for** (two or three sentences: what it does for you, and when you would open it):

**Where it lives** (its own place in the menu, a Settings section, a tool for the agents in Chat, or several):

**Pages** (what you see on each, top to bottom):

**What the agents can ask it to do** (tools, one line each):

**Which models** (none; the desk's usual free models; a small model for the ordinary work; a bigger "advisor" model to plan
and check; may it ever use a paid model, and up to what cost):

**What leaves this PC** (which websites or services it reads from or sends to; "nothing" is a fine answer):

**What needs my yes first** (sending to a person, posting, paying, deleting, changing files, anything else):

**What it must never do**:

**Done means** (how you will know it works: things you can check yourself on the screen, each answerable yes or no):

1.
2.
3.

**What I will test myself** (on which PC, which models):
