# Task sheet: take the Advisor further

Give this sheet, the kit zip and NOTE-FOR-THE-CODING-AGENT.md to the coding agent. Work in `samples/advisor/` of the kit.

## What exists (version 0.1 of the module, status "partial")

- The owner picks an advisor (any provider and model the desk offers; local models show their size) and a worker (a small
  model, or the desk's own chain, walked only on its free and local steps while paid calls are off). Kept in kv as
  `{ provider, model }`.
- A run: the advisor writes a brief (goal, 2 to 6 steps, 2 to 6 yes-or-no checks), the worker does it, the advisor answers
  each check yes / no / cannot tell with a reason and a verdict; "needs work" gives one more round; two rounds at most.
- Shape checks in code (`checkBrief`, `checkReview`), one second try on a malformed answer.
- A paid advisor only with the Advisor's own switch on, the desk's Paid models switch where it applies, and inside the
  spend limits (a provider of unknown billing needs the same switch); the most a run can cost ("up to about X", 6 advisor
  calls) from earlier calls or "cost not known"; after the run, the cost the desk recorded for each of its own calls.
- The owner's Accept or Send back (with a note, which starts a new run). Done = advisor "done" + owner Accept.
- One job per run, Stop and Panic end it; the tool `advisor_ask`; an exposed API (`start`, `get`, `list`).
- Tests with the fake model, passing in the kit's harness and in a desk. Not checked on a real or a paid model.

## What to add next, each with its acceptance checks

1. **Several advisors and a vote.** The owner may pick up to three advisors. Each reviews the same work; the verdict is
   "done" only if most say done; each check's answer shows every advisor's answer.
   - A test with three scripted advisors (2 done, 1 needs work) gives "done" and shows all three answers per check.
   - A test where one advisor is paid and refused runs with the other two and says which one was left out and why.
   - Cost is shown per advisor.
2. **A checklist library.** The owner can save a brief's checks as a named checklist and start a run with it; the advisor
   then writes only the steps.
   - Saving, listing, renaming and deleting checklists works from the page (owner-only routes, tested).
   - A run with a checklist sends no "checks" request to the advisor (assert on the fake model's calls).
3. **Advisor notes saved as lessons.** After an Accept, the owner may press "Keep as a lesson"; the advisor's notes go to
   the Memory module through `ctx.modules.api('memory')` (never its tables), only on that press.
   - With Memory off, the button says "Memory is off" and does nothing.
   - The lesson text is the advisor's notes as written, nothing added.
4. **"/advisor" once the desk has commands.** When the desk gains chat commands, wire the manifest's `commands` entry so
   `/advisor <work>` in Chat starts a run in that chat. Until then, do nothing here: do not read chat text with patterns.
   - Acceptance waits for the desk's command contract.
5. **A Stop button on a run.** Beside Accept and Send back while it works: an owner-only route that calls `ctx.jobs.stop`.
   - A test: Stop during the worker's call ends the run as "stopped", and no review call follows.
6. **Rounds and time limits the owner sets.** One or two rounds (default two); a per-run time limit after which the run stops
   with "stopped: took longer than N minutes".
   - Tests for one round, and for the time limit with a slow fake model.

## What not to touch

Anything outside `samples/advisor/` (copy `testhost.js` unchanged). The desk's own settings, the security level, the spend
limits, the paid switch, other modules' tables, the approval door's decisions. No new npm package. No pattern rules on the
owner's words or the model's text beyond the JSON shape checks.

## Done means

The kit's checker shows no red line for `samples/advisor`; its tests pass in the kit (`node --test samples/advisor/advisor.test.js`) and,
if a desk is at hand, in the desk; pictures of the page at 390 and 1366 px, dark and light; a list of what was not checked.
