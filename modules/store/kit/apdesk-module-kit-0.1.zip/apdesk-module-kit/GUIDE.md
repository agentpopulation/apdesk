# Building a module for AP Desk 0.1.1: the guide

One chapter per topic. Each says what it is, how a module uses it (with a short example copied from the samples in this
kit, which ran in a copy of the desk on Linux on 22 Nov 2026), the rules, and the mistakes people make. Where the desk
0.1.1 has no way for a module to do something, the chapter says so plainly.

The exact reference is CONTRACT.md. The working order for a coding agent is NOTE-FOR-THE-CODING-AGENT.md.
Code blocks marked "from samples/..." are checked by `tests/guide.test.mjs`: every line in them is in that file.

Contents: 1 Loading · 2 Main menu · 3 Module listing · 4 The look · 5 Choosing a model · 6 Budget and spend ·
7 Bench mode · 8 Settings of your own · 9 Tools, chat cards and jobs · 10 Approvals, Offline and Panic · 11 Storing things ·
12 Words on screen · 13 Testing and handing over · 14 Worked example: the Advisor · 15 Other modules built the same way

---

## 1. How a module loads

**What it is.** A module is one folder, `modules/<id>/`, inside the AP Desk folder. The desk reads every
`modules/*/module.json` once when it starts, then switches on the modules that should be on: core modules first, then the
others by `number`, each after the modules it `requires`.

**How a module uses it.** Three files: `module.json` (what it is), `server.js` (what it does), `ui.js` (what the owner sees).

<!-- from samples/hello-notes/module.json -->
```json
  "id": "hello-notes",
  "number": 61,
  "name": "Hello notes",
  "kind": "switch-on",
  "defaultOn": false,
  "menu": [{ "id": "hello-notes", "label": "Notes", "order": 150 }],
  "pages": ["hello-notes"],
  "settings": [{ "id": "hello-notes", "label": "Hello notes" }],
  "tools": ["notes_add"],
  "requires": [],
  "status": "partial"
```

<!-- from samples/hello-notes/server.js -->
```js
export async function activate(ctx) {
  ctx.db.migrate(1, `
  const offSettings = ctx.settings.onChange((key) => { if (key === 'timeZone') ctx.events.emit('hello-notes', { change: 'zone' }); });
  return {
    async deactivate() {
      offSettings();   // routes, tools and the exposed API are removed by the desk; what we started, we stop
```

- **Start.** A new folder is found only when the desk starts. After adding one: restart the desk, then switch the module
  on in Settings › Modules (the Module Store).
- **Switching on and off.** The owner's switch calls `activate(ctx)` or `deactivate()` at once, without a restart. On
  switch-off the desk removes the module's routes, tools, exposed API, menu places and Settings sections by itself; what
  the module saved stays for next time. The choice is kept in the desk's `modules` table.
- **Core against switch-on.** `core` modules are on from the first run and cannot be switched off. Every added module is
  `switch-on`. `parked` modules never start.
- **defaultOn.** What a fresh desk does. An added module says `false`: the owner switches it on himself.
- **requires.** Module ids that must be on first. The Store refuses to switch yours on before them ("X needs Y switched on
  first") and refuses to switch them off while yours is on. Prefer `ctx.modules.api(id)` returning `null` over `requires`:
  then your module works with less.
- **boot.** `"boot": true` makes the shell load `ui.js` at start and call its `boot(ui)`; only for something on every
  screen (a button in the top bar). Almost no module needs it.
- **When activate throws.** The desk keeps going. The module is off, its card in the Store says "Failed to start" and
  "Why: <your message>", and everything it registered before the throw is removed. So throw with a plain sentence.
- **More than one space and person.** A desk can hold several people, each with a Work and maybe a Personal or an
  Incognito space, in one process. Your module is switched on once per space, each time with that space's own `ctx`
  (its own database, workspace, settings, doors). So everything you hold lives inside `activate`, in closures, `ctx.db`
  and `ctx.kv`. A variable at the top of `server.js` is shared by every space and leaks one person's data to another.

**Rules.** The folder name equals `id`. `kind` is `switch-on`, `defaultOn` is `false`. `number` is 60 or above (the desk
uses 1 to 32, 34, 35 and 38). `activate` registers everything and returns `{ deactivate }`.

**Common mistakes.** State at the top of the file (`const cache = new Map()` outside `activate`). A timer or listener
never stopped in `deactivate`. Throwing a stack trace instead of a sentence. Expecting a new folder to appear without a
restart. Using `requires` for a module you only sometimes call.

---

## 2. The main menu

**What it is.** The top menu has eight official places, always first and in this order: Chat, Research, Tasks, Sales,
Files, Agents, Models, Settings. A switch-on module may add places after them, which show only while it is on.

**How a module uses it.** Name the place in `menu` (its `id` is also a page id in `pages`; `order` sorts the added places,
the desk's own use 113 to 119, so use 150 and up). Render the page in `ui.js` under the same id. Use the owner's own name
for the place in your texts:

<!-- from samples/hello-notes/ui.js -->
```js
      // the owner may have renamed this place in Settings › Menu: ui.label gives his name, else ours
      const title = ui.label('hello-notes', 'Notes');
```

- Page ids. The address of a page is `#/<page id>` (and `#/<page id>/<more>` with `route.parts`). A page in `pages` but not
  in `menu` opens by its address only (`ui.go('<page id>')`).
- The owner's menu. In Settings › Menu he can rename any place (up to 30 characters), move it, hide it (Settings itself
  cannot be hidden; a hidden place still opens by its address), and choose the place that opens first. This is his
  setting `ui.menu`; a module never writes it.
- Kit helpers: `ui.label(id, fallback)` (his name, else the role's label, else your fallback), `ui.placeName(id)` (his name
  or the default, `null` when it is not a place), `ui.menuPlaces()` (every place with its default name). When a page draws an
  `h2` with the default name of a renamed place, the shell swaps in the owner's name by itself.
- Doctor is shown as an icon in the top bar, not in the menu; that is the desk's own choice for one module.

**Rules.** Never take an official place id (`chat`, `research`, `tasks`, `sales`, `files`, `agents`, `models`, `settings`)
or another module's place. One menu place per module is plenty. Labels are one or two short words.

**Common mistakes.** A menu id missing from `pages` (the place opens "This place is not part of the desk"). Hard-coding the
label in a heading or a toast where the owner's own name should show. Calling `ui.saveMenu`: that is the owner's control.

---

## 3. The module listing

**What it is.** Settings › Modules is the Module Store: one card per module in two groups, "On from the first run" (core)
and "Switch on when you want them". An added module lands in the second group. Home shows a tile for each switch-on module
that is on and has a menu place ("Module is on. Open it.").

**What the card shows, from module.json:** the `number` in a small pill, the `name`, its state (On, Off, Failed to start,
Waiting for another module), the switch, the `description`, "Why: ..." when it failed, "Needs ... switched on first" from
`requires`, an "Adds ..." line built from `menu`, `settings`, `agentTabs` and `tools` ("Adds a place in the menu: Notes;
Settings › Hello notes; 1 tool for agents."), the `status` pill, and under Details the tool names and `attribution`.

<!-- from samples/advisor/module.json -->
```json
  "name": "Advisor",
  "description": "Your official advisor: a bigger model you choose writes a short brief with yes-or-no checks, a smaller model does the work, the advisor checks it, and you press Accept or Send back. Nothing is sent to anyone. A paid advisor is called only when you allow it and your spend limits do.",
  "status": "partial"
```

- `name`: what it is in one or two words, as the owner would say it ("Advisor", not "AdvisorModule").
- `description`: one to three short sentences a first-time user understands: what it does for him, what leaves the PC,
  what needs his yes. 30 to 400 characters.
- `status`: honest. `works` only when what it says was checked end to end in a desk. `partial` when part was checked only
  with the fake model or a stand-in, or a part is missing. `stub` when it is a placeholder. The Advisor says `partial`: its
  plumbing is checked, a real advisor's judgement is not.
- `attribution`: one line per copied open-source part, with its licence and address.

**Rules.** No marketing words ("powerful", "smart", "seamless"). No promise the code does not keep. Say "Nothing is sent"
only if nothing is.

**Common mistakes.** A description that names the code ("Registers routes for ...") instead of what the owner gets. Status
`works` for something only the fake model ever answered.

---

## 4. The look (theme)

**What it is.** AP Desk's look is "dark and bold": a control room with deep blue-black panels, one purple-to-pink accent,
green for live, amber for waiting, red only for Panic and failures. Light is its daytime twin with the same accents. The
owner switches with the sun icon in the top bar. All colours are CSS variables in `app/ui/shell.css`; a page that uses
them follows both themes for free.

**Tokens a module should use (the desk sets them for both themes):**

| token | for |
|---|---|
| `--fg`, `--dim`, `--faint` | main text, secondary text, hints and labels |
| `--surface`, `--raised`, `--well` | a card, something lifted inside a card, an input or a sunken box |
| `--line`, `--line-strong` | borders, and borders of inputs |
| `--brand`, `--brand-2`, `--brand-soft`, `--on-brand` | the accent (buttons, selected tab), its soft background, text on it |
| `--work`, `--work-head`, `--work-line` | a work panel (the thing the owner is doing now) |
| `--live` / `--live-soft` | answers, on, saved, done |
| `--slow` / `--slow-soft` | waiting, slow, needs you |
| `--info` / `--info-soft` | running |
| `--stop` / `--stop-soft`, `--fail` | Panic, failed, refused |
| `--r-l`, `--r`, `--r-s`, `--r-xs` | corner radius: 18, 14, 10, 7 px |
| `--s1` to `--s6` | spacing: 4, 8, 12, 16, 20, 28 px |
| `--ui`, `--mono` | the font and the code font (never set your own) |

**Ready classes:** `card` (a panel; `card live|slow|run|fail|off` adds a coloured top edge), `work` with `work-head` and
`work-body` (the work panel), `box`, `well`, `group`; `phead` with a `t` child (page heading row); `row`, `stack`, `two`
(two columns that become one under 860 px), `grow`, `tiles` with `stat`; `line` (a label, a hint and something on the
right), `lbl` (a small caps divider), `sub` (dim text), `empty` (an empty state), `caution` (a warning box); `btn`
(`btn ghost`, `btn sm`, `btn stop`), `chip`/`chips`, `pill` (`run`, `ok`, `wait`, `stop`), `schip` (status chip:
`live`, `slow`, `run`, `fail`, `off`), `tabbar` (tabs: buttons with `aria-selected="true"`), `seg`, `sw` (switch),
`meter`, `field` (a control with its saved mark), `saved`, `mono` (a coloured initials tile), `metric`, `md` (rendered
text), `scroll` (a table that scrolls sideways), `offnote`.

**Kit helpers (`ui.*`, from `app/ui/kit.js` and the shell):**
`h(tag, attrs, ...children)` makes an element (`class`, `style` object, `onclick`, `dataset`; `null` children are skipped);
`card`, `btn(text, { kind, onClick })`, `pill(text, kind)`, `statusChip(text, kind)`, `line(title, hint, ...right)`,
`empty(text)`, `spinner()`, `meter(p)`, `sw(on, label, onChange)`, `seg(options, index, onChange)`,
`table(cols, rows, { onRow, empty })`, `av(name)`, `md(text)` (safe Markdown), `toast(text, kind)`, `modal({ title, body, actions })`,
`confirm(text)`, `ask(title, { multiline })`, `savedMark()` (the "Saving…, tick, or cross with the reason" mark),
`announce(text)` (a line in the footer while something runs; call the function it returns when done),
`fmt.time/date/when/ago/money/bytes/pct` (in the owner's zone and currency), `api(path, opts)`, `on(type, fn)` (a server
event while the page is on screen), `onLeave(fn)`, `go(page, ...parts)`, `label`, `placeName`, `menuPlaces`,
`moduleOn(id)`, `agent(id)`, `state` (settings, modules, agents), `openFile(path)`, `refresh()`.
Not for modules: `decide`, `setLevel`, `setAutoApprove`, `setOnline`, `saveMenu`, `lockWindow`, `openChooser`,
`setSession` (the owner's own controls; the checker refuses a page that calls them).

**A complete small page, from the kit only:**

<!-- from samples/hello-notes/ui.js -->
```js
      el.append(
        h('div', { class: 'phead' },
          h('div', { class: 't' }, h('h2', null, title), h('p', { class: 'sub' }, 'Short notes you or the Coordinator write. They stay on this PC.')),
        h('div', { class: 'work', style: { flexShrink: '0' } },
          h('div', { class: 'work-head' }, h('h3', null, 'New note')),
          h('div', { class: 'work-body' }, box, h('div', { class: 'row' }, addBtn, mark))),
        h('div', { class: 'two' },
          card(h('div', { class: 'row' }, h('h3', null, 'Your notes'), h('span', { class: 'grow' }), count), listBody),
          card(h('h3', null, 'Summary'), summaryBody)));
```
It rendered with no console error, nothing wider than the window and no page scroll at 1366x768 and 390x844, dark and light.

**Two layout traps (seen only in a real desk; the harness never draws a page).**
1. The page (`.view`) is a flex column that scrolls. Its direct children may shrink when the page is taller than the pane,
   and one that hides its overflow (`.work`, or anything with `overflow: hidden`) is then cut off or squeezed to a bar. Give
   such a top-level block `style: { flexShrink: '0' }`, as above, or put it inside a plain `div`.
2. `line(title, hint, ...right)` does not wrap: it is for one short control on the right (a switch, a pill, a value). With
   two or more controls the text is squeezed to one word a line at 390 px and the controls cover it. Put several controls in
   a `row` (it wraps) under the text instead.

**A module's own CSS file.** The desk serves only these files of a module to the browser: `ui.js`, files under `ui/`, and
top-level files named `ui<something>.js` or `ui<something>.css` (for example `ui.css`, `ui-chart.js`). It does not add a
stylesheet by itself: the module's `ui.js` adds the link once, the way the Models module does:
```js
function css() {
  if (document.getElementById('models-css')) return;
  document.head.append(Object.assign(document.createElement('link'), { id: 'models-css', rel: 'stylesheet', href: '/modules/models/ui.css' }));
}
```
(from the desk's `modules/models/ui.js`). In that file, use only the tokens above and prefix every selector with a class of
your own (`.hello-notes-...`) so nothing else on the screen changes. Pictures (svg, png) are served only from `ui/`.

**Rules.** No colours, fonts or shadows of your own; tokens only. No emoji, in text or as icons. No bold on small controls
(buttons, pills and chips already have their weight). Nothing cut off: let text wrap; never shorten a sentence with
`slice` on screen. The page fills its pane and scrolls inside it: never `position: fixed`, never a fixed width wider than
390 px, never `overflow: hidden` on the page. Test at 390 px wide and in both themes.

**Common mistakes.** `color: #fff` (vanishes in light). Bold labels on every button. A table without `scroll` around it at
phone width. Building a menu or tabs of your own instead of `tabbar`. `el.replaceChildren(a, cond ? b : null)`: the browser
writes the word "null" (`h()` skips `null`, `replaceChildren` and `append` do not; filter first):

<!-- from samples/advisor/ui.js -->
```js
        // replaceChildren and append write a null as the word "null": leave empty parts out (h() itself skips null)
```

---

## 5. Choosing a model

**What it is.** Every model call goes through one door, `ctx.model`. The door picks the provider and model, rotates the
owner's keys, falls back, holds Offline, is stopped by Panic, records the call and its cost, and names the model that
answered. A module never imports a model library, opens a socket to a provider or reads a key.

**The agent's own chain.** Name no model: the door walks the agent's main and fallback (when you pass `agentId`), then the
default chain: the built-in Free API, then the local model server and the desk's own local model, then every provider with a key in the
owner's order, **paid ones included**. So a call with no model may reach a paid key (inside the spend limits). A module
whose owner said "no paid calls" walks only the free and local steps of that chain itself (`function workerSteps` at samples/advisor/server.js line 84).

<!-- from samples/hello-notes/server.js -->
```js
        const r = await ctx.model.chat({
          purpose: 'small', signal: job.signal, maxTokens: 120,
        // r.label names the model that really answered ("Free API · ..."); show it, never a name of our own
        const summary = { text: r.text.trim(), by: r.label, small: !!r.small, at: new Date().toISOString() };
```

**A named provider and model.** Pass `model: { provider, model }`; only that one is tried. `model` may be `null` for the
provider's default.

<!-- from samples/advisor/server.js -->
```js
    let r = await call(tally, { model: pick, messages, json: true, purpose, signal, maxTokens: 1200 });
```
(`call` is the sample's own wrapper around `ctx.model.chat` that also counts the call's cost; see chapter 6.)

**Which `purpose`.** It is written in the call log and orders the door's learning by kind of ask. Only `research` and `plan`
change the chain (the small-model rule below); no purpose picks a small or a big model, and a call that names its `model`
is not reordered at all. Use `draft` for a summary or a piece of writing, `plan` for a plan, `small` for a short chore.

**What the owner has, for a choice on a page.** `ctx.model.active()` lists what can answer now: `[{ provider, kind:
'router'|'local'|'keyed'|'lan', label, ok, models, detail }]`; for the local model server (`ollama`), `detail` carries each model's `parameters`
("14.8B"), so a page can say which are large. `ctx.model.providers()` gives each keyed provider's `tier`: `paid`,
`free-signup` or `custom`. `ctx.model.listModels(provider)` reads a provider's model ids with the owner's key.

<!-- from samples/advisor/server.js -->
```js
    const choices = active.map((a) => ({ provider: a.provider, label: a.shortLabel || a.label, kind: a.kind, ok: a.ok !== false, models: (a.detail || []).length ? a.detail.map((d) => ({ id: d.name, sizeB: sizeOf(d) })) : (a.models || []).map((m) => ({ id: m, sizeB: null })) }));
```

**Free, paid and local.** Free: the Free API (`router`), local models (`ollama`, `llama`, `lan:<node>`), OpenRouter ids ending
in `:free`. Paid: providers whose tier is `paid` (once the owner adds a key, the desk calls them), any model of the model-router provider (`openrouter`) not
ending in `:free` (refused while the owner's Paid models switch is off). Maybe: `free-signup` and `custom` providers, whose
billing depends on the owner's account; the desk records their cost as "not known" until the owner marks the key free or paid.

**Busy or refused.** The door tries the next target on a failure, at most 6 real tries; a free host that said "busy" rests
for a while and is skipped. A paid model is skipped once the day's or month's limit is reached. When nothing answers it
throws `all_failed` with a plain sentence (and `retryAt` when the free hosts are all resting). With tools, a local model that
cannot call tools is skipped. For `purpose` `research` or `plan`, and for any call with `tools`, a small local model
(4B or less) is moved to the end of the chain, behind the keyed providers; for a plain call, the owner's order holds. This
holds for a module's calls too: a module that wants a small worker first names it with `model`.

**Which model really answered.** `r.label` ("Free API · ...", "<the local model server> · <a local model>:14b"), `r.provider`, `r.model`, and
`r.small` when a small local model answered. Show the label next to the answer, always.

**The "big advisor, small workers" pattern.** A big model plans and checks; small models do the ordinary work; the owner
gives the last yes. Sizes, in the owner's words: the advisor is an online API model (free or paid) or a large local model
of the 14B to 27B kind; the workers are small models of 1B, 3B or 7B, local or free. Let the owner pick both, and keep the
pick in `kv` as `{ provider, model }` (worker `null` = the desk's usual chain, walked step by step so that only free and
local steps are called while paid calls are off). Call the advisor with `model: advisor` and the worker with `model: worker`. Ask the advisor for JSON and check its shape in code. Chapter 14 walks
through it.

**Offline.** Only local models answer. An online pick fails with `offline`. Say it before the call:

<!-- from samples/advisor/server.js -->
```js
    if (ctx.settings.get('online') === false && kind !== 'local') return `The desk is offline and your ${role} is an online model. Choose a local model or go online.`;
```

**Rules.** Every call through `ctx.model`, with `purpose` and the job's `signal`. Show `r.label`. Never guess which model
answered. Never read keys.

**Common mistakes.** Hard-coding a model name in the page text. Calling without `signal` (Stop does not stop it). Treating
`free-signup` as free. Calling `ctx.model.keys.add` or `remove`: the door hands them to every module, but only the Models
page may change keys; the checker refuses it. Reading the model's text with patterns to decide what to do: ask for JSON and
check its shape.

---

## 6. Budget and spend

**What it is.** The desk counts money in minor units of the owner's currency (paise for INR). The owner sets three limits
in Settings › Payments and spend: per item, per day, per month (`spend.perItem`, `spend.perDay`, `spend.perMonth`; a fresh
desk has 2,000, 5,000 and 20,000 in his currency). The only paid switch in 0.1.1 is the "Paid models" switch of the model-router provider (`openrouter`). Every model
call is written to the call log with `cost_minor`: `0` known free, a number estimated at the list price, or `null`, "cost
not known".

**How a module uses it.** Read the limits and what was spent, read-only:

<!-- from samples/advisor/server.js -->
```js
    const st = ctx.approval.state();   // read-only: the owner's limits and what was spent, in minor units of his currency
    if (st.limits.perDay != null && st.spentToday >= st.limits.perDay) return "Today's spend limit is reached, so no paid model is called.";
```

A likely cost before a paid call: the door does not hand modules its price list in 0.1.1, so a module can only go by the
desk's own record of earlier calls to that model (`ctx.model.usage().recent`), and must say "cost not known" otherwise:

<!-- from samples/advisor/server.js -->
```js
    const rows = (ctx.model.usage().recent || []).filter((r) => r.provider === pick.provider && (!pick.model || r.model === pick.model) && r.ok && r.cost_minor != null && r.cost_minor > 0);
    if (!rows.length) return { known: false, why: kind === 'maybe' ? 'it depends on your account with that provider' : 'there is no earlier call to this model to go by' };
```

Say "up to" when there are retries: the Advisor's most is 6 advisor calls a run (a brief and two reviews, each with one
second try), so it shows "up to about X a run".

After the calls, count what was recorded for **those very calls**, not by provider or by time (another module may call the
same model at the same time, and a worker on the desk's own chain may answer from a provider you did not pick). The door
writes one row per answer in the call log; take the row that matches each answer:

<!-- from samples/advisor/server.js -->
```js
  async function call(tally, opts) {
    const before = ctx.model.usage().recent?.[0]?.id ?? 0;
    const r = await ctx.model.chat(opts);
    const row = (ctx.model.usage().recent || []).filter((x) => x.id > before && x.ok && x.provider === r.provider && x.model === r.model).pop();
    tally.calls++; if (row && row.cost_minor != null) tally.minor += row.cost_minor; else tally.unknown++;
```
Show both numbers: known minor units, and how many calls are "cost not known". Money on screen goes through
`ui.fmt.money(minor, currency)`, with the currency from settings.

**Copy, do not rewrite.** The block from `const tiers =` to `async function askWorker` in `samples/advisor/server.js` (what a
pick costs, why it may not be called now, the most a run can cost, counting each call, the worker's free chain) does not
depend on the Advisor; copy it whole into a module that offers "a bigger model with its likely cost".

- **Refuse politely, before the call.** A module that can spend gives the owner a yes of his own before a paid call: either
  a switch of its own ("Paid advisor calls", off by default), or, where its Settings hold only one choice, a confirm on the
  page at each press (the route then refuses a paid pick that comes without that yes, for example `confirmPaid: true`).
  Either way it also checks the desk's paid switch where it applies, and the limits, before every paid call. A provider of
  unknown billing ("maybe") needs the same yes. The refusal is one sentence that says what to change.
- **The door holds too.** Even if a module forgets, the door skips a paid model once the day's or month's limit is reached,
  and counts every "not known" cost at the list price in that limit.
- **Paying for things** (not models) is `ctx.approval.request({ action: 'spend', amount, currency })`: allowed without a card
  only at the Open level, within the limits, in the owner's currency, while the Payments module is on; otherwise it asks.

**Rules.** Never a paid call the owner did not allow. Never a number for a cost the desk does not know: write "cost not
known". Money in the owner's currency from settings, never `$` or `₹` typed into the code.

**Common mistakes.** Showing `0` when the cost is `null`. Assuming the limits are in rupees (they are in the owner's
currency, whatever it is). Summing costs with floating point and rounding each call.

**Not in the desk 0.1.1** (asked for in the report): a way for a module to ask the door "what would this call cost?", and a
desk-wide paid switch for providers other than the model-router provider.

---

## 7. Bench mode

**What it is.** Bench mode (module 31, off until switched on) works while the owner is away from the desk's window: it looks
back at the desk's own work and looks up his market, in steps by how long he has been away, and leaves a note on "While you
were away" and on Home. Everything it finds is a proposal until he presses Keep, which applies it through the module that
owns it (a lesson to Memory, a skill to Agents, a lead to Sales, a task to Tasks, a draft to Mail). Before it spends anything
it must have the owner's money choice: Local only, Free, or Paid with a cap per session and per day.

**What a module can truly do with it today.** Read it, nothing more. Bench exposes `gate()` (the money choice),
`view()`, `current()`, `items(sessionId)`, `note()`, `returnPanel()` and more through `ctx.modules.api('bench')`. Its
activities are a fixed list inside Bench (`activities.js`, `RUN`); there is no call for another module to offer it work,
and no way to add to its return page. So in 0.1.1 a module can:
- read the money choice, and use the same choice for its own away-time work:

<!-- from samples/guide-extras/server.js -->
```js
    const bench = ctx.modules.api('bench');                // null while Bench mode is off
    if (!bench?.gate) return ctx.json(res, { on: false, text: 'Bench mode is off.' });
    const g = bench.gate();                                // { option: 'local' | 'free' | 'paid' | null, chosen, capSessionMinor, capDayMinor, limits }
```
- run its own work as an ordinary job and say on its own page what it did.

Bench's "Paid" means: use a paid route only where paid use is already allowed (the model-router provider's switch; a key in the default
chain for other providers), never turning paid on by itself; it falls back to free at its caps.

**Rules.** Do not reach into Bench's tables (`m_bench_*`). Do not write its money choice (`setGate` is exposed but is the
owner's choice, made on Bench's own page). In Incognito the desk refuses Bench outright.

**Common mistakes.** Treating `option: null` as "free": it means the owner has not chosen yet; do not spend.

**Not in the desk 0.1.1** (the smallest design is in the report): `bench.offer({ id, title, mode, run(b) })` so a module can
hand Bench one activity that runs inside Bench's budget and returns proposals, and `bench.addReturn(card)` for a line on its
return page.

---

## 8. Settings of your own

**What it is.** Each module keeps its own choices in `ctx.kv` (JSON values, namespaced by the desk) and may add one
section to Settings. The desk's own settings are read-only for modules.

**How a module uses it.** A route that saves, a section that shows a switch with the saved mark:

<!-- from samples/hello-notes/server.js -->
```js
  ctx.route('POST', '/settings', (req, res, { body, owner }) => {
    if (!owner) return ctx.json(res, { error: 'Settings change from the desk window only.' }, 403);
    if (typeof body?.newestFirst !== 'boolean') return ctx.json(res, { error: 'newestFirst is true or false.' }, 400);
    ctx.kv.set('newestFirst', body.newestFirst);
```

<!-- from samples/hello-notes/ui.js -->
```js
      // a switch that saves by itself; savedMark answers with a tick or the reason it did not save
      const toggle = sw(d.newestFirst, 'Newest note first', (on) => mark.run(() => ui.api(API + 'settings', { body: { newestFirst: on } })));
      el.append(card(h('h3', null, 'Hello notes'), line('Newest note first', 'Off puts your oldest note at the top', h('span', { class: 'field' }, toggle, mark))));
```

- The section is named in `module.json` `settings: [{ id, label }]` and drawn by `ui.js` `settings[id].render(el, ui)`. It
  appears after the desk's own sections. A section with the id of a core one (`general`, `security`, ...) replaces it: do not.
- **What a module may read** with `ctx.settings.get(key)`: `timeZone`, `currency`, `country`, `locale`, `ownerName`,
  `companyName`, `business.about`, `online`, `security.level`, `spend.perItem/perDay/perMonth`, `openrouter.allowPaid`,
  `theme`, `role`. On a fresh desk, country, currency, zone and locale come from the computer; nothing is assumed.
- **What it may not write.** Any of them. The one exception is `ctx.settings.setOwnerText('business.about', text)`, for the
  owner's own words about his business, from an owner route.

**Rules.** Every setting saves by itself and answers with the saved mark (or says why not). Validate the value in the
route. Owner-only routes refuse when `owner` is false.

**Common mistakes.** A Save button for one switch. Writing settings through `ui.api('settings', ...)` from a page. Keeping
a secret in `kv` (it goes in `ctx.secrets`).

---

## 9. Tools for the agents, chat cards and jobs

**Tools.** A tool is a function the Coordinator (and other agents) can call from a chat. Register it in `server.js` and
list its name in `module.json` `tools`. `run(args, call)` gets `call = { agentId, chatId, signal, emitCard(card) }` and
returns a plain object, which the agent reads (treat what you return as data the model will read; never put instructions
in it).

<!-- from samples/hello-notes/server.js -->
```js
  ctx.tool({
    name: 'notes_add',   // letters, digits and underscores only; listed in module.json "tools" too
    description: 'Add a short note to the owner\'s Hello notes list when he asks to note something down.',
    parameters: { type: 'object', properties: { text: { type: 'string', description: 'the note, in the owner\'s words' } }, required: ['text'] },
    async run(args, call) {
      const note = add(args.text, call.agentId || 'an agent');
      return { ok: true, text: `Noted: ${note.text}`, id: note.id };   // a plain object; the Coordinator reads it back
```

Per agent: on each agent's page, the tab "Tools and skills" lists tools by module with a switch; the owner decides which
agents may use your tools. Your module cannot choose (the `agents` field `ctx.tool` accepts is not read in 0.1.1).

**Chat cards.** `ctx.chatCard(chatId, card)` posts a card; in a tool, `call.emitCard(card)`. Kinds the Chat module draws:
`text`, `table` (`title`, `columns`, `rows`), `progress`, `file`, `draft`, `actions`, `sources`, `report`; others show as text.

<!-- from samples/guide-extras/server.js -->
```js
    const posted = ctx.chatCard(String(body?.chatId || 'dm-coordinator'), { kind: 'table', title: 'Two suppliers', columns: ['Supplier', 'Price'], rows: [['North Paper', 'not stated'], ['Lakeside Print', 'not stated']] });
```

**Jobs.** Any work longer than a moment, any model call, and any approval that may wait is a job. The route answers at
once with the job id; the job keeps running when the page closes.

<!-- from samples/hello-notes/server.js -->
```js
    const job = await ctx.jobs.start({
      kind: 'hello-notes.summary', title: 'Summarise my notes', input: { count: notes.length },
      async run(job) {
        job.progress(0.2, 'Asking a model');
```

- Progress: `job.progress(0..1, 'one line')`. A job started with a `chatId` gets a live progress card in that chat.
- Stop and Panic abort `job.signal`; pass it to every model call, fetch and approval. The job ends `stopped`.
- The tracker (the list icon in the top bar) and the footer line show running and waiting jobs by their `title`; Tasks lists
  them all. A page can add its own footer line while it works with `ui.announce('Reading the files…')`.
- A job's return value is its output (shown in Tasks); a throw is `failed` with your message. In a desk that message is
  shown on the Tasks page ("Did not finish" and the reason); the desk's own toast says only "Failed: <title>". If the owner
  must see the reason where he is, show it on your page too (listen with `ui.on('job', ...)` and read `j.error`).
- **Stop.** In 0.1.1 the owner stops one job from Tasks (or everything with Panic); a module page that wants its own Stop
  button calls a route of its own that calls `ctx.jobs.stop(jobId, 'Stopped by you')`. The Advisor sample has none yet
  (specs/ADVISOR-SPEC.md lists it).

**Rules.** Tool names: letters, digits, underscores. Every tool listed in `module.json`. Long work in a job with a clear
title. Always pass the job's `signal`.

**Common mistakes.** A route that waits for a model or an approval (the owner's page hangs). A tool that returns a huge
object (keep it short; the agent reads every word). A tool that does something the owner did not ask for in that turn.

---

## 10. Approvals, Offline and Panic

**What must go through the approval door.** Anything that leaves the PC or changes something for a person: sending to a
person (`send.person`, always asks), posting to an outside service (`net.post`), writing or deleting files (`file.write`,
`file.delete`), opening or acting in a browser, calendar writes, logins, installs, spending, and anything else with a side
effect (`custom`, always asks). The door alone decides by the owner's level (Open, Careful, Strict) and auto-approve window;
the module asks and waits. The table is in CONTRACT.md section 7.

<!-- from samples/hello-notes/server.js -->
```js
        const d = await ctx.approval.request({ jobId: job.id, action: 'file.write', title: `Save ${notes.length} note${notes.length === 1 ? '' : 's'} to ${rel}`, detail: 'Workspace › reports', payload: { path: rel, notes: notes.length }, signal: job.signal });
        if (!d.ok) return { saved: false, text: d.reason === 'denied' ? 'Not saved: you said no.' : `Not saved (${d.reason}).` };
```

- **How a card reads.** `title` is the one line the owner reads ("Save 3 notes to reports/hello-notes.md"); `detail` one
  more line; `payload` is shown in full, so put in it exactly what will happen. For a send: draft first, ask with the exact
  payload, then `assertGranted(id, 'send.person', payload)` right before sending.
- **A yes that sends nothing.** When the owner only approves something (a share he will send himself, a choice to record),
  use `action: 'custom'`. Its card reads "Action" with Deny and "Approve"; `send.person` would read "Send to a person" with
  "Approve and send", which is untrue when nothing is sent.
- **Levels.** The owner sets them in Settings › Security; a module only reads `ctx.settings.get('security.level')` if it wants
  to explain something. "Ask once" grants end with the job or chat turn.

**Offline.** One switch for the whole desk. `ctx.fetch` refuses with code `offline` before any network; the model door calls
only local models. Say it in plain words:

<!-- from samples/guide-extras/server.js -->
```js
      const r = await ctx.fetch('https://api.example.com/rate', { signal: ctx.panic.signal });
      const why = e.code === 'offline' ? 'The desk is offline, so the rate was not checked.' : e.code === 'halted' ? 'Everything is stopped. Press Resume first.' : 'The rate could not be read just now.';
```
Every outside host is listed in `module.json` `hosts`. The kit's checker refuses an undeclared host, but only one written
out in the code: an address built at run time is a yellow line, and `ctx.fetch` with no hosts declared at all is red. The
desk itself ignores the field in 0.1.1.

**Addresses the owner types in.** A module that reads any page the owner saves (a reading list, a price watch on shops he
names) cannot list its hosts in advance. It declares `"hosts": ["*"]`, which the report shows as one yellow line, takes the
address only from the owner (a route with `owner` true, or a tool call he asked for), checks it is `http:` or `https:`, and
still calls only `ctx.fetch` (so Offline, Panic and the desk-itself rule hold). A module with a fixed list can also refuse
any other host itself: the manifest reaches it as `ctx.manifest.hosts`.

**Pictures from outside.** The desk's page rules let a page load an image from any https address. A page that sets an
image or link address from data can carry what is on the screen to another host, so the checker refuses a computed `src`,
`new Image`, `fetch` in a page and an outside `url(...)` in css.

**Panic.** The red button stops everything: every job signal, model call and `ctx.fetch` is aborted, waiting approvals are
cancelled, and the doors refuse new work until Resume. End cleanly: catch the abort, save what state you have as "stopped",
and do not retry. Anything you start that the doors do not cover registers `ctx.panic.onStop(fn)` (and removes it on
deactivate).

<!-- from samples/advisor/server.js -->
```js
      const stopped = job.signal.aborted || e.code === 'aborted' || e.code === 'halted';
```

**Rules.** Never decide an approval (the door gives modules no way to). Never send without a granted `send.person`. Never
call outside except through `ctx.fetch`.

**Common mistakes.** Asking with a vague title ("Do the action"). A payload that differs from what is then sent. Treating
`timeout` or `halted` as a no from the owner in the words on screen ("You said no" when he never saw it).

---

## 11. Storing things

**Tables.** Named `m_<id>_<thing>` (dashes in the id become underscores). Created and changed only by `ctx.db.migrate`:

<!-- from samples/hello-notes/server.js -->
```js
  // migrate(version, sql) runs once per version, ever; add a version 2 later for a new column, never edit version 1.
  ctx.db.migrate(1, `
    CREATE TABLE IF NOT EXISTS m_hello_notes_notes (
```
The desk refuses SQL that names its own tables (`secrets`, `settings`, `approvals`, `activity`, `kv`, `migrations`,
`modules`), allows only reading `agents`, `jobs`, `calls`, and refuses triggers, views, `ATTACH` and most `PRAGMA`s. It does
**not** stop a module from reading another module's `m_..._` tables: keep to your own prefix, and write table names out in
the SQL (a name built at run time is a yellow line in the check, because nobody can tell which table it opens).

**kv.** Small choices and last results: `ctx.kv.get(key, fallback)`, `set`, `del`, `all`.

**Secrets.** Tokens and passwords only in `ctx.secrets`; never in kv, a log, an event or a route's answer:

<!-- from samples/guide-extras/server.js -->
```js
    ctx.secrets.set('token', String(body?.token || ''));   // an empty value removes it
    ctx.json(res, { saved: ctx.secrets.has('token') });     // say whether it is there, never what it is
```

**Files.** In the workspace only, through `ctx.workspacePath(...)`, which refuses a path that climbs out. Files there show in
the Files page; open one for the owner with `ui.openFile(path)`.

**Other modules.** Through what they expose, never their tables:

<!-- from samples/guide-extras/server.js -->
```js
    const notes = ctx.modules.api('hello-notes');           // null while Hello notes is off
```

**What a backup carries.** The whole SQLite file (your tables and kv) and the workspace folder. Secrets only if the owner
ticks "include keys". Not your module folder, not other folders in the data folder. A restore brings your tables back as
they were; write migrations that cope with an older version.

**Incognito.** The database is in memory and the workspace is a scratch folder, both dropped when the person leaves:
nothing your module stores there is kept. Do not promise "saved" in a way that suggests otherwise; the desk shows the
Incognito notice itself.

**Rules.** One table prefix. Times in UTC ISO strings. Money as integer minor units with the currency.

**Common mistakes.** `CREATE TABLE` outside `migrate`. Editing migration 1 after it shipped. Writing to `ctx.dir` (the module
folder is replaced when the module is updated).

---

## 12. Words on screen

The owner's rules, with good and bad side by side.

| bad | good | the rule |
|---|---|---|
| "Error: ECONNREFUSED 127.0.0.1:11434" | "The local model server is not running. Start it, or choose another model." | plain short words; say what to do |
| "Done! 🎉" | "Saved to reports/notes.md in your workspace." | no emoji; say what happened |
| "run_lz3k9a failed" | "The advisor's brief was not in the agreed form, so the run stopped." | no internal ids |
| "Cost: null" / "undefined" | "Cost not known: it depends on your account with that provider." | never null or undefined on screen |
| "2026-11-22T14:05:00Z" | "8:12 pm" (`ui.fmt.when`, in the owner's zone) | times in the owner's zone |
| "$0.0000" | "₹40" for an INR owner, "$0.48" for a USD owner (`ui.fmt.money`) | money in the owner's currency from settings |
| (button does nothing visible) | "Saving…" then a tick, or "Not saved: <why>" | every action answers back |
| "The price is ₹1,200." (no page said it) | "Price: not checked." | never invent data; say "not checked" |
| "Checked." (after the fake model) | "Checked with a stand-in model only; not checked on a real model." | say what was really checked |
| **Bold Save** on a small button | Save | no bold on small controls |
| "Write a short follow-up for the three customers who asked for pri" | the whole line, wrapping | nothing cut off |

Times: the server stores and sends UTC ISO strings and never puts a time into a sentence; the page formats each one with
`ui.fmt.when` (the owner's zone from settings). The harness never runs your page, so only a look in a desk (ideally with a
zone other than your own) checks this.

Also: speak to the owner as "you"; one idea per sentence; the same word for the same thing everywhere ("Accept", not
"Approve" on one screen and "Confirm" on the next); no "Generated by" signatures.

---

## 13. Testing and handing over

**The harness.** `tools/harness.mjs` is a stand-in for the desk: it builds the same `ctx` (routes callable in-process, an
in-memory database with the desk's SQL guard, kv, a scripted fake model, an approval door that answers as the test says,
jobs, events, Panic, secrets, `ctx.fetch` refused unless a test allows a host). `testhost.js`, copied unchanged into your
module folder, lets the same test file run in the harness (inside this kit) and in a real desk (inside its `modules/`), with
the same `allowHosts` and `fetchImpl` in both (`samples/guide-extras/guide-extras.test.js` reads a page that way in both).
`keys`, `prices` and `localModels` are harness-only: skip such a test in a desk and say why (as `samples/advisor` does).

<!-- from samples/advisor/advisor.test.js -->
```js
async function host(q, settings) {
  const h = await openHost({ script: scripted(q), settings });
  await h.call('POST', A + 'settings', { advisor: { provider: 'router', model: null } });   // the Free API as advisor, for plumbing
```

**The fake model.** In both places the model answers from your script `(body, n) => text | { text, toolCalls, status,
delayMs }`; `body.messages` is what your module sent. It proves plumbing: the right calls, the right order, the shape
checks, Stop, Panic, the refusals. It never proves that a real model does the work well.

**What counts as proof.** A command you ran and its output: `node --test` in the kit, `node tools/check-module.mjs <folder> --run`
with no red line (the run is a locked-down Node process: no programs, no workers, no network, writes only in a temp
folder, an empty environment), and in a desk `node --test modules/<id>/<id>.test.js`, `node tools/smoke.mjs --quick` with your module
found and switched on and off. Pictures of your page at 390 px and 1366 px wide, dark and light.

**What must be called "not checked".** Anything only the fake model answered (a real model's quality), anything not run on
Windows or macOS, any paid call, any outside service you could not reach.

**Looking at your page in a desk with a script.** A fresh desk first shows a role chooser ("Skip, show everything") and
then pairs the browser by a six-digit code it prints in its log; keep one browser profile so it stays paired, or start the
desk from a script with its test helper as the samples' proof did. The look follows the desk's own sun/moon button (the
`data-theme` attribute), not the browser's colour scheme: press that button for the light look.

**Common mistakes.** Tests that pass only in the harness (run them in a desk too). A test that calls the network. Saying
"all tests pass" with no output.

---

## 14. Worked example: the Advisor

The owner's idea: an official advisor, a big model, that guides small models and checks their work, and the owner verifies
at the end. Every step below is code in `samples/advisor/` (server.js about 280 lines, ui.js about 125).

1. **Choosing the big and the small model.** The owner picks both on the Advisor page from what `ctx.model.active()` lists,
   with sizes for local models (large: 14B or more; small: 8B or less). The picks live in kv as `{ provider, model }`; the
   worker may be `null`: then the desk's own chain, walked one step at a time and only on its free and local steps while
   paid calls are off (`function workerSteps` at samples/advisor/server.js line 84). See `picks()` (`const picks =` at samples/advisor/server.js line 31) and the
   `/state` route (`ctx.route('GET', '/state'` at samples/advisor/server.js line 225). The page's chooser is (`function chooser` at samples/advisor/ui.js line 27).
2. **Is it allowed, and what will it cost?** `kindOf()` (`function kindOf` at samples/advisor/server.js line 38) sorts a pick into local, free,
   paid or maybe (a maybe needs the same yes as paid); `refusal()` (`function refusal` at samples/advisor/server.js line 48) says in one sentence why it may not be called now
   (no advisor chosen, Offline, the Advisor's own paid switch off, the desk's Paid models switch off, a spend limit reached);
   `likelyCost()` (`function likelyCost` at samples/advisor/server.js line 63) gives "up to about X a run" (6 advisor calls at most) from earlier calls, or "cost not known".
   The page shows both before the first call. The refusal is checked again before every call (`gate()`, (`const gate =` at samples/advisor/server.js line 192)).
3. **The brief with yes-or-no checks.** The advisor is asked for one JSON object: goal, steps, checks
   (`const briefPrompt` at samples/advisor/server.js line 105). The prompt is built from the owner's task and the desk's settings (country,
   currency, zone, today's date, business name) (`const place =` at samples/advisor/server.js line 99); the owner's words are never read
   with patterns. `checkBrief()` (`function checkBrief` at samples/advisor/server.js line 127) checks the shape in code: a goal, 1 to 8 steps,
   1 to 8 checks, each numbered `c1`, `c2`, ...
4. **The work.** The worker gets the goal, the steps, the checks it will be judged by, and the owner's words
   (`const workPrompt` at samples/advisor/server.js line 113); it is told to write "not checked" for facts nobody gave.
5. **The review.** The advisor answers every check yes / no / cannot tell with one line of reason, and gives a verdict
   (`const reviewPrompt` at samples/advisor/server.js line 119). `checkReview()` (`function checkReview` at samples/advisor/server.js line 136) checks that every
   check is answered exactly once, with an allowed answer and a reason, and that "done" comes only with all yes. A malformed
   answer gets one second try with the reason (`askJson()`, (`async function askJson` at samples/advisor/server.js line 153)), then the run fails
   in plain words.
6. **Two rounds at most.** "needs work" gives the worker one more round with the advisor's notes and its last try; then it
   stops whatever the verdict (`for (let n = 1; n <= ROUNDS_MAX` at samples/advisor/server.js line 197).
7. **Who did what, and the cost.** Each round keeps the worker's and the reviewer's `r.label` and whether a small local
   model wrote it; the run keeps the cost the desk recorded for each of its own calls, with the count of calls whose cost
   is not known (`async function call` at samples/advisor/server.js line 75). The page shows "Who did what" and "Cost" (`const who =` at samples/advisor/ui.js line 76).
8. **The owner's Accept.** The run waits as "Waiting for you". Accept (`'/runs/:id/accept'` at samples/advisor/server.js line 245) marks it
   accepted; it is **done** only when the advisor said "done" and the owner accepted (`done: r.verdict` at samples/advisor/server.js line 164).
   Send back (`'/runs/:id/sendback'` at samples/advisor/server.js line 253) needs a note and starts a new run that carries it.
9. **A job with Stop and Panic.** The whole run is one job (`kind: 'advisor.run'` at samples/advisor/server.js line 183) with every model call on
   `job.signal`; Stop or Panic ends it as "stopped". Nothing is sent anywhere.
10. **The Coordinator can hand work to it.** The tool `advisor_ask` (`name: 'advisor_ask'` at samples/advisor/server.js line 266) starts a run
    from a chat; the run's progress card shows in that chat.
11. **"/advisor" in chat.** The desk 0.1.1 has no slash commands. The manifest declares the wish
    (`"commands": [{ "name": "advisor", "hint": "Hand this work to your advisor" }]`, ignored by the desk today); the tool and
    the page work now. Typing /advisor needs a small addition to the desk.

The tests (`samples/advisor/advisor.test.js`) walk: no advisor chosen, one round to done and Accept, a second round with the
notes, the stop after two rounds, Send back, a paid advisor refused while paid is off (never called), a brief in the wrong
form, and the tool with Panic. They pass in the kit's harness and in a desk. Not checked: a real advisor or worker model,
a paid advisor, Windows.

---

## 15. Other modules built the same way

Each outline: purpose, menu place, pages, tools, which models, what needs approval, done means.

**Proof-reader pair.** Purpose: a small model corrects spelling and grammar of a draft; a bigger one checks that the meaning
did not change. Place: "Proof-read" (order 152). Pages: one, with the text, the corrected text and the changes side by side.
Tools: `proofread_text`. Models: worker 1B to 3B local; checker 7B or an online free model. Approval: none (nothing leaves;
saving a file is `file.write`). Done means: every change listed, the checker answered "meaning kept" yes or no for each
paragraph, the owner pressed Use this.

**Lead checker.** Purpose: before a lead goes to Sales, check it is a buyer, not a news site or a seller. Place: none; a
section in Sales is not possible for a module, so its own page "Lead check". Tools: `lead_check`. Models: a small model reads
the fetched page into fields; a bigger one answers "is this a buyer? yes / no / cannot tell" with a quote from the page.
Approval: `browser.open` or `ctx.fetch` to the lead's site (hosts declared per site cannot be known: use the Search module's
exposed `read` instead of `ctx.fetch`); adding to Sales through `ctx.modules.api('sales').addLead` only after the owner's Keep.
Done means: each lead has an answer with the quote it rests on, or "not checked".

**Meeting-notes keeper.** Purpose: turn the owner's typed or pasted meeting notes into decisions, owners and dates. Place:
"Meetings". Pages: a list and one meeting. Tools: `meeting_add_notes`. Models: a 7B local or free model for the summary; the
advisor pattern for "did every decision get an owner?". Approval: none to keep notes; `send.person` to mail the summary to the
people in the meeting (draft, card, `assertGranted`). Done means: decisions, owners and dates listed, each linked to the line
of the notes it came from; dates shown in the owner's zone.

**Price watcher.** Purpose: watch the price of a few products on pages the owner names and tell him when it drops. Place:
"Prices". Pages: the list with last price and when it was read. Tools: `price_watch_add`. Models: none for reading a price that
the page states in a fixed spot; a small model only to find that spot once, checked by the owner. Approval: none to read
(`ctx.fetch` to declared hosts); a schedule through the Flows module's exposed API. Done means: every price shown came from a
page read at a stated time; a price not found says "not found on the page", never a guess; Offline shows the last reading
with its time.

**Translator with a reviewer.** Purpose: translate a text with a small model; a bigger model reviews meaning, tone and
numbers. Place: "Translate". Pages: source, translation, the reviewer's notes. Tools: `translate_text`. Models: worker 3B to 7B
(local or free); reviewer an online free or paid model, or 14B to 27B local, with the paid switch and cost line of chapter 6.
Approval: none (nothing is sent); a paid reviewer only when the owner allowed it. Done means: the reviewer answered yes / no /
cannot tell for "meaning kept", "numbers unchanged", "names unchanged", and the owner pressed Use this.
